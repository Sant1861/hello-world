<?php
ini_set("display_errors",1);
$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db=new Dbclass();
$db1=new Dbclass($cid);

$type=$_POST['type'];
extract($_POST); 

if($type==10){
    


$send=$db1->sql("select ABS(amount) as amount,date,trans_type,trans_name,ABS(CASE WHEN sm_main_form_140.amount<0 THEN sm_main_form_140.amount ELSE 0 END) as credit,ABS(CASE WHEN sm_main_form_140.amount>=0 THEN sm_main_form_140.amount ELSE 0 END) as debit  from sm_main_form_140 where chit_id='".$chit_id."' and  trans_type not in (12,14,16,17,18)  and  date <= '".date('Y-m-d')."' and del is null and status is null order by id desc limit 10")->many();


  
  echo json_encode($send);
    
    $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);    
    
// extract($_POST);   
/* Start Save Request */

$url="mcpl_mini_statement.php";
$new=fopen("log.txt",'a');
date_default_timezone_set("Asia/Kolkata");

$CURRENTDATE=date("Y-m-d h:i:s");

$write=$CURRENTDATE."-".$cid."-".$type."-".$url."-".$agent;

fwrite($new,$write);
fwrite($new,"\r\n");
fclose($new);    
    
}






?>