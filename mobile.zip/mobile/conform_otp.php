<?php
// ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();


    extract($_POST);
    //  print_r($_POST);
    if(!empty($mobile) && !empty($led_id) && $led_id !='0'){
        $check = $db->from('otp')->sortDesc('id')->where('mobile',$mobile)->where('led_id',$led_id)->where('status',1)->where('cid',$cid)->select()->one();
// echo $check."prem";
if($otp===$check['otp'])
     {
         
        //  print_r($_POST);
      $data = $db->from('sm_main_form_20')->where('led_id',$led_id)->where('cid',$cid)->one();
          
        
             $check=$db1->sql("select email,f_name from sm_main_form_104 where del is null and mobile='".$_POST["mobile"]."'and role_id='".$_POST["role_id"]."' and f_name is not null and email is not null")->one();
      $check1 = count($check);
    //   print_r($check1);
       // $ch =$db1->from('sm_main_form_108')->where('del #,null')->where('cid',$cid)->where('name',$data['led_id'])->select()->one();
        	
            if($check1>0){
                //  print_r($_POST);
                $data1['mobile'] = $data['mobile'];
			$data1['email']=$check['email'];
				$data1['f_name']=$check['f_name'];
         $data1["error"]= "false";
         $data1["error_msg"] = "Already register";
                
            }
        
            else{
$in = array('uid'=>$data['id'],'date'=>date('Y-m-d'),'cid'=>$data['cid'],'name'=>$data['led_id'],'mobile'=>$mobile,'device_id'=>$device_id,'cus_name'=>$data['name']);
 
$pn = $db1->from("sm_main_form_108")->insert($in)->execute();
        
      
			   
			
				// $stmt1 = $db->sql("SELECT cid,name,address,phone FROM sm_main_form_7 WHERE cid = '$cid' ")->one();
				
				// $row2 = $stmt1;
				 $data1['mobile'] = $data['mobile'];
			
         $data1["error"]= "TRUE";
         $data1["error_msg"] = "Login Successfull";
        
     }
    
    }
    
    
    }
    else{
         $data1["error"]= TRUE;
		 $data1["error_msg"] = "Required parameters  missing!";
    }
     
             echo json_encode($data1);
  
  ?>
  
  