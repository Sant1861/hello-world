<?php  
/*SAVE QUERY*/
// ini_set("display_errors",1);
$cid=21472147;

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
$type = $_POST['type'];
$data=$_POST;

if($type==10){
   
// print_r($data);

    /* Role id check */
    if($data['role_id'] != '' && $data['role_id'] !='0'  ){
        
        $check=$db->sql("select * from sm_main_form_20 where del is null and mobile='".$data["mobile"]."' ")->one();
        $a=$check['led_id'];
      
     //print_r($a);
      
      $ldata=array('cid'=>$data["cid"],'f_name'=>$data["f_name"],'address'=>$data["address"],'email'=>$data["email"],'state'=>$data["state"],'city'=>$data["city"],'dist'=>$data['dist']);
      
        $ledinsert=$db1->from('sm_main_form_104')->where('id',$a)->update($ldata)->execute();
     
      $ldata1=array('cid'=>$data["cid"],'f_name'=>$data["f_name"],'address'=>$data["address"],'email'=>$data["email"],'state'=>$data["state"],'city'=>$data["city"],'dist'=>$data['dist']);
      
      $ledinsert1=$db->from('sm_main_form_20')->where('led_id',$a)->update($ldata1)->execute();
      
    
    $response["error"] = 'FALSE';
    $response['role_id']=$data['role_id'];
     $response['f_name']=$data['f_name'];
      $response['email']=$data['email'];
  $response["error_msg"] = " Register successfully";
  echo json_encode($response);
    
     
      
    }
    
    
    else{
       $response["error_msg"] ="Required parameters  missing!"; 
       echo json_encode($response);
    }
        
        
//         if($check["mobile"] != $data["mobile"]){
            
//                     if($data['role_id'] !='3'){
    
//     $ldata=array('cid'=>$data["cid"],'f_name'=>$data["f_name"],'address'=>$data["address"],'email'=>$data["email"],'state'=>$data["state"],'city'=>["city"],'dist'=>['dist']);

// $ledinsert=$db1->from('sm_main_form_104')->insert($ldata)->execute();

// $ldata1=array('cid'=>$data["cid"],'f_name'=>$data["f_name"],'address'=>$data["address"],'email'=>$data["email"],'state'=>$data["state"],'city'=>["city"],'dist'=>['dist']);
// $ledinsert1=$db->from('sm_main_form_20')->insert($ldata1)->execute();
// }
// }
 }
 else {
    // required post params is missing
    $response["error"] = TRUE;
	
    $response["error_msg"] ="Required parameters  missing!";
    
}

if($type==11){
    
    
    $coupen= $db1->from('sm_main_form_104')->where('del', null)->many();
    echo json_encode($coupen);
}
if($type==12){
   
// print_r($data);

    /* Role id check */
    if($data['role_id'] != '' && $data['role_id'] !='0'  ){
        
        $check=$db->sql("select * from sm_main_form_20 where del is null and mobile='".$data["mobile"]."' ")->one();
        $a=$check['led_id'];
      
     //print_r($a);
      
      $ldata=array('cid'=>$data["cid"],'f_name'=>$data["f_name"],'address'=>$data["address"],'email'=>$data["email"],'state'=>$data["state"],'city'=>$data["city"],'dist'=>$data['dist']);
      
        $ledinsert=$db1->from('sm_main_form_104')->where('id',$a)->update($ldata)->execute();
     
      $ldata1=array('cid'=>$data["cid"],'f_name'=>$data["f_name"],'address'=>$data["address"],'email'=>$data["email"],'state'=>$data["state"],'city'=>$data["city"],'dist'=>$data['dist']);
      
      $ledinsert1=$db->from('sm_main_form_20')->where('led_id',$a)->update($ldata1)->execute();
      
    
    $response["error"] = 'FALSE';
    $response['role_id']=$data['role_id'];
     $response['f_name']=$data['f_name'];
      $response['email']=$data['email'];
  $response["error_msg"] = " Register successfully";
  echo json_encode($response);
    
     
      
    }
    
    
    else{
       $response["error_msg"] ="Required parameters  missing!"; 
       echo json_encode($response);
    }
        
        

 }
 else {
    // required post params is missing
    $response["error"] = TRUE;
	
    $response["error_msg"] ="Required parameters  missing!";
    
}

 