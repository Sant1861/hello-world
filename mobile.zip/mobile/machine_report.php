<?php
ini_set("display_errors",1);

$cid=$_POST['cid'];
 $con2 = mysqli_connect('localhost','softuser','Soft@2021',"s_".$cid); 
//  echo $con2;



// $type = $_POST['type'];
// $data=$_POST;
// /* Macine wise report  for Agent
//  REPORT contain the information about agent Machine wise collection in particular date wise*/
// if($type==5){
     
//     extract($_POST);
    
//     $response = array();
    
//     $data6 = array('SNO','COLLECTION_DATE','NO_OF_MACHINE','AMOUNT');

//     $sdate = date('Y-m-d',strtotime($sdate));
//     $edate = date('Y-m-d',strtotime($edate));
//     // $cdate=date('Y-m-d');
//     $machine=$data['palmtec_id'];
   
//     /* COUNT(machine_id) ->no of machine (agent) in particular date  , sum(amount)->agent collection amount in particular date for machine */  
    

    
//     $active_machine = "SELECT collectdt ,receiptno,palmtec_id,collectamt as amount FROM `transact` where `collectdt` BETWEEN '".date('Y-m-d',strtotime($sdate))."' and '".date('Y-m-d',strtotime($edate))."' AND palmtec_id='$machine'   group by date(collectdt),palmtec_id ";
     
//       echo  $active_machine;
//   $result = mysqli_query($con2,$active_machine);
     
//             $i=1;
//              while($row1 = mysqli_fetch_array($result, MYSQLI_ASSOC))
//   {
    
//                  $date = date('d-m-Y',strtotime($row1['collectdt']));
//                  $data4[]=array('SNO'=>$i,'COLLECTION_DATE'=>$date,'NO_OF_MACHINE'=>$row1['receiptno'],'AMOUNT'=>$row1['amount']);
//                     $rcount += $row1['receiptno'];
//                     $tcount += $row1['amount'];
//             $i++;
//                     }

//     $data4[]=array('SNO'=>"",'COLLECTION_DATE'=>"",'NO_OF_MACHINE'=>"",'AMOUNT'=>"",'TOTAL_MACHINES'=>$rcount,'TOTAL_AMOUNT'=>$tcount);
 
    
//     $response['header'] = $data6;
//     $response['cont'] = $data4;

//   echo json_encode($response);

// }




$type = $_POST['type'];
$data=$_POST;

/* Macine wise report  for Agent
 REPORT contain the information about agent Machine wise collection in particular date wise*/
if($type==5){
 
    extract($_POST);
    
 /*start request save*/ 
     $r_t=$data['request'];
//$log=$_SERVER['REQUEST_URI'];
date_default_timezone_set('Asia/Kolkata');
$new=fopen("log.txt",'a');
$CURRENTDATE=date("Y-m-d H:i:s"); 
//echo $CURRENTDATE;
$write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $data['palmtec_id']." - " . $data['collectdt']." - " .$name  ;
//$write="[" . $CURRENTDATE . " ] - " . $log;

fwrite($new,$write);
fwrite($new,"\r\n");
fclose($new);
  /* end request save*/

    
    $response = array();
    
    $data6 = array('SNO','DATE','ACC_NO','AMOUNT');

    extract($_POST);
     
$palmtec_id=$data['palmtec_id'];
$cdate=date('Y-m-d');

 
$query = "select * from transact where post is null and cancel='N' and palmtec_id='$palmtec_id' and collectdt='$cdate' ";
 
//  echo  $query;

$result = mysqli_query($con2,$query);
//   exit;
// print_r($data);
  $a=0;
  $result1 =$result;
  
$i=1;

  $k=0;  
     while($row1 = mysqli_fetch_array($result1, MYSQLI_ASSOC))
  {
          $k++;    
//   print_r($row1);
                 $data4[]=array('SNO'=>$k,'DATE'=>date('d-m-Y',strtotime($cdate)),'ACC_NO'=>$row1['acno'],'AMOUNT'=>$row1['collectamt']);
                    // $rcount = count($row1['ACC_NO']);
                    $tcount += $row1['collectamt'];
            $i++;
                    }

    $data4[]=array('SNO'=>"",'DATE'=>"",'ACC_NO'=>"TOTAL",'AMOUNT'=>"$tcount");
 
    
    $response['header'] = $data6;
    $response['cont'] = $data4;

  echo json_encode($response);

}

if($type==1){
    
     /*start request save*/ 
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
$a=array();
$machine_id = "select DISTINCT(palmtec_id) from transact  "; 
$result = mysqli_query($con2,$machine_id);
while($row1 = mysqli_fetch_array($result, MYSQLI_ASSOC))

  {
      $a[]=$row1;

  }
    echo json_encode($a);
}



if($type==2){
    
$c_date=date('Y-m-d');
    
  
     /*start request save*/ 
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$c_date  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/

    
$i=array();
$c_date=date('Y-m-d');
     
$machine_id = "select palmtec_id,COUNT(receiptno) as receipts, SUM(collectamt) as collectamt from transact where collectdt='$c_date' group by  palmtec_id" ; 
$result = mysqli_query($con2,$machine_id);

while($row= mysqli_fetch_array($result, MYSQLI_ASSOC))
  {
     $i[]=$row;
  }
    echo json_encode($i);
}


?>



























