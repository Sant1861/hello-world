
<?

$cid=21472147;

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
$type = $_POST['type'];
$data=$_POST;

if($type==1){
    
    // print_r($_POST);
    $id=$data['id'];

 $result=$db1->sql("SELECT * FROM sm_main_form_102 WHERE id=$id and del IS NULL ORDER BY id DESC")->many();
                            
                         
                            foreach($result as $res)
                            {
					$idd=$res['id'];

               $pro_img=$db1->sql("SELECT pro_img FROM sm_main_form_103 WHERE pro_id=$idd and   del IS NULL")->many();
       
        
        
        
	
        
        
        
                    
      $data1["pro_name"]=$res['pro_name'];
     $data1["cat_name"]=$res['cat_name'];
     $data1["pro_price"]=$res['pro_price'];
      $data1["pro_size"]=$res['pro_size'];
      $data1["room"]=$res['room'];
      $data1["bathroom"]=$res['bathroom'];
      $data1["garage"]=$res['garage'];
      $data1["garage_size"]=$res['garage_size'];
      $data1["bed_room"]=$res['bed_room'];
      $data1["year_build"]=$res['year_build'];
      $data1["land_mark"]=$res['land_mark'];
      $data1["pro_sts"]=$res['pro_sts'];
      $data1["address"]=$res['address'];
      $data1["city"]=$res['city'];
        $data1["state"]=$res['state'];
         $data1["post_code"]=$res['post_code'];
          
          $data1["pro_occ"]=$res['pro_occ'];
          $data1["property_type"]=$res['property_type'];
            $data1["pro_stories"]=$res['pro_stories'];
             $data1["pro_building"]=$res['pro_building'];
              $data1["park_space"]=$res['park_space']; 
              $data1["pro_feature"]=$res['pro_feature'];
              $data1["upcoming"]=$res['upcoming'];
              $data1["category_name"]=$res['category_name'];
              $data1["seller"]=$res['seller'];
               $data1["seller_name"]=$res['seller_name'];
              $data1["sel_name"]=$res['sel_name'];
               $data1["pro_desc"]=$res['pro_desc'];
                $data1["pro_feature"]=$res['pro_feature'];
              $data1["lt"]=$res['lt'];
              $data1["ln"]=$res['ln'];
              $data1["sts_name"]=$res['sts_name'];
              $data1["pro_img"]=$pro_img;
      
      echo json_encode($data1);

                            }

    
}

if ($type==2) {
    
    print_r($_POST);
    $id = $data['id'];
   

// [cid] => 21472147
// [cat_name] => 5
// [pro_price] => test
// [pro_size] =>
// [room] =>
// [bathroom] =>
// [garage] =>
// [garage_size] =>
// [bed_room] =>
// [year_build] =>
// [pro_sts] => 1932
// [pro_name] => test
// [address] => tedt
// [city] => Tiruppur
// [area] =>
// [post_code] => test
// [pro_desc] => tesy
// [pro_stories] =>
// [park_space] =>
// [pro_feature] => test
// [count] => 0
// [clocation] =>
// [lt] => 11.0150152
// [ln] => 77.0234732
// [upcoming] => 2
// [c_mobile] => 7092676471
// [pro_type] => 6
// [land_mark] => test
// [pay_id] =>




    //$data1 = array('pro_name' => $data['pro_name']);
  $data1 = array('cat_name' => $data['cat_name'],'pro_price' => $data['pro_price'],'pro_size' => $data['pro_size'],'room' => $data['room'],'bathroom' => $data['bathroom'],'garage' => $data['garage'],'garage_size' => $data['garage_size'],'bed_room' => $data['bed_room'],'year_build' => $data['year_build'],'pro_sts' => $data['pro_sts'],'pro_name' => $data['pro_name'],'address' => $data['address'],'city' => $data['city'],'area' => $data['area'],'post_code' => $data['post_code'],'pro_desc' => $data['pro_desc'],'pro_stories' => $data['pro_stories'],'park_space' => $data['park_space'],'pro_feature' => $data['pro_feature'],'clocation' => $data['clocation'],'lt' => $data['lt'],'ln' => $data['ln'],'upcoming' => $data['upcoming'],'c_mobile' => $data['c_mobile'],'pro_type' => $data['pro_type'],'land_mark' => $data['land_mark'],'pay_id' => $data['pay_id']);
  
  
  
  
  
//   $data1 = array('pro_name' => $data['pro_name'], 'cat_name' => $y, 'category_name' => $cat_name1, 'pro_type' => $x, 'property_type' => $prosk, 'pro_price' => $data['pro_price'], 'pro_size' => $data['pro_size'], 'room' => $data['room'], 'bathroom' => $data['bathroom'], 'garage' => $data['garage'], 'garage_size' => $data['garage_size'], 'bed_room' => $data['bed_room'], 'year_build' => $data['year_build'], 'land_mark' => $data['land_mark'], 'pro_sts' => $data['pro_sts'], 'sts_name' => $a, 'address' => $data['address'], 'city' => $cityy, 'area' => $area2, 'state' => $data['state'], 'post_code' => $data['post_code'], 'pro_desc' => $data['pro_desc'], 'pro_occ' => $data['pro_occ'], 'pro_stories' => $data['pro_stories'], 'pro_building' => $data['pro_building'], 'park_space' => $data['park_space'], 'seller_name' => $u, 'sel_name' => $selname2, 'pro_feature' => $data['pro_feature'], 'c_mobile' => $data['c_mobile'], 'lt' => $data['lt'], 'pay_id' => $data['pay_id'], 'ln' => $data['ln'],'price_no'=>$data['price_no'],'upcoming' => $data['upcoming'],'seller' => $d1);
echo  $result=$db1->from('sm_main_form_102')->where('id',$id)->update($data1)->sql();
 $result=$db1->from('sm_main_form_102')->where('id',$id)->update($data1)->execute();

 


   
}








?>