<?php
$cid = $_REQUEST['cid'];
require_once("../index.php");
require_once(BASEPATH . 'config/autoloader.php');
require_once(BASEPATH . 'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
// ini_set("display_errors",1);
$db->sql("SET NAMES utf8")->execute();
$db1->sql("SET NAMES utf8")->execute();
$offset = '';
$offsetval = "";
$search = "";
$word = "";
$offset = "";
$city = "";
$area = "";
$pincode = "";
$saletype = "";
$subcatlist = "";
$minprice = "";
$maxprice = "";
$led_id = "";
$newold = "";
$order = "";
$areas = "";
$citys = "";
extract($_REQUEST);
$cid = 13051305;
extract($_REQUEST);


if ($sub_type == 1) {
	if (!empty($cat_id)) {
		$search .= " AND category=$cat_id ";
	}
	if (!empty($sub_cat_id)) {
		$search .= " AND sub_cat=$sub_cat_id ";
	}
	if ($cat_id == 1) {
		if (!empty($saletype)) {
			$search .= " AND listing_for=$saletype ";
		}
	}
	if (!empty($subcatlist)) {
		$subcatlist = rtrim($subcatlist, ",");
		$search .= " AND pro_type in($subcatlist) ";
	}

	if (!empty($minprice)) {
		$search .= " AND (price_in_number >= $minprice) ";
	}
	if (!empty($maxprice)) {
		$search .= " AND (price_in_number <= $maxprice)  ";
	}
	if (!empty($city)) {
		$ex = explode(" ", $city);


		foreach ($ex as $ex1) {
			$citys .= "'" . $ex1 . "',";
		}

		$citys = rtrim($citys, ',');
		$search .= " AND city in ($citys)";

		$word .= "$city";
	}
	if (!empty($area)) {
		$areaaa = $area;
		$ex = explode(" ,", $area);
		// // print_r($ex);
		foreach ($ex as $ex1) {
			$areas .= "'" . $ex1 . "',";
		}

		$areas = rtrim($areas, ',');
		$search .= " AND area in ($areas)";

		$word .= "-$areaaa ";
	}
	if (!empty($pincode)) {
		$search .= " AND postal_code=$pincode ";

		$word .= "-$pincode ";
	}
	if ($cat_id == 2) {

		$ip = $db1->sql("SELECT `id`, `category`, `sub_cat`, `pro_type`, `client_name`, `client_whatsapp`, `client_mobile`, `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`, `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`, `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`, `user_upload_by`, `paid`, `date`, `edit_date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `edit_id`, `del`, `is_d`, `act`, `dtime`, `state`, `job_role`, `job_experience`, `job_salary`, `key_skils`, `place`, `offering_value`, `email`, `website`, `price`, `describtion`, `propriter_name`, `mail_id`, `pincode`, (SELECT img_2 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null  and category=  $cat_id   order by id desc limit 50")->many();
		foreach ($ip as &$val) {
			$sk['price_in_number'] =  $val['price_in_alphabet'];
			$sk['email'] = $val['email'];
			$sk['product_title'] =  $val['vehicle_name'];
			$sk['area'] =  $val['area'];
			$sk['pro_type'] =  $val['pro_type'];
			$sk['city'] =  $val['city'];
			$sk['id'] =  $val['id'];
			$sk['client_mobile'] =  $val['contact_number'];
			$sk['img1'] =  $val['img1'];
			// $sk['pro_size']=$val['product_size'];
			// $sk['size_type']=$val['size_type'];
			$sk['pro_code'] = $val['product_code'];
			// $sk['pro_code']=$val['product_code'];
			$skk[] = $sk;
		}
	}
	if ($cat_id == 3) {
		//  print_r($_POST);
//  ini_set("display_errors",1);
	$ip = $db1->sql("SELECT `id`, `category`, `sub_cat`, `pro_type`, `client_name`, `client_whatsapp`, `client_mobile`, `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`, `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`, `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`, `user_upload_by`, `paid`, `date`, `edit_date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `edit_id`, `del`, `is_d`, `act`, `dtime`, `state`, `job_role`, `job_experience`, `job_salary`, `key_skils`, `place`, `offering_value`, `email`, `website`, `price`, `describtion`, `propriter_name`, `mail_id`, `pincode`, (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null    $search  order by id desc ")->many();
		foreach ($ip as &$val) {
			//   =$val['job_role'];
// 			$rolename = $db->sql("SELECT name FROM sm_main_form_11 WHERE value=" . $val["job_role"] . " and list_id=217 ")->one();
 $head_job=$db1->sql("select ans as job from add_property_1 where del is null and mid=".$val['id']." and ques='Job_Role'")->one();
			$sk['price_in_number'] =  $val['price_in_alphabet'];
			$sk['email'] = $val['email'];
			$sk['product_title'] =  $head_job['job'];
			$sk['area'] =  $val['area'];
			$sk['pro_type'] =  $val['pro_type'];
			$sk['city'] =  $val['city'];
			$sk['id'] =  $val['id'];
			$sk['client_mobile'] =  $val['contact_no'];
			$sk['img1'] =  $val['img1'];
			$sk['pro_size'] = $val['company_name'];
			// $sk['size_type']=$val['size_type'];
			$sk['pro_code'] = $val['product_code'];
			// $sk['pro_code']=$val['product_code'];
			$skk[] = $sk;
		}
	}
	if ($cat_id == 4) {
		//  print_r($_POST);

		$ip = $db1->sql("SELECT `id`, `category`, `sub_cat`, `pro_type`, `client_name`, `client_whatsapp`, `client_mobile`, `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`, `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`, `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`, `user_upload_by`, `paid`, `date`, `edit_date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `edit_id`, `del`, `is_d`, `act`, `dtime`, `state`, `job_role`, `job_experience`, `job_salary`, `key_skils`, `place`, `offering_value`, `email`, `website`, `price`, `describtion`, `propriter_name`, `mail_id`, `pincode`, (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null    $search   order by id desc")->many();
		foreach ($ip as &$val) {
			//   =$val['job_role'];
			// $rolename=$db->sql("SELECT name FROM sm_main_form_11 WHERE value=" . $val["job_role"] . " and list_id=217 ")->one();           

			$sk['price_in_number'] =  $val['business_name'];
			// $sk['email']=$val['email'];
			$sk['product_title'] =  $val['propriter_name'];
			$sk['area'] =  $val['area'];
			$sk['pro_type'] =  $val['pro_type'];
			$sk['city'] =  $val['city'];
			$sk['id'] =  $val['id'];
			$sk['client_mobile'] =  $val['contact_number'];
			$sk['img1'] =  $val['img1'];
			$sk['pro_size'] = $val['company_name'];
			// $sk['size_type']=$val['size_type'];
			$sk['pro_code'] = $val['product_code'];
			// $sk['pro_code']=$val['product_code'];
			$skk[] = $sk;
		}
	}
	if ($cat_id == 5) {
		//  print_r($_POST);

	 $ip = $db1->sql("SELECT `id`, `category`, `sub_cat`, `pro_type`, `client_name`, `client_whatsapp`, `client_mobile`, `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`, `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`, `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`, `user_upload_by`, `paid`, `date`, `edit_date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `edit_id`, `del`, `is_d`, `act`, `dtime`, `state`, `job_role`, `job_experience`, `job_salary`, `key_skils`, `place`, `offering_value`, `email`, `website`, `price`, `describtion`, `propriter_name`, `mail_id`, `pincode`, (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null    $search   order by id desc")->many();
		foreach ($ip as &$val) {
			//   =$val['job_role'];
			// $rolename=$db->sql("SELECT name FROM sm_main_form_11 WHERE value=" . $val["job_role"] . " and list_id=217 ")->one();           

			$sk['price_in_number'] =  $val['address'];
// 			$sk['price_in_number'] =  $val['company_name'] . "in" . $val['city'];
			$sk['listing_for'] = $val['business_proof'];
			$sk['product_title'] =  $val['company_name'] . " in " . $val['city'];
// 			$sk['product_title'] =  $val['address'];
			$sk['area'] =  $val['area'];
			$sk['pro_type'] =  $val['pro_type'];
			$sk['city'] =  $val['city'];
			$sk['id'] =  $val['id'];
			$sk['client_mobile'] =  $val['contact_number'];
			$sk['img1'] =  $val['img1'];
			$sk['pro_size'] = $val['payment_mode'];
			// $sk['size_type']=$val['size_type'];
			$sk['pro_code'] = $val['product_code'];
			// $sk['pro_code']=$val['product_code'];
			$skk[] = $sk;
		}
	}
	if ($cat_id == 7) {
		//  print_r($_POST);

		$ip = $db1->sql("SELECT `id`, `category`, `sub_cat`, `pro_type`, `client_name`, `client_whatsapp`, `client_mobile`, `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`, `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`, `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`, `user_upload_by`, `paid`, `date`, `edit_date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `edit_id`, `del`, `is_d`, `act`, `dtime`, `state`, `job_role`, `job_experience`, `job_salary`, `key_skils`, `place`, `offering_value`, `email`, `website`, `price`, `describtion`, `propriter_name`, `mail_id`, `pincode`, (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1 ) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null    $search   order by id desc")->many();
		foreach ($ip as &$val) {
			//   =$val['job_role'];
			$pro_for = $db->sql("SELECT name FROM sm_main_form_11 WHERE value=" . $val["mobile_brand"] . " and list_id=224 and del IS NULL")->one();

			$sk['price_in_number'] =  $pro_for['name'];
			$sk['listing_for'] = $val['seller_name'];
			$sk['product_title'] =  $val['description'];
			$sk['area'] =  $val['area'];
			$sk['pro_type'] =  $val['pro_type'];
			$sk['city'] =  $val['city'];
			$sk['id'] =  $val['id'];
			$sk['client_mobile'] =  $val['mobile_number'];
			$sk['img1'] =  $val['img1'];
			$sk['pro_size'] = $val['description'];
			// $sk['size_type']=$val['size_type'];
			$sk['pro_code'] = $val['product_code'];
			// $sk['pro_code']=$val['product_code'];
			$skk[] = $sk;
		}
	}
	
	if ($cat_id == 8) {
	
	$ip = $db1->sql("SELECT *, (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1 ) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null    $search   order by id desc")->many();
		foreach ($ip as &$val) {
		    
		    if($val['img1']!=""){
		        $imgs=$val['img1'];
		    }else{
		       $imgs="https://truebroker.in/img/no_img.jpg"; 
		    }
		    
		    $dateTimeStr = $val['auction_edate'];
$dateTime = new DateTime($dateTimeStr);

// Format the date with the month in words
$formattedDate = $dateTime->format('F j, Y');

// Format the time in 12-hour format with AM/PM
$formattedTime = $dateTime->format('h:i A');

// echo $formattedDate . ' ' . $formattedTime; 
                                    $dateTimeStr1 = $val['auction_sdate'];
$dateTime1 = new DateTime($dateTimeStr1);

// Format the date with the month in words
$formattedDate1 = $dateTime1->format('F j, Y');

// Format the time in 12-hour format with AM/PM
$formattedTime1 = $dateTime1->format('h:i A');

// echo $formattedDate . ' ' . $formattedTime; 	
		    
		    
		    
		    
			//   =$val['job_role'];
			$pro_for = $db->sql("SELECT name FROM sm_main_form_11 WHERE value=" . $val["bank_name"] . " and list_id=244 and del IS NULL")->one();

			$sk['rev_price'] =  $val['reserve_price'];
			$sk['auction_type'] = $val['auction_type'];
			$sk['bank_name'] =  $pro_for['name'];
			$sk['emd_amount'] =  $val['emd_amount'];
			$sk['auction_start'] =  $formattedDate1 . ' ' . $formattedTime1 ;
			$sk['auction_end'] =  $formattedDate . ' ' . $formattedTime  ;
			$sk['id'] =  $val['id'];
			$sk['client_mobile'] =  $val['client_mobile'];
			$sk['img1'] = $imgs;
			$sk['pro_size'] = $val['description'];
			// $sk['size_type']=$val['size_type'];
			$sk['pro_code'] = $val['product_code'];
			// $sk['pro_code']=$val['product_code'];
			$skk[] = $sk;
		}
	
	

	
	
	}
	
	echo json_encode($skk);
}




if ($sub_type == 2) {
	// print_r($_POST);
	if (!empty($cat_id)) {
		$search .= " AND category=$cat_id ";
	}
	if (!empty($sub_cat_id)) {
		$search .= " AND sub_cat=$sub_cat_id ";
	}
	if ($cat_id == 1) {
		if (!empty($sale_type)) {
			$search .= " AND listing_for=$sale_type ";
		}
	}
	if (!empty($subcatlist)) {
		$subcatlist = rtrim($subcatlist, ",");
		$search .= " AND pro_type in($subcatlist) ";
	}

	if (!empty($minprice)) {
		$search .= " AND (price_in_number >= $minprice) ";
	}
	if (!empty($maxprice)) {
		$search .= " AND (price_in_number <= $maxprice)  ";
	}
	if (!empty($city)) {
		$ex = explode(" ", $city);


		foreach ($ex as $ex1) {
			$citys .= "'" . $ex1 . "',";
		}

		$citys = rtrim($citys, ',');
		$search .= " AND city in ($citys)";

		$word .= "$city";
	}
	if (!empty($area)) {
		$areaaa = $area;
		$ex = explode(" ,", $area);
		// // print_r($ex);
		foreach ($ex as $ex1) {
			$areas .= "'" . $ex1 . "',";
		}

		$areas = rtrim($areas, ',');
		$search .= " AND area in ($areas)";

		$word .= "-$areaaa ";
	}
	if (!empty($pincode)) {
		$search .= " AND postal_code=$pincode ";

		$word .= "-$pincode ";
	}
	if ($cat_id == 1) {
		if ($sale_type == 0) {
			$ip = $db1->sql("SELECT `id`, `aid`, `uid`, `bid`, `cid`, `sub_cat`, `client_name`, `client_whatsapp`, `client_mobile`, 
                            `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, 
                            `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`,
                            `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`,
                            `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`,
                            `user_upload_by`, `paid`, `date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `del`, `is_d`, `act`, `dtime`,
                            (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null    AND category=$cat_id    order by id ASC ")->many();
			// print_r($ip);
			foreach ($ip as &$val) {
				$sk['price_in_number'] =  $val['price_in_alphabet'];
				$sk['listing_for'] = $val['listing_for'];
				$sk['product_title'] =  $val['product_title'];
				$sk['area'] =  $val['area'];
				$sk['pro_type'] =  $val['pro_type'];
				$sk['city'] =  $val['city'];
				$sk['id'] =  $val['id'];
				$sk['client_mobile'] =  $val['client_mobile'];
				$sk['img1'] =  $val['img1'];
				$sk['pro_size'] = $val['product_size'];
				$sk['size_type'] = $val['size_type'];
				$sk['pro_code'] = $val['product_code'];
				// $sk['pro_code']=$val['product_code'];
				$skk[] = $sk;
			}
		} else {
			$ip = $db1->sql("SELECT `id`, `aid`, `uid`, `bid`, `cid`, `sub_cat`, `client_name`, `client_whatsapp`, `client_mobile`, 
                            `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, 
                            `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`,
                            `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`,
                            `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`,
                            `user_upload_by`, `paid`, `date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `del`, `is_d`, `act`, `dtime`,
                            (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null and listing_for!=''   $search   order by id desc ")->many();
			// print_r($ip);
			foreach ($ip as &$val) {
				$sk['price_in_number'] =  $val['price_in_alphabet'];
				$sk['listing_for'] = $val['listing_for'];
				$sk['product_title'] =  $val['product_title'];
				$sk['area'] =  $val['area'];
				$sk['pro_type'] =  $val['pro_type'];
				$sk['city'] =  $val['city'];
				$sk['id'] =  $val['id'];
				$sk['client_mobile'] =  $val['client_mobile'];
				$sk['img1'] =  $val['img1'];
				$sk['pro_size'] = $val['product_size'];
				$sk['size_type'] = $val['size_type'];
				$sk['pro_code'] = $val['product_code'];
				// $sk['pro_code']=$val['product_code'];
				$skk[] = $sk;
			}
		}
	}




	if ($cat_id == 2) {

		$ip = $db1->sql("SELECT `id`, `category`, `sub_cat`, `pro_type`, `client_name`, `client_whatsapp`, `client_mobile`, `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`, `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`, `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`, `user_upload_by`, `paid`, `date`, `edit_date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `edit_id`, `del`, `is_d`, `act`, `dtime`, `state`, `job_role`, `job_experience`, `job_salary`, `key_skils`, `place`, `offering_value`, `email`, `website`, `price`, `describtion`, `propriter_name`, `mail_id`, `pincode`, (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null  and category=  $cat_id   order by id desc limit 50")->many();
		foreach ($ip as &$val) {
			$sk['price_in_number'] =  $val['price_in_alphabet'];
			$sk['email'] = $val['email'];
			$sk['product_title'] =  $val['vehicle_name'];
			$sk['area'] =  $val['area'];
			$sk['pro_type'] =  $val['pro_type'];
			$sk['city'] =  $val['city'];
			$sk['id'] =  $val['id'];
			$sk['client_mobile'] =  $val['contact_number'];
			$sk['img1'] =  $val['img1'];
			// $sk['pro_size']=$val['product_size'];
			// $sk['size_type']=$val['size_type'];
			$sk['pro_code'] = $val['product_code'];
			// $sk['pro_code']=$val['product_code'];
			$skk[] = $sk;
		}
	}
	if ($cat_id == 3) {
		//  print_r($_POST);

		$ip = $db1->sql("SELECT `id`, `category`, `sub_cat`, `pro_type`, `client_name`, `client_whatsapp`, `client_mobile`, `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`, `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`, `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`, `user_upload_by`, `paid`, `date`, `edit_date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `edit_id`, `del`, `is_d`, `act`, `dtime`, `state`, `job_role`, `job_experience`, `job_salary`, `key_skils`, `place`, `offering_value`, `email`, `website`, `price`, `describtion`, `propriter_name`, `mail_id`, `pincode`, (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null    $search   order by id desc")->many();
		foreach ($ip as &$val) {
			//   =$val['job_role'];
			$rolename = $db->sql("SELECT name FROM sm_main_form_11 WHERE value=" . $val["job_role"] . " and list_id=217 ")->one();

			$sk['price_in_number'] =  $val['price_in_alphabet'];
			$sk['email'] = $val['email'];
			$sk['product_title'] =  $rolename['name'];
			$sk['area'] =  $val['area'];
			$sk['pro_type'] =  $val['pro_type'];
			$sk['city'] =  $val['city'];
			$sk['id'] =  $val['id'];
			$sk['client_mobile'] =  $val['contact_no'];
			$sk['img1'] =  $val['img1'];
			$sk['pro_size'] = $val['company_name'];
			// $sk['size_type']=$val['size_type'];
			$sk['pro_code'] = $val['product_code'];
			// $sk['pro_code']=$val['product_code'];
			$skk[] = $sk;
		}
	}
	if ($cat_id == 4) {
		//  print_r($_POST);

		$ip = $db1->sql("SELECT `id`, `category`, `sub_cat`, `pro_type`, `client_name`, `client_whatsapp`, `client_mobile`, `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`, `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`, `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`, `user_upload_by`, `paid`, `date`, `edit_date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `edit_id`, `del`, `is_d`, `act`, `dtime`, `state`, `job_role`, `job_experience`, `job_salary`, `key_skils`, `place`, `offering_value`, `email`, `website`, `price`, `describtion`, `propriter_name`, `mail_id`, `pincode`, (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null    $search   order by id desc")->many();
		foreach ($ip as &$val) {
			//   =$val['job_role'];
			// $rolename=$db->sql("SELECT name FROM sm_main_form_11 WHERE value=" . $val["job_role"] . " and list_id=217 ")->one();           

			$sk['price_in_number'] =  $val['business_name'];
			// $sk['email']=$val['email'];
			$sk['product_title'] =  $val['propriter_name'];
			$sk['area'] =  $val['area'];
			$sk['pro_type'] =  $val['pro_type'];
			$sk['city'] =  $val['city'];
			$sk['id'] =  $val['id'];
			$sk['client_mobile'] =  $val['contact_number'];
			$sk['img1'] =  $val['img1'];
			$sk['pro_size'] = $val['company_name'];
			// $sk['size_type']=$val['size_type'];
			$sk['pro_code'] = $val['product_code'];
			// $sk['pro_code']=$val['product_code'];
			$skk[] = $sk;
		}
	}
	if ($cat_id == 5) {
		//  print_r($_POST);

		$ip = $db1->sql("SELECT `id`, `category`, `sub_cat`, `pro_type`, `client_name`, `client_whatsapp`, `client_mobile`, `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`, `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`, `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`, `user_upload_by`, `paid`, `date`, `edit_date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `edit_id`, `del`, `is_d`, `act`, `dtime`, `state`, `job_role`, `job_experience`, `job_salary`, `key_skils`, `place`, `offering_value`, `email`, `website`, `price`, `describtion`, `propriter_name`, `mail_id`, `pincode`, (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null    $search   order by id desc")->many();
		foreach ($ip as &$val) {
			//   =$val['job_role'];
			// $rolename=$db->sql("SELECT name FROM sm_main_form_11 WHERE value=" . $val["job_role"] . " and list_id=217 ")->one();           

			$sk['price_in_number'] =  $val['company_name'] . "in" . $val['city'];
			$sk['listing_for'] = $val['business_proof'];
			$sk['product_title'] =  $val['address'];
			$sk['area'] =  $val['area'];
			$sk['pro_type'] =  $val['pro_type'];
			$sk['city'] =  $val['city'];
			$sk['id'] =  $val['id'];
			$sk['client_mobile'] =  $val['contact_number'];
			$sk['img1'] =  $val['img1'];
			$sk['pro_size'] = $val['payment_mode'];
			// $sk['size_type']=$val['size_type'];
			$sk['pro_code'] = $val['product_code'];
			// $sk['pro_code']=$val['product_code'];
			$skk[] = $sk;
		}
	}
	if ($cat_id == 7) {
		//  print_r($_POST);

		$ip = $db1->sql("SELECT `id`, `category`, `sub_cat`, `pro_type`, `client_name`, `client_whatsapp`, `client_mobile`, `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`, `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`, `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`, `user_upload_by`, `paid`, `date`, `edit_date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `edit_id`, `del`, `is_d`, `act`, `dtime`, `state`, `job_role`, `job_experience`, `job_salary`, `key_skils`, `place`, `offering_value`, `email`, `website`, `price`, `describtion`, `propriter_name`, `mail_id`, `pincode`, (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null    $search   order by id desc")->many();
		// print_r($ip);
		foreach ($ip as &$val) {
			//   =$val['job_role'];
			$pro_for = $db->sql("SELECT name FROM sm_main_form_11 WHERE value=" . $val["mobile_brand"] . " and list_id=224 and del IS NULL")->one();

			$sk['price_in_number'] =  $pro_for['name'];
			$sk['listing_for'] = $val['seller_name'];
			$sk['product_title'] =  $val['description'];
			$sk['area'] =  $val['area'];
			$sk['pro_type'] =  $val['pro_type'];
			$sk['city'] =  $val['city'];
			$sk['id'] =  $val['id'];
			$sk['client_mobile'] =  $val['mobile_number'];
			$sk['img1'] =  $val['img1'];
			$sk['pro_size'] = $val['description'];
			// $sk['size_type']=$val['size_type'];
			$sk['pro_code'] = $val['product_code'];
			// $sk['pro_code']=$val['product_code'];
			$skk[] = $sk;
		}
	}
	echo json_encode($skk);
}
