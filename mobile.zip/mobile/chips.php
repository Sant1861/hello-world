<?php

ini_set('display_errors',1);
$cid = $_POST['cid'];
require_once("../index.php");
require_once(BASEPATH . 'config/autoloader.php');
require_once(BASEPATH . 'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);

extract($_REQUEST);
// $cid = 13051305;
// extract($_REQUEST);

$db1->sql("SET NAMES utf8")->execute();
$db->sql("SET NAMES utf8")->execute();
// echo"hiiiiiii;";
if ($type == 28) {
    if($sub_type==1){
    // $sel=$db1->sql("(select a.pro_id,a.pro_code,b.product_title,b.business_name,b.company_name from sm_main_form_1025 as a INNER JOIN add_property  as b on a.pro_id= b.id where a.pro_user='501' and a.user_id=500 group by a.pro_id);")->many();  
      $sel=$db1->sql("select a.pro_code,a.sub_cat,a.cat,a.pro_id,(select img_4 from sm_main_form_1009 as b where b.pro_id=a.pro_id limit 1) as img from sm_main_form_1048 as a where a.del is null group by a.cat_id order by order1 asc,a.id desc ")->many(); 
   
      echo json_encode($sel);
    }
    
    
    
 
    
    if($sub_type==2){
        
        function formatIndianNumber($number) {
                if ($number >= 10000000) {
                    return number_format(($number / 10000000), 2, '.', '') . ' Crore';
                } elseif ($number >= 100000) {
                    return number_format(($number / 100000), 2, '.', '') . ' Lac';
                } elseif ($number >= 1000) {
                    return number_format(($number / 1000), 2, '.', '') . ' K';
                } else {
                    return $number;
                }
            }
        
      



        //   print_r($_POST);
    $sel2=$db1->sql("select a.pro_code,a.sub_cat,a.cat,a.pro_id,(select img_4 from sm_main_form_1009 as b where b.pro_id=a.pro_id limit 1) as img from sm_main_form_1048 as a where a.del is null and a.cat_id=$category order by order1 asc,a.id desc ")->many(); 
  $sel= count($sel2);
   if($sel==0){
        $sel1=$db1->sql("SELECT 
                                a.pro_code,
                                a.sub_cat,
                                a.cat,
                                a.pro_id,
                                b.product_title,
                                b.product_size,
                                b.size_type,
                                b.area,
                                b.city,
                                b.price_in_alphabet,b.price_in_number,
                                (SELECT name FROM truebroker_new_1.sm_main_form_11 WHERE value = b.size_type AND list_id = 216 AND del IS NULL) AS size_type_name,
                                (
                                    SELECT img_4 
                                    FROM sm_main_form_1009 AS c 
                                    WHERE c.pro_id = a.pro_id 
                                    LIMIT 1
                                ) AS img 
                            FROM 
                                sm_main_form_1048 AS a 
                            INNER JOIN 
                                add_property AS b ON a.pro_id = b.id 
                            WHERE 
                                a.del IS NULL 
                            ORDER BY 
                                a.order1 ASC, a.id DESC;

                     ")->many(); 
                     foreach ($sel1 as &$item) {
                        $item['price_in_alphabet'] = formatIndianNumber($item['price_in_number']);
                    }



   }else$sel1 = $db1->sql("
    SELECT 
        a.pro_code,
        a.sub_cat,
        a.cat,
        a.pro_id,
        b.product_title,
        b.product_size,
        b.size_type,
        b.area,
        b.city,
       
        b.price_in_number,
        (
            SELECT name 
            FROM truebroker_new_1.sm_main_form_11 
            WHERE value = b.size_type 
            AND list_id = 216 
            AND del IS NULL
        ) AS size_type_name,
        (
            SELECT img_4 
            FROM sm_main_form_1009 AS c 
            WHERE c.pro_id = a.pro_id 
            LIMIT 1
        ) AS img 
    FROM 
        sm_main_form_1048 AS a 
    INNER JOIN 
        add_property AS b ON a.pro_id = b.id 
    WHERE 
        a.del IS NULL 
        AND a.cat_id = $category 
    ORDER BY 
        a.order1 ASC, 
        a.id DESC;
")->many();


foreach ($sel1 as &$item) {
    
     if($item['product_size']!=""){
                                     $pro_size_type = $db->sql("SELECT name FROM sm_main_form_11 WHERE value= '".$item["size_type"]."'  and list_id=216 and del IS NULL")->one();                    
                                                      if(preg_match('/[a-zA-Z]/', $item['product_size'])){
                                                        $prod=$item['product_size'];
                                                      }else{
                                                        $prod=$item['product_size'] . " " . $pro_size_type['name']; 
                                                      }
                                                  }else{
                                                      $prod="Size unspecified"; 
                                                  }
    $item['price_in_alphabet'] = formatIndianNumber($item['price_in_number']);
    $item['final_size'] = $prod;
}

echo json_encode($sel1);
}
}

?>