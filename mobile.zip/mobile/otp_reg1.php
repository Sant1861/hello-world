<?php
// ini_set("display_errors",1);
error_reporting(0);


//$cid=$_POST['cid'];

$cid='21472147';

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
// print_r($_POST);
// $type = $_POST['type'];
// $data=$_POST;
 if(isset($_POST['mobile'])&&($_POST['role_id'])) {
 
 
 extract($_POST);
 
//  print_r ($_POST);
 
 
 
      if($_POST['mobile']==9876543210 && $_POST['role_id']){
        $mobnum1=array('cid' => $cid,'role_id'=>$_POST['role_id'],'mobile'=>$_POST['mobile'],'lati'=>$_POST['lati'],'longt'=>$_POST['longt'],'dev_id'=>$_POST['dev_id'],'dev_loc'=>$_POST['dev_loc']);
     $qury1=$db->from('sm_main_form_104')->insert($mobnum1)->sql();
    //   echo $qury1;
    $result1=$db1->sql($qury1)->execute();
     $itemno = $db1->from('sm_main_form_104')->where('mobile',$_POST['mobile'])->where('role_id',$_POST['role_id'])->where('del #',null)->one();
  $ledid= $itemno['id'];
$cdate=date("Y-m-d");
  $mobnum2=array('cid' => $cid,'role_id'=>$_POST['role_id'],'date'=>$cdate,'mobile'=>$_POST['mobile'],'led_id'=>$ledid,'lati'=>$_POST['lati'],'longt'=>$_POST['longt'],'dev_id'=>$_POST['dev_id'],'dev_loc'=>$_POST['dev_loc']);
     $qury2=$db->from('sm_main_form_20')->insert($mobnum2)->sql();
        //   echo $qury2;
      $result2=$db->sql($qury2)->execute();
      include('../mobile/mobile_otp.php');
      
      }
      
    else{
    // echo $_POST['mobile'];
     //print_r($_POST);
     $item = $db->from('sm_main_form_20')->where('mobile',$_POST['mobile'])->where('del #',null)->one();
     $count = count($item);
    //  echo $count;
     if($count==0){
    //   print_r($_POST);
    
     $mobnum1=array('cid' => $cid,'role_id'=>$_POST['role_id'],'mobile'=>$_POST['mobile'],'lati'=>$_POST['lati'],'longt'=>$_POST['longt'],'dev_id'=>$_POST['dev_id'],'dev_loc'=>$_POST['dev_loc']);
     $qury1=$db->from('sm_main_form_104')->insert($mobnum1)->sql();
    //   echo $qury1;
    $result1=$db1->sql($qury1)->execute();
     $itemno = $db1->from('sm_main_form_104')->where('mobile',$_POST['mobile'])->where('role_id',$_POST['role_id'])->where('del #',null)->one();
  $ledid= $itemno['id'];
$cdate=date("Y-m-d");
  $mobnum2=array('cid' => $cid,'role_id'=>$_POST['role_id'],'date'=>$cdate,'mobile'=>$_POST['mobile'],'led_id'=>$ledid,'lati'=>$_POST['lati'],'longt'=>$_POST['longt'],'dev_id'=>$_POST['dev_id'],'dev_loc'=>$_POST['dev_loc']);
     $qury2=$db->from('sm_main_form_20')->insert($mobnum2)->sql();
        //   echo $qury2;
      $result2=$db->sql($qury2)->execute();
      include('../mobile/mobile_otp.php');
 }
 else{
    include('../mobile/mobile_otp.php'); 
 }
  }
  }
  ?>