<?
ini_set("display_errors",1);
$cid='1';

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$type = $_POST['type'];
$data=$_POST;


if($type==1){
    
    $companydetails=$db->sql("select * from sm_main_form_7 where del is null  order by id asc")->many();
    // echo $companydetails;
    echo json_encode($companydetails);
}
?>