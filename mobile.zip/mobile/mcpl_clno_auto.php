<?php
// Log..
// Mcpl Agent Cl No Autocomplete

ini_set("display_errors",1);
$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1=new Dbclass($cid);

$type=$_POST['type'];


if($type==9){



            $agent=$_POST['led_id'];
            // print_r($agent);
            $name=$_POST['name'];
            $data=$db1->sql("select  id as chit_id,sub_name as name,name as led_id,mobile,address,chit_no as cl_no,chit_sno as cl_sno,chit_sno as label,col_amount as balance from sm_main_form_1417 where del is null and cid=$cid and (chit_no LIKE '%".$name."%' or `sub_name` LIKE '%".$name."%' or `chit_sno` LIKE '%".$name."%' ) ")->many();
            
            foreach($data as &$d){
                
                
              
                $d['label']=$d['cl_no']." - ".$d['name']." - ".$d['cl_sno'];
                
                // $bal=$db1->sql("select sum(amount) as bal from sm_main_form_140 where chit_id='".$d['chit_id']."' and  trans_type not in (12,14,16,17,18) and date <= '".date('Y-m-d')."' and  del is null and status is null")->one();
                // $d['balance']=$bal['bal'];
                
                $d['balance']="0";
                
                
                
                    }
           echo json_encode($data);
           
           
  extract($_POST);         
            /*Start Request SAVE */
             $url="mcpl_clno_auto.php";
             $new=fopen("mcpl.txt",'a');
             date_default_timezone_set("Asia/Kalkata");
             $CURRENTDATE=date("Y-m-d H:i:s");

             $write=$CURRENTDATE."-".$cid."-".$type."-".$url."-".$agent;

             fwrite($new,$write);
             fwrite($new,"\r\n");
             fclose($new);
            
            /* End Request SAVE */
            
}










?>