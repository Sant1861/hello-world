
<?
$cid = $_POST['cid'];
ini_set("display_errors",0);
// $cid='21472147';

require_once('../index.php');
require_once(BASEPATH . 'config/autoloader.php');
require_once(BASEPATH . 'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user = new USER();
$date5 = date("Y-m-d");

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~api for Otp send~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if ($_POST['sub_type'] == 1) {
    if (isset($_POST['mobile']) && ($_POST['role_id'])) {


        $item = $db->from('sm_main_form_20')->where('mobile', $_POST['mobile'])->where('del #', null)->one();
        $count = count($item);

        if ($count == 0) {
            $mobnum1 = array('cid' => $cid, 'role_id' => $_POST['role_id'], 'mobile' => $_POST['mobile'], 'lati' => $_POST['lt'], 'longt' => $_POST['ln'], 'dev_id' => $_POST['device_id'], 'dev_loc' => $_POST['dev_loc']);
            $qury1 = $db->from('sm_main_form_104')->insert($mobnum1)->sql();
            //   echo $qury1;
            $result1 = $db1->sql($qury1)->execute();
            $itemno = $db1->from('sm_main_form_104')->where('mobile', $_POST['mobile'])->where('role_id', $_POST['role_id'])->where('del #', null)->one();
            $ledid = $itemno['id'];
            $cdate = date("Y-m-d");
            $mobnum2 = array('cid' => $cid, 'role_id' => $_POST['role_id'], 'date' => $cdate, 'mobile' => $_POST['mobile'], 'led_id' => $ledid, 'lati' => $_POST['lt'], 'longt' => $_POST['ln'], 'dev_id' => $_POST['device_id'], 'dev_loc' => $_POST['dev_loc']);
            $qury2 = $db->from('sm_main_form_20')->insert($mobnum2)->execute();
            $last_id = $db->insert_id;

            $coins = $db1->sql("select * from sm_main_form_1012 where reward_type=1 and del is null")->one();
            $ins = array('uid' => $data['id'], 'date' => date('Y-m-d'), 'cid' => $data['cid'], 'mobile' => $mobile, 'description' => "Welcome Bonus", 'user_id' => $last_id, 'coin' => $coins['coins']);

            $pn1 = $db->from("sm_main_form_20_1")->insert($ins)->execute();
            //   echo $qury2;
            // $result2 = $db->sql($qury2)->execute();
            include('../mobile/mobile_otp.php');
        } else {
            include('../mobile/mobile_otp.php');
        }
    } else {
        $data1["error"] = TRUE;
        $data1["error_msg"] = "WE DIDN'T GET YOUR MOBILE NUMBER";
        echo json_encode($data1);
    }
}
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~api fro Otp send end~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

// --------------------------------------------------------------------------------------------------confrim otp start-------------------------------------------------------------------------------------------------------
if ($_POST['sub_type'] == 2) {

    extract($_POST);

    if (!empty($mobile) && !empty($led_id) && $led_id != '0') {

        $check = $db->from('otp')->sortDesc('id')->where('mobile', $mobile)->where('led_id', $led_id)->where('status', 1)->where('cid', $cid)->select()->one();

        if ($otp === $check['otp']) {


            $data = $db->from('sm_main_form_20')->where('led_id', $led_id)->where('mobile',$mobile)->where('cid', $cid)->one();


            $check = $db1->sql("select email,f_name from sm_main_form_104 where del is null and mobile='" . $_POST["mobile"] . "'and role_id='" . $_POST["role_id"] . "' and f_name is not null and email is not null")->one();
            $check1 = count($check);

            $coincheck=$db->sql("select * from sm_main_form_20_2 where mobile='$mobile' and date='$date5'")->one();
            $coinch=count($coincheck);
            if($coinch==0){
                $coins = $db1->sql("select * from sm_main_form_1012 where reward_type=16 and del is null")->one();
            $ins = array('uid' => $data['id'], 'date' => date('Y-m-d'), 'cid' => $data['cid'], 'mobile' => $mobile, 'description' => "Daily Login Bonus", 'user_id' => $data['id'], 'coin' => $coins['coins']);

            $pn1 = $db->from("sm_main_form_20_1")->insert($ins)->execute();
            
            
             $ins1 = array('cid'=> $cid, 'uid'=> $data['id'],'user_id' => $data['id'], 'date'=>date('Y-m-d') , 'mobile'=>$mobile,'led_id'=>$led_id );

            $pn2 = $db->from("sm_main_form_20_2")->insert($ins1)->execute();
            }else{
            //   sm_main_form_20_2  
             $ins1 = array('cid'=> $cid, 'uid'=> $data['id'],'user_id' => $data['id'], 'mobile'=>$mobile,'date'=>date('Y-m-d') , 'led_id'=>$led_id );

            $pn2 = $db->from("sm_main_form_20_2")->insert($ins1)->execute();
            }
            
            if ($check1 > 0) {

                $data1['mobile'] = $data['mobile'];
                $data1['email'] = $check['email'];
                $data1['f_name'] = $check['f_name'];
                $data1['uid'] = $data['id'];
                $data1["error"] = "false";
                $data1["error_msg"] = "Already register";
            } else {

                $in = array('uid' => $data['id'], 'date' => date('Y-m-d'), 'cid' => $data['cid'], 'name' => $data['led_id'], 'mobile' => $mobile, 'device_id' => $device_id, 'cus_name' => $data['name']);

                $pn = $db1->from("sm_main_form_108")->insert($in)->execute();

                $data1['mobile'] = $data['mobile'];
                $data1['uid'] = $data['id'];
            }
        } 
        
        else {
            $data1["error"] = TRUE;
            $data1["error_msg"] = "Your Otp is Wrong!";
        }
    } else {
        $data1["error"] = TRUE;
        $data1["error_msg"] = "Required parameters  missing!";
    }

    echo json_encode($data1);
}

// --------------------------------------------------------------------------------------------------confrim otp End-------------------------------------------------------------------------------------------------------

?>