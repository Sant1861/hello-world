<?PHP
// ini_set('display_errors',1);
$cid=13051305;

 $ss="";
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db = new Dbclass();
$db1 = new Dbclass($cid);
$db1->sql("SET NAMES utf8")->execute();
extract($_POST);






if ($type == 39) {
    if($sub_type==1){
            $recent = $db1->sql("SELECT id,sub_cat,pro_type FROM sm_main_form_1002 WHERE del IS NULL AND category = 1")->many();
        
            foreach ($recent as &$r) {
                $subcat = $db1->sql("SELECT sub_category FROM sm_main_form_1001 WHERE del IS NULL AND id = '" . $r['sub_cat'] . "'")->one();
                $r['sub_cat'] = $subcat['sub_category']; 
            }
        
            echo json_encode($recent);
    }
    
    if($sub_type==2){
            $recent = $db->sql("SELECT name,value FROM sm_main_form_11 WHERE del IS NULL AND list_id = 193")->many();
        
            // foreach ($recent as &$r) {
            //     $subcat = $db1->sql("SELECT sub_category FROM sm_main_form_1001 WHERE del IS NULL AND id = '" . $r['sub_cat'] . "'")->one();
            //     $r['sub_cat'] = $subcat['sub_category']; 
            // }
        
            echo json_encode($recent);
    }
}
