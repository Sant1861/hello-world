
<?
$cid=$_POST['cid'];

// $cid='21472147';

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
// table for payment graph
if($_POST['sub_type']==1){
    
    $select=$db1->sql("select * from sm_main_form_1015 where del is null")->many();
     $data1["error"] = TRUE;
    $data1["error_msg"] = "allow to next page"; 
 echo json_encode($select);
}

if($_POST['sub_type']==2){
    extract($_POST);
    // print_r($_POST);
    
      $data1 = array('cid' => $cid,'user_id' => $uid,'f_name' => $f_name,'date'=>$payment_date,'time'=>$payment_time,'coin'=>$coins,'amount'=>$amount,'pay_id'=>$payment_id);
  $qury1=$db1->from('sm_main_form_1016')->insert($data1)->execute();
    
    $data2=array('cid'=>$cid,'user_id' => $uid,'coin'=>$coins,'date'=>$payment_date);
 $qury2=$db->from('sm_main_form_20_1')->insert($data2)->execute();
    
       $response['error']=False;
$response['error_mgs']="allow to next page";
  echo json_encode($response); 
}

?>