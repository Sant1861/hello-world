<?php

class FORM_FIELD 
{	

	private $conn;
	
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
	
    }
    
    

        
	public function fields($cid,$id,$col_name,$field_name,$field_type,$settings)
	{
	    $data3=array();
	             if($field_type ==  1  || $field_type == 2){
            
      
  
        $extra  = array('label'=>$col_name,'col_name'=>$field_name,'input_type'=>$field_type,'id'=>$id);
        
        
        }
        
	    
	   if($field_type ==  3 || $field_type ==  4 || $field_type == 10 || $field_type == 11 || $field_type == 14  || $field_type == 15 )
            {
    require_once('../index.php');
        require_once(BASEPATH.'config/autoloader.php');
        require_once(BASEPATH.'config/sysconfig.php');
        $db = new Dbclass();
        $db1= new Dbclass($cid);
        if($field_type == 3){
                 $extra =array('field_name'=>'Drop Down','id'=>$id);
        }
        if($field_type == 4){
                 $extra =array('field_name'=>'Sys Drop Down','id'=>$id);
        }
        if($field_type == 5){
                 
                 $log  = explode("|",$settings);
                 $type = $log[0];
                $fid      = $log[1];
                $id=$log[2];
                 $name = $log[3];
                 
                $extra  = array('fid'=>$fid,'type'=>$type,'id'=>$id,'name'=>$name,'id'=>$id);
        }
        if($field_type == 10){
                 $extra =array('field_name'=>'CheckBox','id'=>$id);
        }
        if($field_type == 11){
                 $extra =array('field_name'=>'Radio','id'=>$id);
        }
        if($field_type == 14){
                 $extra =array('field_name'=>'Multi Select','id'=>$id);
                 
        }
        if($field_type == 15){
                 $extra =array('field_name'=>'Save Button','id'=>$id);
        }
        
                $data3 = $this->OptionSelectList($cid,$id,$col_name,$field_name,$field_type,$settings);
                // $data3 = $cid.$col_name.$field_name.$field_type.$settings;

}
            
        
     elseif($field_type==8){
         
                 $extra =array('field_name'=>'Date','id'=>$id);
         
             }
  
          
            else
            {
                $extra = null;
            }
           
    $data=array('label'=>$col_name,'field_type'=>$field_type,'field_name'=>$field_name,'extra' =>$extra,'value' =>$data3);  
    return $data;
 
	
	}
	
	
	
    public function OptionSelectList($cid,$id,$col_name,$field_name,$field_type,$settings){
        
        
          require_once('../index.php');
        require_once(BASEPATH.'config/autoloader.php');
        require_once(BASEPATH.'config/sysconfig.php');
        $db = new Dbclass();
        $db1= new Dbclass($cid);
        
         $drop_array = array();
         
  
        if($field_type ==  3 || $field_type ==  4 || $field_type == 10 || $field_type == 11 || $field_type == 14 || $field_type == 15 ){
             
            
            $ft_value  = explode("|",$settings);
                $list = $ft_value[0];
			    $form = $ft_value[1];
			    $id= $ft_value[2];
			    $name = $ft_value[3];
			    $value='';
			 //   $where ="and `$name` like '%$value%' ";
			    
			      
			      
			    if($list == 2){  
			      
			    $stmt = $db1->sql("SELECT *,$name as label,$id as value FROM sm_main_form_$form WHERE del is null LIMIT 10")->many();
			 
		
      
        
            
            if($field_type==3)
            {
            $drop_array[] = array('id'=>0,'name'=>'select a Option'); }
            foreach($stmt as &$row){
           
               
            $drop_array[] = array('label'=>$row['label'],'value'=>$row['value']);
                                                                                                                   
            }
            
        }else{
            			 $stmt = $db->sql("SELECT * FROM sm_main_form_11  WHERE list_id='".$form."' AND del IS NULL ORDER BY list_order ASC ")->many();
            	foreach($stmt as &$row){
           
               
            $drop_array[]  = array('label'=>$row['name'],'value'=>$row['value']);
            
            }
        }
        
        }
return $drop_array;


}	

  
}



?>