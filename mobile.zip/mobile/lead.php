<?php
// ini_set("display_errors",1);
$cid = $_POST['cid'];
require_once("../index.php");
require_once(BASEPATH . 'config/autoloader.php');
require_once(BASEPATH . 'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
// extract($_REQUEST);
// $cid = 13051305;
extract($_REQUEST);

$db1->sql("SET NAMES utf8")->execute();

$date=date("Y-m-d");


// print_r($_POST);
// print_r($_FILES);
                             $target_dir = "../../uploads/lead/";
                             
                             $target_file1 = $target_dir . basename($_FILES["imageapi0"]["name"]);
                             
                             $imageFileType1 = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));

                             $mat_pic1 =$lastid1.'imageapi'.time().''.$i.'.'.$imageFileType1;

                             $target_file = $target_dir . $mat_pic1;

                             if (move_uploaded_file($_FILES["imageapi0"]["tmp_name"], $target_file)) {
                                //   echo "The file ". htmlspecialchars( basename( $_FILES["imageapi$i"]["name"])). " has been uploaded.";
                                //  print_r($_FILES);
                                  $wmgs1="https://truebroker.in/web_new/uploads/lead/$mat_pic1"; 
                                //   $data2=array('cid'=>$cid,'pro_id'=>$pid,'pro_img'=>$wmgs1);
                                //   $qury2=$db1->from('sm_main_form_103')->insert($data2)->execute(); 
                                //   echo "image upload sucessfull";
                              } 
                           
                            //  `id`, `aid`, `uid`, `bid`, `cid`, `number`, `w_number`, `photo`, `date`, `lead_by`, `del`, `is_d`, `act`, `dtime`
     
        $data1 = array('cid' => $cid,'bid' => $bid,'uid' => $uid,'aid' => $aid,'number' => $number,'w_number'=>$w_number,'photo'=>$wmgs1,'date'=>$date,'lt'=>$lt,'ln'=>$ln);
        $qury1=$db1->from('sm_main_form_1036')->insert($data1)->execute();
        // echo $qury1;
    // $result1=$db1->sql($qury1)->execute();
     
    //   $last_id11=$db1->insert_id;
// echo json_encode()
// $w_number

if($w_number==""){
    $w_number1=$number;
}else{
   $w_number1=$w_number; 
}
$nameuid=$db->sql("select * from sm_main_form_20 where del is null and id=$uid")->one();
$fnme=$nameuid['f_name'];
$mobi_name=$nameuid['mobile'];
$img="https://truebroker.in/msg/tb001.jpg";
	$img1="https://truebroker.in/msg/cp.png";
//  $imggg=$img.$img;
	$msg="Dear sir/mam, thank you for choosing Truebroker. We appreciate your support and value your satisfaction. Our dedicated team is here to assist you. Best regards, $fnme at [TrueBroker]. contact Us :$mobi_name";
	$msg1="Kindly Know More About Us https://truebroker.in And Download App From http://surl.li/jmvyt Contact Us:9047834783";
	$data_sms=array('cid'=>$cid, 'mobile'=>$w_number1, 'caption'=>$msg,'message'=>$img,'temp_id'=>1);
	 $qury1=$db->from('send_wsms')->insert($data_sms)->execute();
// 	$data_sms1=array('cid'=>$cid, 'mobile'=>$w_number1, 'caption'=>$msg1,'message'=>$img1,'temp_id'=>1);
// 	 $qury1=$db->from('send_wsms')->insert($data_sms1)->execute();





            if($qury1==true){
             $response["error"] = false;
             $response["error_msg"] = " Register successfully";
             }
             else{
               $response["error"] = true;
             $response["error_msg"] = " something went Wrong";  
             }
	echo json_encode($response);






?>