<?php
ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);

$type = $_POST['type'];
$data=$_POST;


/* Route Chart report */

if($type==1){
    
    
     $agent=$data['agent'];
     $sdate=date('Y-m-d',strtotime($data['sdate']));
     $edate=date('Y-m-d',strtotime($data['edate']));
     $route =$data['route'];
    
    
    
     /*start request save*/ 
     $url="route_chat.php";
    //  $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." CID :" . $data['cid'] ." TYPE : " . $data['type']." URL  : ".$url."  AGENT  : ".$agent." FROM  : ".$sdate."  TO : ".$edate."   ROUTE ID  :".$route  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
    //   print_r($_POST);
      
    // extract($_POST);
    
    $response = array();
    
    // $rts=$db1->sql("select * from sm_main_form_1410 where del is null and id='".$route."' ")->one();
    
    // $ts=$rts['name'];
    
    // $response[]=" $ts OLLECTION DETAILS FROM $sdate to $edate ";
    
    $data6 = array('SNO','NAME','GROUP','CHITID','T_NO','DATE','AMOUNT','PHONE');


     
          
         
     $tb = $db1->sql("SELECT  sum(amount) as amt,name,led_id,chit_id,mobile,date FROM sm_main_form_1419 where cid='$cid'  and agent='".$agent."' and route='".$route."' and  `date` BETWEEN '".date('Y-m-d',strtotime($sdate))."' and '".date('Y-m-d',strtotime($edate))."' and del is null   group by   chit_id  order by name ")->many();
                //  echo $tb;
                   $i=1;
                   
                   
                   
                   foreach($tb as &$sa){
                       
                       $ss=$db1->sql("select * from sm_main_form_1417 where del is null and id='".$sa['chit_id']."'  ")->one();
                       
                       $data4[]= array('SNO'=>"$i",'NAME'=>$sa['name'],'GROUP'=>$ss['gname'],'CHITID'=>$sa['chit_id'],'T_NO'=>$ss['t_no'],'DATE'=>date('d-m-Y',strtotime($sa['date'])),'AMOUNT'=>$sa['amt'],'PHONE'=>$sa['mobile']);
       
       
        $total += abs($sa['amt']);
                    $i++;
                   }
                   $data4[]=array('SNO'=>"",'NAME'=>"",'GROUP'=>"",'CHITID'=>"",'T_NO'=>"",'DATE'=>"TOTAL",'AMOUNT'=>"$total",'PHONE'=>"");
    
    // $response['header1'] = $data2;
    $response['header'] = $data6;
    $response['cont'] = $data4;

  echo json_encode($response);

}










