<?php  
/*SAVE QUERY*/
// ini_set("display_errors",1);
$cid=$_POST['cid'];

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
$type = $_POST['type'];
$data=$_POST;

if($data['sub_type']==1){
   
// print_r($data);

    /* Role id check */
    if($data['role_id'] != '' && $data['role_id'] !='0'  ){
        
        $check=$db->sql("select * from sm_main_form_20 where del is null and mobile='".$data["mobile"]."' ")->one();
        $a=$check['led_id'];
      
     //print_r($a);
      
      $ldata=array('cid'=>$data["cid"],'f_name'=>$data["f_name"],'address'=>$data["address"],'email'=>$data["email"],'state'=>$data["state"],'city'=>$data["city"],'dist'=>$data['dist']);
        $ledinsert=$db1->from('sm_main_form_104')->where('id',$a)->update($ldata)->execute();
     
      $ldata1=array('cid'=>$data["cid"],'f_name'=>$data["f_name"],'address'=>$data["address"],'email'=>$data["email"],'state'=>$data["state"],'city'=>$data["city"],'dist'=>$data['dist'],'register_status'=>'mobile');
      $ledinsert1=$db->from('sm_main_form_20')->where('led_id',$a)->update($ldata1)->execute();
    //   echo"hiiiiiiiiii";
    //   coin form
    //   $check1=$db->sql("select * from sm_main_form_20 where del is null and mobile='".$data["mobile"]."' and id='".$check['id']."'")->one();
    //   $coins=$db1->sql("select * from sm_main_form_1012 where del is null and reward_type=1")->one();
       
    //   $ldata2=array('cid'=>$check1["cid"],'f_name'=>$check1["f_name"],'mobile'=>$check1['mobile'],'address'=>$check1["address"],'email'=>$check1["email"],'state'=>$check1["state"],'city'=>$check1["city"],'dist'=>$check1['dist'],'coin'=>$coins['coins'],'user_id'=>$check1['id'],'date'=>date("Y-m-d"));
    //   $ledinsert1=$db->from('sm_main_form_20_1')->insert($ldata2)->execute();
      
    
    $response["error"] = 'FALSE';
    $response['role_id']=$data['role_id'];
     $response['f_name']=$data['f_name'];
      $response['email']=$data['email'];
      $response['coin']=$ldata2['coin'];
  $response["error_msg"] = " Register successfully";
  echo json_encode($response);
    
     
      
    }
    
    
    else{
       $response["error_msg"] ="Required parameters  missing!"; 
       echo json_encode($response);
    }

 }
 else {
    // required post params is missing
    $response["error"] = TRUE;
	
    $response["error_msg"] ="Required parameters  missing!";
    
}


?>