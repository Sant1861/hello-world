<?
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();

extract($_POST);
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~api for coin start~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

if($sub_type=='1'){
    // print_r($_POST);
    if($uid!=''){
    $sel=$db->sql("SELECT sum(coin) as coin1 FROM sm_main_form_20_1 WHERE user_id=$uid group by user_id")->one();
    
                  $data['coin'] = $sel['coin1'];
			     $data['uid']=$sel['user_id'];
         $data["error"]= "TRUE";
         $data["error_msg"] = "Login Successfull";
         
}
else{
     $data["error"]= TRUE;
		 $data["error_msg"] = "Your User Id Is  missing!";
}
echo json_encode($data);
}
?>