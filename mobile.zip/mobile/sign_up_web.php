<?
// ini_set('display_errors', 1);
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$cid =$_REQUEST['cid'];
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
$response = array();
// $type = $_POST['type'];
// $data=$_POST;
extract($_POST);
// print_r($_POST);
 $date=date('Y-m-d');
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Login Register~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if($sub_type==1){
  
    if($mobile!='' && $email!='' && $password!=''){
        $check=$db->sql("select count(mobile)as ccount from sm_main_form_20 WHERE del is null and mobile=$mobile")->one();
       $count1=$check['ccount'];
        // echo $count.'prem';
        if($count1==0){
            
    
      
  $ldata=array('cid'=>$cid,'date'=>$date,'f_name'=>$f_name,'address'=>$address,'role_id'=>1,'mobile'=>$mobile,'email'=>$email,'state'=>$state,'city'=>$city,'dist'=>$dist,'u_name'=>$user_name,'password'=>$password,'dev_id'=>$device_id,'dev_loc'=>$dev_loc,'lati'=>$lt,'longt'=>$ln);
       $ledinsert=$db1->from('sm_main_form_104')->insert($ldata)->execute();
     $last_id=$db1->insert_id;
     
     
     
      $ldata1=array('cid'=>$cid,'date'=>$date,'f_name'=>$f_name,'address'=>$address,'role_id'=>1,'mobile'=>$mobile,'email'=>$email,'state'=>$state,'city'=>$city,'dist'=>$dist,'register_status'=>'web','u_name'=>$user_name,'password'=>$password,'led_id'=>$last_id,'dev_id'=>$device_id,'dev_loc'=>$dev_loc,'lati'=>$lt,'longt'=>$ln);
  $ledinsert1=$db->from('sm_main_form_20')->insert($ldata1)->execute();
 $last_id1=$db->insert_id;
      
      
      
      
      
      
       $check1=$db->sql("select * from sm_main_form_20 where del is null and mobile=$mobile and id=$last_id1")->one();
       $coins=$db1->sql("select * from sm_main_form_1012 where del is null and reward_type=1")->one();
       
      $ldata2=array('cid'=>$check1["cid"],'date'=>$date,'led_id'=>$last_id1,'f_name'=>$check1["f_name"],'mobile'=>$check1['mobile'],'u_name'=>$check1['u_name'],'address'=>$check1["address"],'email'=>$check1["email"],'state'=>$check1["state"],'city'=>$check1["city"],'dist'=>$check1['dist'],'coin'=>$coins['coins'],'description'=>"Welcome Bonus",'user_id'=>$last_id1,'date'=>date("Y-m-d"));
    $ledinsert1=$db->from('sm_main_form_20_1')->insert($ldata2)->execute();
      
    
      $response["error"] = false;
    // $response['role_id']=$data['role_id'];
      $response['f_name']=$f_name;
      $response['email']=$email;
      $response['coin']=$ldata2['coin'];
      $response['uid']=$check1['id'];
      $response["error_msg"] = " Register successfully";
  
         $data1['mobile'] = $data['mobile'];
		 $data1['uid']=$data['id'];
   
        }
       
        
        else{
            
            
             $check=$db->sql("select * from sm_main_form_20 WHERE del is null and mobile=$mobile ")->one();
            
            
            // update email and password for already user
            
             $data1 = array('f_name'=>$user_name,'address'=>$address,'role_id'=>1,'email'=>$email,'state'=>$state,'city'=>$city,'dist'=>$dist,'register_status'=>'web','u_name'=>$user_name,'password'=>$password,);
             $result=$db->from('sm_main_form_20')->where('id',$check['id'])->update($data1) ->execute();
            
            $response['f_name']=$check['f_name'];
            $response['uid']=$check['id'];
            $response["error"] = true;
             $response["error_msg"] = "Already User";
  
        }
        
        echo json_encode($response);
    }
    // else{
    //     $response["error"] = true;
    //     $response["error_msg"] = "Something Went Wrong";
    // }
    
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ email login ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

if($sub_type=='2'){
    // echo "hiiiiiiiii";
    
    if($user!='' && $password!=''){
        // echo "hiiiiiiiii";
        
     $check=$db->sql("select * from sm_main_form_20 WHERE del is null and email='".$user."' and password='".$password."'")->one();
    $countt=count($check);
        if($countt!=0){
            
      
         $response['f_name']=$check['f_name'];
         $response['uid']=$check['id'];
         $response['mobile']=$check['mobile'];
         $response["error"] = false;
         $response["error_msg"] = "Allow To Next Page";
         
         $data1['mobile'] = $data['mobile'];
		 $data1['uid']=$data['id'];    
             
    }
    // else{
        
    //         $response["error"] = true;
    //          $response["error_msg"] = "Email and password didn't match";
    // }
    echo json_encode($response);
}
    
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Forget password~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if($sub_type==3){
    // echo "hiiiiiiiii";
    
    if($mobile!='' &&  $email!='' && $password!=''){
        // echo "hiiiiiiiii";
        
     $check=$db->sql("select * from sm_main_form_20 WHERE del is null and email='".$email."' and mobile='".$mobile."'")->one();
    $countt=count($check);
        if($countt!=0){
             $data1 = array('password'=>$password);
  $result=$db->from('sm_main_form_20')->where('id',$check['id'])->update($data1) ->execute();
  $result1=$db1->from('sm_main_form_104')->where('mobile',$mobile)->where('email',$email)->update($data1) ->execute();
      
         $response['f_name']=$check['f_name'];
            $response['uid']=$check['id'];
            $response["error"] = false;
             $response["error_msg"] = "Allow To Next Page";
             
         $data1['mobile'] = $data['mobile'];
		 $data1['uid']=$data['id'];
		 
    }
    // else{
        
    //         $response["error"] = true;
    //          $response["error_msg"] = "Email and password didn't match";
    // }
    echo json_encode($response);
}
    
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ email valiadation ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

if($sub_type==4){
   
    
    if($email!=''){
        
        
     $check=$db->sql("select * from sm_main_form_20 WHERE del is null and email='".$email."'")->one();
    $countt=count($check);
        if($countt!=0){
             
      
      
            $response["error"] = true;
             $response["error_msg"] = "Already Exist";
    }
    else{
        
            $response["error"] = false;
             $response["error_msg"] = "ok";
    }
    echo json_encode($response);
}
    
}


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~







// if($result2=true){
//      $response["error"] = TRUE;
//     $response["error_msg"] = "Signup Sucess Full";
// }
//     }

// else {
    
//     $response["error"] = TRUE;
//     $response["error_msg"] = "user password missing!";
    
//     $new=fopen("sch_login.txt",'a');
//         $CURRENTDATE=date("Y-m-d H:i:s"); 
//         $write= $CURRENTDATE  ." - " .json_encode($_POST)."-".$response["error_msg"];;
//         fwrite($new,$write);
//         fwrite($new,"\r\n");
//         fclose($new);
// // 		exit();
   
// } 

// echo json_encode($response);
?>