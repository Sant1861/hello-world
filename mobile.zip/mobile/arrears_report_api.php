<?php 
ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);

$type = $_POST['type'];
$data=$_POST;
//print_r($_POST);


 //Arrears-Report
if($type==1) 
{
    extract($_POST);
  
//          if($data['agent'] != null) {
             
//               $route_name=$data['route'];
//     $date=$data['date'];
//  $agent_name= $data['agent'];
 
//               /*start request save*/ 
//      $url="arrears_report_api.php";
//      $r_t=$data['request'];
//       date_default_timezone_set('Asia/Kolkata');
//     $new=fopen("log.txt",'a');
//     $CURRENTDATE=date("Y-m-d H:i:s"); 
//     $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url ." - ".$route_name." - ".$date  ." - ".$agent_name ;
    
    
//     fwrite($new,$write);
//     fwrite($new,"\r\n");
//     fclose($new);
//       /* end request save*/
      
      
      
//       $response = array();
    
//     $data6 = array('SNO','NAME','GROUPID','TD','DUE','COLL','DIVID','ARREARS','LDR','AGENT','ROUTE','PHONE');    
           
             
 
//           $ndate = date('Y-m-d',strtotime($date));
                   
//                   $cond='';
         
//             if(!empty($agent_name)){
//                 $cond .=" and agent='".$agent_name."' ";
//             }
//             if(!empty($route_name)){
//                 $cond .=" and route='".$route_name."' ";
//             } 
//             if($ndate){
//                 $cond .=" and td_date <='".$ndate."' ";
//             } 

//                   if($cid=='68363582'){  $tb = $db1->sql("SELECT date,name,agent,gp_tno,gname,t_no,td_date,ch_value,id,temp_id,route,ch_type FROM sm_main_form_1417 where  `paid` LIKE 'Y' AND pay_type NOT IN ('Final','Cancel After Group','Cancel Before Group') $cond   AND cid=$cid  ORDER BY ch_type ASC  ")->many(); 
//                 //   echo $tb;
                      
//                   }else{  
//                   $tb = $db1->sql("SELECT date,name,agent,gp_tno,td_date,ch_value,id,temp_id,gname,t_no,route,ch_type FROM sm_main_form_1417 where  `paid` LIKE 'Y' AND `pay_type` IN ('Regular','Advance','Adjustment')  $cond   AND cid=$cid  ORDER BY ch_type ASC ")->many();
//                   }
                  
//                   $i=1;
//                 //   print_r($tb);
//                 // echo $tb;
//   foreach($tb as &$sa){

//                       $agent = $sa['agent'];
                      
//                   $agent = $db1->from('sm_main_form_1401')->where('id',$agent)->where('cid',$cid)->where('del #',null)->one();
//                 //   print_r($agent);
//                   $name = $db1->from('sm_main_form_1401')->where('id',$sa['name'])->where('cid',$cid)->where('del #',null)->one();
               
//                   $collect = $db1->sql("select sum(amount) as collectamt,MAX(date) AS date from sm_main_form_140 where led_id='".$sa['name']."' AND chit_id='".$sa['id']."' and trans_type NOT IN (13,15) and cid=$cid and del is null ORDER BY date DESC")->one();
             
                
//     $route = $db1->sql("SELECT name as route FROM `sm_main_form_1410` WHERE id='".$sa['route']."' AND del is null")->one();
//     $route= $route['route'];

//                     //   $collect = $db1->sql("select sum(amount) as collectamt,MAX(date) AS date from sm_main_form_140 where led_id='".$sa['name']."' AND chit_id='".$sa['id']."' and trans_type not in (13,15) and date <= '".$ndate."' and cid=$cid and del is null")->one();
//               $div_amt = $db1->sql("select sum(amount) as div_amt from sm_main_form_140 where led_id='".$sa['name']."' AND chit_id='".$sa['id']."' and trans_type = '15'   AND status is null   and date <= '".date('Y-m-d',strtotime($date))."' and cid=$cid and del is null")->one();
//             //   echo $div_amt;
//               $due_amt = $db1->sql("select sum(amount) as due_amt from sm_main_form_140 where led_id='".$sa['name']."' AND chit_id='".$sa['id']."' and trans_type = '13'  and date <= '".date('Y-m-d',strtotime($date))."' and cid=$cid and del is null")->one();
               
//               $div_amt = abs($div_amt['div_amt']);
              
//                 $due_amt = abs($due_amt['due_amt']);
//               $col_amount =  abs($collect['collectamt']);
               
//                  $total = abs($col_amount) + abs($div_amt);
//                   $balance = $due_amt - $total;
                  
                  
//                     //  $tc = abs($collect['collectamt']) + abs($dividend['collectamount']) + $adjus + $journal;
//                     //  $arrers = abs($sa['ch_value']) - $tc;
//                 //  print_r($arrers);
//                   if( $balance > 0) {
                      
//                     $data4[]= array('SNO'=>"$i",'NAME'=>$name['name'],'GROUPID'=>$sa['gp_tno'],'TD'=> date('d-m-Y',strtotime($sa['td_date'])),'DUE'=>"$due_amt",'COLL'=>"$col_amount",'DIVID'=>"$div_amt",'ARREARS'=>"$balance",'LDR'=>date('d-m-Y',strtotime($collect['date'])),'AGENT'=>$agent['name'],'ROUTE'=>$route,'PHONE'=>$name['mobile']);
                    
                    
//                     $dueamt+=$due_amt;
//                     $ctot += abs($col_amount);
//                     $dtot += abs($div_amt);
//                     $tr += $balance;
//                      $i++;
// }
//   }
//   $data4[]=array('SNO'=>"",'NAME'=>"",'GROUPID'=>"",'TD'=>"Total",'DUE'=>"$dueamt",'COLL'=>"$ctot",'DIVID'=>"$dtot",'ARREARS'=>"$tr",'LDR'=>"",'AGENT'=>"",'ROUTE'=>"",'PHONE'=>"");
  
//   $response['header'] = $data6;
//     $response['cont'] = $data4;

//   echo json_encode($response);
             
             
             
             
//          }else{
             
           $route_name=$data['route'];
    $date=$data['date'];
 $agent_name= $data['agent'];
 
              /*start request save*/ 
     $url="arrears_report_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[1" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." menu :  " . $r_t." Url :  ".$url ." Route :  ".$route_name." date : ".$date  ." Agent ".$agent_name ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
      
      
      $response = array();
    
    $data6 = array('SNO','NAME','GROUPID','TD','DUE','COLL','DIVID','ARREARS','LDR','AGENT','ROUTE','PHONE');    
           
             
 
           $ndate = date('Y-m-d',strtotime($date));
                   
                  $cond='';
         
            if(!empty($agent_name) && $agent_name !='0'){
                $cond .=" and agent='".$agent_name."' ";
            }
            if(!empty($route_name) && $route_name !='0'){
                $cond .=" and route='".$route_name."' ";
            } 
            if($ndate){
                $cond .=" and td_date <='".$ndate."' ";
            } 

                  if($cid=='68363582'){  $tb = $db1->sql("SELECT date,name,agent,gp_tno,gname,t_no,td_date,ch_value,id,temp_id,route,ch_type FROM sm_main_form_1417 where  `paid` LIKE 'Y' AND pay_type NOT IN ('Final','Cancel After Group','Cancel Before Group') $cond   AND cid=$cid  ORDER BY ch_type ASC  ")->many(); 
                //   echo $tb;
                      
                  }else{  
                  $tb = $db1->sql("SELECT date,name,agent,gp_tno,td_date,ch_value,id,temp_id,gname,t_no,route,ch_type FROM sm_main_form_1417 where  `paid` LIKE 'Y' AND `pay_type` IN ('Regular','Advance','Adjustment')  $cond   AND cid=$cid  ORDER BY ch_type ASC ")->many();
                  }            
                  $i=1;
                //   print_r($tb);
                // echo $tb;
  foreach($tb as &$sa){

                       $agent = $sa['agent'];
                      
                  $agent = $db1->from('sm_main_form_1401')->where('id',$agent)->where('cid',$cid)->where('del #',null)->one();
                //   print_r($agent);
                  $name = $db1->from('sm_main_form_1401')->where('id',$sa['name'])->where('cid',$cid)->where('del #',null)->one();
               
                  $collect = $db1->sql("select sum(amount) as collectamt,MAX(date) AS date from sm_main_form_140 where  chit_id='".$sa['id']."' and trans_type NOT IN (12,13,14,15,16,17,18,23) and cid=$cid and del is null and status IS NULL ORDER BY date DESC")->one();
             
                
    $route = $db1->sql("SELECT name as route FROM `sm_main_form_1410` WHERE id='".$sa['route']."' AND del is null")->one();
    $route= $route['route'];

                    //   $collect = $db1->sql("select sum(amount) as collectamt,MAX(date) AS date from sm_main_form_140 where led_id='".$sa['name']."' AND chit_id='".$sa['id']."' and trans_type not in (13,15) and date <= '".$ndate."' and cid=$cid and del is null")->one();
               $div_amt = $db1->sql("select sum(amount) as div_amt from sm_main_form_140 where led_id='".$sa['name']."' AND chit_id='".$sa['id']."' and trans_type = '15'   AND status is null   and date <= '".date('Y-m-d',strtotime($date))."' and cid=$cid and del is null")->one();
            //   echo $div_amt;
               $due_amt = $db1->sql("select sum(amount) as due_amt from sm_main_form_140 where led_id='".$sa['name']."' AND chit_id='".$sa['id']."' and trans_type = '13'  and date <= '".date('Y-m-d',strtotime($date))."' and cid=$cid and del is null")->one();
               
               $div_amt = abs($div_amt['div_amt']);
              
                $due_amt = abs($due_amt['due_amt']);
               $col_amount =  abs($collect['collectamt']);
               
                 $total = abs($col_amount) + abs($div_amt);
                  $balance = $due_amt - $total;
                  
                    $running = $db1->sql("select sum(amount) as running_amt from sm_main_form_140 where  chit_id='".$sa['id']."' and trans_type not in (12,14,16,17,18)  and  del is null and status is null")->one();
                    //  $tc = abs($collect['collectamt']) + abs($dividend['collectamount']) + $adjus + $journal;
                    //  $arrers = abs($sa['ch_value']) - $tc;
                //  print_r($arrers);
                  if( $balance > 0) {
                      
                    $data4[]= array('SNO'=>"$i",'NAME'=>$name['name'],'GROUPID'=>$sa['gp_tno'],'TD'=> date('d-m-Y',strtotime($sa['td_date'])),'DUE'=>"$due_amt",'COLL'=>"$col_amount",'DIVID'=>"$div_amt",'ARREARS'=>$running['running_amt'],'LDR'=>date('d-m-Y',strtotime($collect['date'])),'AGENT'=>$agent['name'],'ROUTE'=>$route,'PHONE'=>$name['mobile']." - ".$name['phone']);
                    
                    
                    $dueamt+=$due_amt;
                    $ctot += abs($col_amount);
                    $dtot += abs($div_amt);
                    $tr += $balance;
                     $i++;
}
  }
  $data4[]=array('SNO'=>"",'NAME'=>"",'GROUPID'=>"",'TD'=>"Total",'DUE'=>"$dueamt",'COLL'=>"$ctot",'DIVID'=>"$dtot",'ARREARS'=>"$tr",'LDR'=>"",'AGENT'=>"",'ROUTE'=>"",'PHONE'=>"");
  
  $response['header'] = $data6;
    $response['cont'] = $data4;

  echo json_encode($response);
        //  }
    

}

if($type==2){
    
     /*start request save*/ 
     $url="arrears_report_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
    
       $route =  $db1->sql("SELECT id,name from sm_main_form_1410 where del is NULL")->many();
       
     echo json_encode($route);
}

?>

                   
                    