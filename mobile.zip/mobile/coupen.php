<?php
/*SAVE QUERY*/
// ini_set("display_errors",1);
$cid=21472147;

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
$type = $_POST['type'];
$data=$_POST;


if($type==15){

                $coupen= $db1->from('sm_main_form_107')->where('del', null)->many();
             
               



 echo json_encode($coupen);  


}
 
 if($type==18){ 

        $coupen= $db1->from('sm_main_form_115')->one();
             
               



 echo json_encode($coupen);  
 }  

if($type==19){


						 $qu= $db1-> sql("SELECT b.id,b.pro_name,b.city,b.pro_price,b.land_mark,a.pro_id,b.sts_name,a.pro_img FROM sm_main_form_102 as b INNER JOIN sm_main_form_103 as a ON a.pro_id = b.id WHERE a.upcoming=1 and b.upcoming=1 and (a.del is null) and (b.del is null) GROUP BY a.pro_id ORDER BY id DESC LIMIT 5 ")->many();
			
  
echo json_encode($qu);

}




