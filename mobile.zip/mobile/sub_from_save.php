<?php 


// ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$response=array();
// print_r($_POST);


if($_POST['sub_type']=1){
    // echo "prem";
    // print_r($_POST);
    
     $data1=$_POST;
      $ip = json_decode($data1['data'][0], true);
    //   print_r($ip);
    $cp=  count($ip);
    // echo $cp;
    for($i=0;$i<$cp;$i++){
        // echo $ip[$i];
       $bbb= explode("-",$ip[$i]);
    //   print_r($bbb);
       $ins1=array('mid'=>$data1['last_id'],'ans'=>$bbb[1],'ques'=>$bbb[0]);
  	$d=$db1->from("add_property_1")->insert($ins1)->execute();
    }
     $sel=$db1->sql("select * from add_property_1 where mid='".$data1['last_id']."'")->many();
    // print_r($sel);
    foreach($sel as $sel1){
        // echo $sel1['ques'].'<br>'.$sel1['ans'];
        // echo "hiiiiii1";
  $up=$db1->sql("select * from sm_main_form_1003 where name='".$sel1['ques']."' ")->one();
//   echo "hiiiiii2";
//   print_r($up);
        $data5=array('ques_id'=>$up['id']);
         $result=$db1->from('add_property_1')->where('id',$sel1['id'])->update($data5)->execute();
    }
    
    $dd= $data1['last_id'];
    
    
    	$sel = $db1->sql("select * from add_property where id=$dd")->one();
	if ($sel['category'] == 1) {
		$name = $sel['client_name'];
		$phone = $sel['client_whatsapp'];
	} elseif ($sel['category'] == 2) {

		$name = $sel['customer_name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 3) {

		$name = $sel['name'];
		$phone = $sel['contact_no'];
	} elseif ($sel['category'] == 4) {

		$name = $sel['name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 5) {

		$name = $sel['company_name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 7) {

		$name = $sel['seller_name'];
		$phone = $sel['mobile_number'];
	} else {
		$uid = $sel['uid'];
		$sel = $db->sql("select * from sm_main_form_20 where id=$uid")->one();
		$name = $sel['f_name'];
		$phone = $sel['mobile'];
	}
	$code = $sel['product_code'];
	$yearr = 2023;

	$sms = "Dear," . " " . $name . " Thankyou For Choosing Truebroker,Your Registration Is Completed,Please Verify Your Entred Details Whether Correct Or Not Through The Url,And Pls Click Publish Button On My Listing Page For Listing On Our Site And APP Listing., Your url is https://truebroker.in/listing_detail?id=$code Any Queries Contact 7448812555";
	$wsms = array('cid' => $cid, 'mobile' => $phone, 'message' => $sms);
	$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();

$scall=$db1->sql("select * from sm_main_form_1024 where del is null")->many();

	foreach ($scall as $call) {

// 		$numw = $call['w_num'];


		$sms1 = "Dear team one property uploaded now property name is," . " " . $code. " and url is  https://truebroker.in/listing_detail?id=$code please check and approval it";

		$wsms = array('cid' => $cid, 'mobile' => $call['mobile'], 'message' => $sms1);
		$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();
	}

    
    
    
    
    
    
    
    
    $response["error"] = FALSE;
    $response["error_msg"] = "Save Sucessfully";
    $response["last_id"] = $dd;
  echo json_encode($response); 
    
    
    //   $ipp=$ip[0];
    //   print_r($ipp);
    // //   print_r($data1['data'][0]);
    //  $cc= count($data1['data'][0]);
    // // $bb= explode(":",);
    // $bb1= explode(",",$data1['data'][0]);
    // $newstr = str_replace("[{}]"," ", $bb1, $cc);  
    // print_r($newstr);
    // echo $newstr;
    // $bb2= explode("",$bb1);
    
}