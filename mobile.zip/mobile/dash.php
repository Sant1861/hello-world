<?php
/*SAVE QUERY*/
// ini_set("display_errors",1);
$cid=21472147;

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
$type = $_POST['type'];
$data=$_POST;


if($type==16){

                $dash= $db1->from('sm_main_form_110')->where('del', null)->where('upcoming',1)->many();
             
               



 echo json_encode($dash);  


}
    
    
if($type==17){

                $dash= $db1->from('sm_main_form_110')->where('del', null)->where('upcoming',2)->many();
             
               



 echo json_encode($dash);  


}
   
 