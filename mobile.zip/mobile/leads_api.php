<?php
$cid = $_POST['cid'];
require_once("../index.php");
require_once(BASEPATH . 'config/autoloader.php');
require_once(BASEPATH . 'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);

extract($_REQUEST);
// $cid = 13051305;
// extract($_REQUEST);

$db1->sql("SET NAMES utf8")->execute();
$db->sql("SET NAMES utf8")->execute();
// echo"hiiiiiii;";
if ($type == 27) {
    if($sub_type==3){
//   $sel=$db1->sql("select user_name,user_id,mobile from sm_main_form_1025 where pro_user='$uid'and pro_id=$pro_id group by user_id")->many();
   $sel=$db1->sql("select a.user_name,a.user_id,a.mobile,a.pro_id,(select b.product_code from add_property as b where a.pro_id=b.id)as code from sm_main_form_1025 as a where a.pro_user='$uid'and a.pro_id='$pro_id' group by a.user_id; ")->many();
    foreach($sel as &$sel1){
        if($sel1['user_name']==""){
            
            $ins=$db->sql("select * from sm_main_form_20 where del is null and id='".$sel1['user_id']."'")->one();
            $sel1['user_name']=$ins['email'];
        }
        
    }
    echo json_encode($sel);
    }
    
    
    
 
    
    if($sub_type==2){
        //   print_r($_POST);
    $sel=$db1->sql("(select a.pro_id,a.pro_code,b.product_title,b.business_name,b.company_name from sm_main_form_1025 as a INNER JOIN add_property  as b on a.pro_id= b.id where a.pro_user='501' and a.user_id=500 group by a.pro_id);")->many();  
       
   
      echo json_encode($sel);
    }
    
    
    if($sub_type==1){
        $sel=$db1->sql("SELECT a.id,a.product_code,DATE_FORMAT(a.approved_date, '%d-%m-%Y') as date,a.product_title,a.vehicle_name,a.company_name,(select b.img_og from sm_main_form_1009 as b where b.del is null and b.pro_id=a.id limit 1) as img,(select count(DISTINCT(c.user_id)) from sm_main_form_1025 as c where c.pro_user=a.uid and c.pro_id=a.id ) as count FROM `add_property` as a where a.uid=$uid and a.del is null and a.pro_view=1")->many();
        echo json_encode($sel);
    }
}

?>