<?PHP
$data = $_POST;
$type = $data['type'];
// $cid=21472147;
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
//  print_r($_POST);
$db = new Dbclass();
$db1 = new Dbclass($cid);
extract($_POST);
  


if($type==38){
    
      $wishArray = array();
     
  $message=$db1->sql("select * from add_property where del is null and uid='".$uid."' order by id desc ")->many();
  
  foreach($message as $miss){
       $cat=$db1->sql("select * from sm_main_form_1000 where del is null and id='".$miss['category']."' ")->one();
            
                                                      $sub_cat=$db1->sql("select * from sm_main_form_1001 where del is null and id='".$miss['sub_cat']."' ")->one();
            
                                                      $pro_type=$db1->sql("select * from sm_main_form_1002 where del is null and id='".$miss['pro_type']."' ")->one();
                                                      
            								          $imge=$db1->sql("select * from sm_main_form_1009 where del is null and pro_id='".$miss['id']."' group by pro_id  ")->one();
            								         
            								         
            								           $wishArray[] = array('pro_id' => $miss['id'],'product_title'=>$miss['product_title'],'category'=>$cat['category'],'sub_category'=>$sub_cat['sub_category'],'pro_type'=>$pro_type['pro_type'],
            								           'product_code' => $miss['product_code'],'client_name' => $miss['client_name'],'price' => $miss['price_in_number'],'address' => $miss['city'],'date' => $miss['date'],'img'=>$imge['img_1']);
  }
  echo json_encode($wishArray);
}