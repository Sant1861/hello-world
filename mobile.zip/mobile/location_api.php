<?php 
ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);

$type = $_POST['type'];
$data=$_POST;
//print_r($_POST);
$cdate=date('Y-m-d');

if($type==1){
    
    /*start request save*/ 
     
     $url="location_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
      
      
    //  print_r($data);
    
     $name = $data['name'];
     
     $led = $db1->sql("select name,id as cusid from sm_main_form_1401 where del is null and cid=$cid and (name like '%".$name."%' ) ")
    ->many();
foreach($led as &$d)
{
    $d['name'] = $d['name'];
}
echo json_encode($led);
}

if($type==2){
    
     /* request save*/ 
     $r_t=$data['request'];
      date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
    
//   if($data['cusid']==)
     
 $data = array('cid'=>$data['cid'],'uid'=>$data['uid'],'cusid'=>$data['cusid'],'name'=>$data['name'],'latitude'=>$data['latitude'],'longitude'=>$data['longitude']);
       $data1 =  $db1->from('sm_main_form_1448')
             ->insert($data)
             ->execute();
             
                    
        
          
            if($data1==true){
          $response['error']=false;
          $response['error_msg']="Location Saved successfully";
            }
            else {
                 $response['error']=true;
          $response['error_msg']="Error";
            }
            echo json_encode($response);
   
             
            // echo $data1;
         
    //$db1->sql($data1)->execute();
    
}

if($type==3){
    
    /* request save*/ 
     $r_t=$data['request'];
      date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
    
    
    // print_r($data);
    $led_id=$data['cusid'];
    $retrive_location=$db1->sql("SELECT name,latitude,longitude FROM sm_main_form_1448 where del is NULL and cusid='$led_id' ")->one();
    
    // if($retrive_location==true){
    //       $response['error']=false;
    //       $response['error_msg']="success";
    //         }
    //         else {
    //              $response['error']=true;
    //       $response['error_msg']="Error";
    //         }
            // echo json_encode();
   echo json_encode($retrive_location);
}
    

?>