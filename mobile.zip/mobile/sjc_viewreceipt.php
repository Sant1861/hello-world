<?php
ini_set("display_errors",1);

$cid=$_POST['cid'];
 $con2 = mysqli_connect('localhost','softuser','Soft@2021',"s_".$cid); 

$type = $_POST['type'];
$data=$_POST;



if($type==3){
    $a=array();
    $cdate=date('Y-m-d');
    $cus=$data['uid'];
    // print_r($data);
    
    $view_receipt="SELECT date_format(a.collectdt, '%d-%m-%Y') as date,a.collectamt as collectamt,a.acno as acno,a.modepay as modepay,a.actype as actype,a.receiptno as receiptno,a.palmtec_id as palmtec_id,b.name as name FROM transact as a INNER JOIN master as b ON a.acno=b.accountno where a.collectdt='$cdate' and a.palmtec_id='$cus' ORDER BY a.receiptno DESC limit 20";
    
$result = mysqli_query($con2,$view_receipt);
while($row1 = mysqli_fetch_array($result, MYSQLI_ASSOC))

  {
      $a[]=$row1;

  }
    echo json_encode($a);
     

}



?>
