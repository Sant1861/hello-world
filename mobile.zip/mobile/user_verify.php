<?php 
ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
// $db1 = new Dbclass($cid);

$type = $_POST['type'];
$data=$_POST;

/*user_verify for user login
company_id is parameter */

if($type==1){
     $admin =  $db->from('sm_main_form_20')->where('user_id',$data['user'])->where('cid',$data['company_id'])->where('password',$data['password'])->where('del #',null)->many();

          if($admin==true){
          $response['error']=true;
          $response['error_msg']="User already exist";
            }
          else {
          $response['error']=false;
          $response['error_msg']="user not registered";  
          }
  echo json_encode($response);
   
}

//company_id verify
if($type==2){
    //  $company_id =  $db->from('sm_main_form_20')->where('cid',$data['company_id'])->where('del #',null)->many();
     
    //  if($company_id==true){
    //      $response['error']=false;
    //      $response['error_msg']="done";
    //  }
    //   else {
    //       $response['error']=true;
    //       $response['error_msg']="Company_id not match";  
    //       }
    //       echo json_encode($response);
    
    
 $response =  $db->from('sm_main_form_7')->where('id',$data['company_id'])->select(array('cid','name'))->where('del #',null)->one();
     
     if($response==true){
         $response['error']=false;
         $response['error_msg']="done";
     }
      else {
          $response['error']=true;
          $response['error_msg']="Company_id not match";  
          }
          echo json_encode($response);
    
    
    
}

?>