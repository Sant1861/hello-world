
<?
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();

extract($_POST);
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~api for coin start~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

if($sub_type=='1'){
    // print_r($_POST);
    if($uid!=''){
    $sel=$db->sql("SELECT sum(coin) as coin1 FROM sm_main_form_20_1 WHERE user_id=$uid group by user_id")->one();
    
                  $data['coin'] = $sel['coin1'];
			     $data['uid']=$sel['user_id'];
         $data["error"]= "TRUE";
         $data["error_msg"] = "Login Successfull";
         
}
else{
     $data["error"]= TRUE;
		 $data["error_msg"] = "Your User Id Is  missing!";
}
echo json_encode($data);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~api for coin end~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~debit for coin view~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


if($sub_type=='2'){
    // print_r($_POST);
    if($uid!='' && $pro_id !=''){
$val    = $db1->sql("SELECT * FROM add_property WHERE id=$pro_id and del IS NULL")->one();
    
    $sts =$db->sql("select * From `sm_main_form_20_1` where user_id='$uid' and pro_id='$pro_id' and del is null")->many();
    
    
    if(count($sts)==0){
        // print_r($_POST);
        $sel=$db1->sql("select * from sm_main_form_1012 where reward_type=3 and del is null")->one();
        $pkcoins=$sel['coins'];
    $sk    = $db->sql("INSERT INTO `sm_main_form_20_1`(`date`,`user_id`,`coin`,`pro_id`) VALUES ('".date('Y-m-d')."',$uid,-$pkcoins,$pro_id)")->execute();
             $data1["error"]= False;
		 $data1["error_msg"] = "Coin debited"; 
    
    }
            $data1["error"]= False;
		 $data1["error_msg"] = "allow to next page"; 
    
}
else{
     $data1["error"]= TRUE;
		 $data1["error_msg"] = "Your User Id or product id Is  missing!";
}
echo json_encode($data1);
}



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~debit for coin view end~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~coin view check~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



if($sub_type=='3'){
    // print_r($_POST);
    if($uid!='' && $pro_id !=''){
        
        
    $sts =$db->sql("select * From `sm_main_form_20_1` where user_id='$uid' and pro_id='$pro_id' and del is null")->many();
    
    
    if(count($sts)==0){
        
         $data1["error"]= "False";
		 $data1["view"] =0;
		 $data1["error_msg"] = "no coin reduced";
}
else{
         $data1["error"]= "False";
		 $data1["view"] =1;
		 $data1["error_msg"] = "Alredy coin reduced";
}
echo json_encode($data1);
}
}




//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~coin view check~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~coinviews~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


if($sub_type=='4'){
    // print_r($_POST);
    
        
        
 $sts =$db1->sql("select a.reward_type,a.coins,b.reward_type as types,b.id From `sm_main_form_1012`as a INNER JOIN sm_main_form_1013 as b where b.id=a.reward_type and b.del is null and a.del is null")->many();
    
    
    
     
echo json_encode($sts);

}


?>