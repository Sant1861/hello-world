<?php 
ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);

$type = $_POST['type'];
$data=$_POST;
//print_r($_POST);

//Machine entry api for Receipt
if($type==1){
      
      /* 'ef'=>2
     is mobile save  entry different */
     
 $data = array('date'=>date('Y-m-d',strtotime($data['date'])),'cid'=>$data['cid'],'ef'=>2,'aid'=>$data['aid'],'uid'=>$data['uid'],'led_id'=>$data['led_id'],'name'=>$data['name'],'mobile'=>$data['mobile'],'address'=>$data['address'],'chit_id'=>$data['chit_id'],'balance'=>$data['balance'],'amount'=>$data['amount'],'p_type'=>$data['p_type'],'pay_acc'=>$data['pay_acc'],'route'=>$data['route'],'col_type'=>$data['col_type'],'agent'=>$data['agent'],'refr'=>$data['refr']);
       $data1 =  $db1->from('sm_main_form_1419')
             ->insert($data)
             ->execute();
             
            // echo $data1;
            if($data1==true){
          $response['error']=false;
          $response['error_msg']="Receipt Insert successfully";
            }
            else {
                 $response['error']=true;
          $response['error_msg']="Data Not Insert";
            }
            echo json_encode($response);
    //$db1->sql($data1)->execute();         
}


// Machine entry api save query for payment menu
if($type==2){
    
    $target_dir = "../../image/payment image/";
$target_file1 = $target_dir . basename($_FILES["image"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));

$filename = rand(11111,99999).".".$imageFileType;
$target_file = $target_dir . $filename;
// Check if image file is a actual image or fake image

//   if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
//     echo "The file ". htmlspecialchars( basename( $_FILES["image"]["name"])). " has been uploaded.";
//   } else {
//     echo "Sorry, there was an error uploading your file.";
//   }
$data['image'] = $filename;


/* 'ef'=>2
     is mobile save  entry different */
    
$d=array('date'=>date('Y-m-d',strtotime($data['date'])),'cid'=>$data['cid'],'ef'=>2,'aid'=>$data['aid'],'uid'=>$data['uid'],'amount'=>$data['amount'],'p_type'=>$data['p_type'],'image'=>$filename,'acc_no'=>$data['acc_no'],'remark'=>$data['remark']);
    
    $save=$db1->from('sm_main_form_1420')
               ->insert($d)
             ->execute();
           // echo $save;
             
            
            if($save==true){
          $response['error']=false;
          $response['error_msg']="Payment Saved successfully";
            }
            else {
                 $response['error']=true;
          $response['error_msg']="Payment Not Saved";
            }
            echo json_encode($response);
   
    
}

//Machine entry api save query for Enquiry menu
//  if($type==3){
     
//      /* 'ef'=>2
//      is mobile save  entry different */
     
//      $dr=array('cid'=>$data['cid'],'ef'=>2,'aid'=>$data['aid'],'name'=>$data['user_id'],'amount'=>$data['amount'],'ch_value'=>$data['ch_value'],'email'=>$data['email'],'mobile'=>$data['mobile'],'address'=>$data['address']);
//      $enquiry= $db1->from('sm_main_form_1437')
//                   ->insert($dr)
//                   ->execute();
//                   //echo $enquiry;
                   
//                     if($enquiry==true){
//           $response['error']=false;
//           $response['error_msg']="Inserted successfully";
//             }
//             else {
//                  $response['error']=true;
//           $response['error_msg']="Data Not Insert";
//             }
//             echo json_encode($response);
   
                   
//  }



?>
