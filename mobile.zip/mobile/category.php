<?php 

ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();

$db1=new Dbclass($cid);

extract($_REQUEST);

if($type == 4){
    
if($sub_type == 1){ //category
    
$lw = $db1->from('sm_main_form_1000')->where('del #',null)->where('cid',$cid)->select(array('category as label','id as value'))->many();

echo json_encode($lw);

}

if($sub_type == 2) { //sub_category
    $lw = $db1->from('sm_main_form_1001')
               ->where('del #', null)
               ->where('category', $cat_id)
               ->where('cid', $cid)
                ->where('id !@', array(29,33))
               ->select(array('sub_category as label','id as value'))
               ->many();
    
    foreach($lw as &$l) {
        $img = $db1->sql("select * from sm_main_form_1508 where del is null and category='".$l['value']."'")->one();
        if($img['image']!=""){
        $l['img'] = $img['image'];
        }else{
             $l['img'] ="";
        }
        
    }
    
    echo json_encode($lw);
}


if($sub_type == 3){ //pro_type
    $lw = $db1->from('sm_main_form_1002')->where('del #',null)->where('category',$cat_id)->where('sub_cat',$sub_cat_id)->where('cid',$cid)->select(array('pro_type as label','id as value'))->many();
    
    
    
     foreach($lw as &$l) {
        $img = $db1->sql("select * from sm_main_form_1507 where del is null and pro_type='".$l['value']."'")->one();
        if($img['app_img']!=""){
        $l['img'] = $img['app_img'];
        }else{
             $l['img'] ="";
        }
        
    }
    echo json_encode($lw);
}

}
?>