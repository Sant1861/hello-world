 <?php
/*SAVE QUERY*/
//  ini_set("display_errors",1);
$cid=21472147;

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
$type = $_POST['type'];
$data=($_POST);
if($type=1){
// print_r($data);
// print_r($_FILES);


	$partner_id=$data['id'];
      
     

//  [name] => Array
//           (
//               [name] => 1 sgs.pdf
//               [type] => multipart/form-data
//               [tmp_name] => /tmp/phpSSrH4s
//               [error] => 0
//               [size] => 163568
//           )
//   )

  
      
      
     
     #retrieve file title
        // $title = $_POST["title"];
    #file name with a random number so that similar dont get replaced
     $pname = $partner_id."-".$_FILES["name"]["name"];
    #temporary file name to store file
    $tname = $_FILES["name"]["tmp_name"];
     #upload directory path
    $uploads_dir = '../uploads/all_in_one/';
    #TO move the uploaded file to specific location
    move_uploaded_file($tname, $uploads_dir.'/'.$pname);
    #sql query to insert into database
    
    
    
 
    
    
    
      $data1 = array('aid'=>$data['aid'],'uid'=>$data['uid'],'bid'=>$data['bid'],'cid'=>$data['cid'],'partner_id'=>$partner_id,'all_in_one'=>$pname);
  $qury1=$db1->from('sm_main_form_135')->insert($data1)->execute();
  if($qury1==TRUE){
   $response['error']=FALSE;
 $response['error_mgs']=" upload sucessfull";
  }
  
  else{
       $response['error']=TRUE;
 $response['error_mgs']="something went wrong";
  }
  
echo json_encode($response);
    
}
?>