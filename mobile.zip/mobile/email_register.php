<?


/*SAVE QUERY*/
// ini_set("display_errors",1);
$cid=$_POST['cid'];

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
// $type = $_POST['type'];
// $data=$_POST;
extract($_POST);
if($sub_type==1){
    
    if($mobile!='' && $email!='' && $password!=''){
        $check=$db->sql("select count(mobile)as ccount from sm_main_form_20 WHERE del is null and mobile=$mobile")->many();
        $count1=$check['ccount'];
        
        if($count1!=0){
        //             $check=$db->sql("select * from sm_main_form_20 where del is null and mobile='".$data["mobile"]."' ")->one();
        // $a=$check['led_id'];
      
     //print_r($a);
      
      $ldata=array('cid'=>$data["cid"],'f_name'=>$data["f_name"],'address'=>$data["address"],'email'=>$data["email"],'state'=>$data["state"],'city'=>$data["city"],'dist'=>$data['dist'],'password'=>$data['password']);
        $ledinsert=$db1->from('sm_main_form_104')->insert($ldata)->execute();
     $last_id=$db->insert_id;
      $ldata1=array('cid'=>$data["cid"],'f_name'=>$data["f_name"],'address'=>$data["address"],'email'=>$data["email"],'state'=>$data["state"],'city'=>$data["city"],'dist'=>$data['dist'],'register_status'=>'mobile','password'=>$data['password'],'led_id'=>$last_id);
      $ledinsert1=$db->from('sm_main_form_20')->insert($ldata1)->execute();
    //   echo"hiiiiiiiiii";
    //   coin form
    $last_id1=$db->insert_id;
       $check1=$db->sql("select * from sm_main_form_20 where del is null and mobile=$mobile and id=$last_id1")->one();
       $coins=$db1->sql("select * from sm_main_form_1012 where del is null and reward_type=1")->one();
       
      $ldata2=array('cid'=>$check1["cid"],'f_name'=>$check1["f_name"],'mobile'=>$check1['mobile'],'address'=>$check1["address"],'email'=>$check1["email"],'state'=>$check1["state"],'city'=>$check1["city"],'dist'=>$check1['dist'],'coin'=>$coins['coins'],'user_id'=>$last_id1,'date'=>date("Y-m-d"));
      $ledinsert1=$db->from('sm_main_form_20_1')->insert($ldata2)->execute();
      
    
    $response["error"] = 'FALSE';
    $response['role_id']=$data['role_id'];
     $response['f_name']=$data['f_name'];
      $response['email']=$data['email'];
      $response['coin']=$ldata2['coin'];
  $response["error_msg"] = " Register successfully";
  echo json_encode($response);
        }
    }
    
}



?>