<?php

$cid = $_POST['cid'];
require_once("../index.php");
require_once(BASEPATH . 'config/autoloader.php');
require_once(BASEPATH . 'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
ini_set("display_errors",1);
extract($_REQUEST);
// $cid = 13051305;
// extract($_REQUEST);

$db1->sql("SET NAMES utf8")->execute();
$db->sql("SET NAMES utf8")->execute();
// print_r($_POST);
$t=time();
if ($type == 29) {
if($sub_type==1){
        // print_r($_POST);
        // print_r($_FILES);
        
            $check=$db->sql("select * from sm_main_form_20 WHERE del is null  and id='".$uid."'")->one(); 
    
    
    $filesize=$_FILES["photo"]["size"]; 
    
   $f="https://truebroker.in/web_new/uploads/user_photo/"; 
     if($filesize==0){
        //  echo "prem";
      $target_file1=$check['photo'];
 }
 else{
      $target_dir = "../../uploads/user_photo/";
        $target_file1 = $target_dir . basename($_FILES["photo"]["name"]);
        $img=basename($_FILES["photo"]["name"]);
        $file_name=explode(".",$img);
        $imageFileType = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
         $mat_pic1 = $t.".".$imageFileType;
        $target_file = $target_dir.$mat_pic1;
        $target_file1 = $f.$mat_pic1;
        $mat_pic2=$f.$mat_pic1;
             // Valid extension
                 $valid_ext = array('png','jpeg','jpg');
                 // Check extension
                 if(in_array($imageFileType,$valid_ext)){
                 // Compress Image
                 compressImage($_FILES['photo']['tmp_name'],$target_file,60);
                 
                 }  
 }
 
 if($password!=""){
     $pass=$password;
 }else{
     $pass=$check['password'];
 }
 if($email!=""){
     $email1=$email;
 }else{
     $email1=$check['email'];
 }

//   echo $chk1;
 $data1 = array('f_name'=>$full_name,'email'=>$email1,'photo'=>$target_file1,'password'=>$pass);
  $result=$db->from('sm_main_form_20')->where('id',$check['id'])->update($data1) ->execute();
    if($result==true){
   $response["error"] = FALSE;
    $response["error_msg"] = "Save Sucessfully"; 
 
    }else{
        $response["error"] = TRUE;
    $response["error_msg"] = "Some thin went wrong"; 
    }  
    echo json_encode($response);
}

if($sub_type==2){
  $check=$db->sql("select * from sm_main_form_20 WHERE del is null  and id='".$uid."'")->one();  
//   if(){}

$response['name']=$check['f_name'];
$response['photo']=$check['photo'];
 echo json_encode($response);
}
    
}



function compressImage($source, $destination, $quality) {

  $info = getimagesize($source);

  if ($info['mime'] == 'image/jpeg') 
    $image = imagecreatefromjpeg($source);

  elseif ($info['mime'] == 'image/gif') 
    $image = imagecreatefromgif($source);

  elseif ($info['mime'] == 'image/png') 
    $image = imagecreatefrompng($source);

  imagejpeg($image, $destination, $quality);

} 

?>