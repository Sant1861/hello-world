<?php
ini_set("display_errors",1);
error_reporting(0);


$cid=13051305;

// $cid='21472147';

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
// print_r($_POST);
// $type = $_POST['type'];
// $data=$_POST;
// print_r("$_POST");
// echo $_POST['mobile']."prem";
extract($_REQUEST);

$t=time();

 if($type==1)
  {
    //   print_r($_REQUEST);
//  Array ( [id] => 9952264103 [cid] => 13051305 [type] => 1 )
            // echo"sk";
            
           
         $otp = $user->generateotp(6);

        //  $name1 = $db1->from('sm_main_form_104')->where('id',$item['led_id'])->where('del #',null)->one();
        //  $mobile=$name1['mobile'];
        //  $name = $name1['name'];
        $name="Customer";
         $phone = $id;
//   $phone = $mobile;
  
	$msg = "<#> SMART: Dear $name ,Your OTP number for login is $otp Don't share this code with others By SMART $tok";
  
  $sid ="";
$thu= $user->sendsms_api($phone,$msg,$_POST['cid'],17);
 $pna = $db->from('sm_main_form_7')->where('cid',$_POST['cid'])->one();
 	$in = array('date'=>date('Y-m-d'),'led_id'=>$item['led_id'],'cid'=>$_POST['cid'],'mobile'=>$phone,'otp'=>$otp,'device_id'=>$device_id,'test'=>$thu);
 	$ins = $db->from('otp')->insert($in)->execute();
 	
//          $data = array('mobile'=>$phone);
//          $data['cid'] = $_POST['cid'];
          
//             $data['role_id'] = $item['role_id'];
//          $data['uid'] =$item['id'];
//          $data['led_id'] =$item['led_id'];
//          $data['comp_name'] = $pna['name'];
//          //$data = array('id'=>5);
//          	$data["error"]= FALSE;
// 		 $data["error_msg"] = "Allow to next page";
		  
       $data="success";
     
             echo json_encode($data);
  }
 if($type==2){
    //  print_r($_REQUEST);
     
    $check = $db->sql("select count(id)as count from otp where mobile=$mobile and otp=$otp")->one();
      
      if($check['count']>0){
          $data=1;
      }
      else{
           $data=2;
      }
       echo json_encode($data);
 }
 
  if($type==3){
    //  print_r($_REQUEST);
     
     $pro_idd=$db1->sql("select * from add_property where del is null and product_code=$pro_code")->one();
     if($_FILES["verify_pic"]["size"]>0){
      $target_dir = "../uploads/verification_pic/";
     $target_file1 = $target_dir . basename($_FILES["verify_pic"]["name"]);
     $img=basename($_FILES["verify_pic"]["name"]);
     $file_name=explode(".",$img);
     $imageFileType = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
     $mat_pic1 = $t.".".$imageFileType;
     $target_file = $target_dir.$mat_pic1;
     // Valid extension
     $valid_ext = array('png','jpeg','jpg');
     // Check extension
     if(in_array($imageFileType,$valid_ext)){
     // Compress Image
     compressImage($_FILES['verify_pic']['tmp_name'],$target_file,60);
     
}}
$agent=array ('aid'=>$aid, 'uid'=>$uid, 'bid'=>$bid, 'cid'=>$cid, 'agent_name'=>$name, 'agent_id'=>$agent_id, 'pro_id'=>$pro_idd['id'], 'pro_code'=>$pro_code, 'cust_mobile'=>$mobile, 'otp_verified'=>$otp2, 'date_verified'=>$date, 'verifiy_pic'=>$target_file);
   $qury1=$db1->from('sm_main_form_1028')->insert($agent)->execute();
   $add_pro=array('verified_by'=>$agent_id,'first_approve'=>1);
      $result =$db1->from('add_property')
            	 ->where(array('product_code' => $pro_code))
                ->update($add_pro)
                ->execute();
   
    $data=1;
 echo json_encode($data);
 }
 
   
  // Compress image
function compressImage($source, $destination, $quality) {

  $info = getimagesize($source);

  if ($info['mime'] == 'image/jpeg') 
    $image = imagecreatefromjpeg($source);

  elseif ($info['mime'] == 'image/gif') 
    $image = imagecreatefromgif($source);

  elseif ($info['mime'] == 'image/png') 
    $image = imagecreatefrompng($source);

  imagejpeg($image, $destination, $quality);

}
  ?>                                      