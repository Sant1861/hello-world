<?php

$cid = $_POST['cid'];
require_once("../index.php");
require_once(BASEPATH . 'config/autoloader.php');
require_once(BASEPATH . 'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
ini_set("display_errors",1);
extract($_REQUEST);
// $cid = 13051305;
// extract($_REQUEST);

$db1->sql("SET NAMES utf8")->execute();
$db->sql("SET NAMES utf8")->execute();
print_r($_POST);
if($type==33){
//     if($sub_type==1){
//         function haversineDistance($lat1, $lon1, $lat2, $lon2) {
//     $earthRadius = 6371000; // Radius of the Earth in meters

//     $lat1Rad = deg2rad($lat1);
//     $lon1Rad = deg2rad($lon1);
//     $lat2Rad = deg2rad($lat2);
//     $lon2Rad = deg2rad($lon2);

//     $dLat = $lat2Rad - $lat1Rad;
//     $dLon = $lon2Rad - $lon1Rad;

//     $a = sin($dLat / 2) * sin($dLat / 2) + cos($lat1Rad) * cos($lat2Rad) * sin($dLon / 2) * sin($dLon / 2);
//     $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

//     $distance = $earthRadius * $c; // Distance in meters
// echo $distance;
//     return $distance;
// }



// $sel1=$db1->sql("select * from add_property where del is null and pro_view=1 and latitude !='' and logitute !='' ")->many();

// foreach($sel1 as $s){
// $location_a = array($s['latitude'], $s['logitute']);
// $location_b = array(11.007916454450001, 77.02674701261071);

// $distance = haversineDistance($location_a[0], $location_a[1], $location_b[0], $location_b[1]);

// if ($distance > 30) {
//     echo "location_b is more than 100 meters away from location_a.";
// } else {
//     echo "location_b is within 100 meters of location_a.";
// }

//     }
    
//     }
    
    
//     if ($sub_type == 2) {
//         function haversineDistance($lat1, $lon1, $lat2, $lon2) {
//             $earthRadius = 6371000; // Radius of the Earth in meters

//             $lat1Rad = deg2rad($lat1);
//             $lon1Rad = deg2rad($lon1);
//             $lat2Rad = deg2rad($lat2);
//             $lon2Rad = deg2rad($lon2);

//             $dLat = $lat2Rad - $lat1Rad;
//             $dLon = $lon2Rad - $lon1Rad;

//             $a = sin($dLat / 2) * sin($dLat / 2) + cos($lat1Rad) * cos($lat2Rad) * sin($dLon / 2) * sin($dLon / 2);
//             $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

//             $distance = $earthRadius * $c; // Distance in meters

//             return $distance;
//         }

//         $sel1 = $db1->sql("select * from add_property where del is null and pro_view = 1 and latitude != '' and logitute != ''  order by id desc limit 10 ")->many();

//         foreach ($sel1 as $s) {
//             $location_a = array(11.007916454450001, 77.02674701261071);
//             $location_b = array(11.007916454450001, 77.02674701261071);

//             $distance = haversineDistance($location_a[0], $location_a[1], $location_b[0], $location_b[1]);

//             if ($distance > 100) {
//                 echo "good Response: location_b is more than 100 meters away from location_a."."<br>";
//             } else {
//                 echo "bad Response: location_b is within 100 meters of location_a."."<br>";
//             }
//         }
//     }
    
    
//     if ($sub_type == 3) {
//     $badResponse = false; // Flag to track if a location within 100 meters is found

//     function haversineDistance($lat1, $lon1, $lat2, $lon2) {
//         $earthRadius = 6371000; // Radius of the Earth in meters

//         $lat1Rad = deg2rad($lat1);
//         $lon1Rad = deg2rad($lon1);
//         $lat2Rad = deg2rad($lat2);
//         $lon2Rad = deg2rad($lon2);

//         $dLat = $lat2Rad - $lat1Rad;
//         $dLon = $lon2Rad - $lon1Rad;

//         $a = sin($dLat / 2) * sin($dLat / 2) + cos($lat1Rad) * cos($lat2Rad) * sin($dLon / 2) * sin($dLon / 2);
//         $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

//         $distance = $earthRadius * $c; // Distance in meters

//         return $distance;
//     }

//     $sel1 = $db1->sql("select * from add_property where del is null and pro_view = 1 and latitude != '' and logitute != '' order by id desc limit 10")->many();

//     foreach ($sel1 as $s) {
//         $location_a = array($s['latitude'], $s['logitute']);
//       print_r($location_a) ;
//         $location_b = array(11.007916454450001, 77.02674701261071);

//         $distance = haversineDistance($location_a[0], $location_a[1], $location_b[0], $location_b[1]);
// echo $distance."<br>";
//         if ($distance < 100) {
//             // If a location within 100 meters is found, set the flag to true
//             $badResponse = true;
//             break; // Exit the loop early as a "bad" response is found
//         }
//     }

//     if ($badResponse) {
//         echo "Bad Response: At least one location is within 100 meters of location_a.";
//     } else {
//         echo "Good Response: No location is within 100 meters of location_a.";
//     }
// }
    if ($sub_type == 4) {
    $badResponse = false; // Flag to track if a location within 100 meters is found

    function haversineDistance($lat1, $lon1, $lat2, $lon2) {
        $earthRadius = 6371000; // Radius of the Earth in meters

        $lat1Rad = deg2rad($lat1);
        $lon1Rad = deg2rad($lon1);
        $lat2Rad = deg2rad($lat2);
        $lon2Rad = deg2rad($lon2);

        $dLat = $lat2Rad - $lat1Rad;
        $dLon = $lon2Rad - $lon1Rad;

        $a = sin($dLat / 2) * sin($dLat / 2) + cos($lat1Rad) * cos($lat2Rad) * sin($dLon / 2) * sin($dLon / 2);
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

        $distance = $earthRadius * $c; // Distance in meters

        return $distance;
    }

    $sel1 = $db1->sql("select id,latitude,logitute from add_property where del is null and pro_view = 1 and latitude != '' and logitute != '' order by id desc ")->many();
print_r($sel1);
   foreach ($sel1 as $s) {
    $location_a = array($s['latitude'], $s['logitute']);
    // print_r($location_a);

    $location_b = array($lt, $ln);

    $distance = haversineDistance($location_a[0], $location_a[1], $location_b[0], $location_b[1]);
    // echo "Distance: " . $distance . " meters<br>";

    if ($distance < 100) {
        // If a location within 100 meters is found, set the flag to true
        $badResponse = true;
        break; // Exit the loop early as a "bad" response is found
    }
}


    if ($badResponse) {
        echo "Bad Response: At least one location is within 100 meters of location_a.";
    } else {
        echo "Good Response: No location is within 100 meters of location_a.";
    }
}

    
    
    
}



?>