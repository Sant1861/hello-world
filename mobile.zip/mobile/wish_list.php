<?php 
$cid=$_POST['cid'];
require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db= new Dbclass();
$db1=new Dbclass($cid);
ini_set("display_errors",0);
$citys="";
extract($_REQUEST);
$cid=13051305;



   



if($type == 18){
    
    
if($sub_type == 1){ 
    
     $date=date('Y-m-d');
      $datacount=$db1->sql("select * from sm_main_form_1022 where del is null and pro_id='$pro_id' and customerid=$uid")->many();
      $datacount=count($datacount);


      if($datacount==0){
          
        //  echo "insert";
      $insert=$db1->from('sm_main_form_1022')
                     ->insert(array("cid"=>$cid,"pro_id"=>$pro_id,"customerid"=>$uid,"date"=>"$date"))
                     ->execute();
          $response['error']=false;
          $response['error_mgs']="Your like a product";
      }
      else{
          
            $insert=$db1->sql("UPDATE `sm_main_form_1022` SET `del` = '1' WHERE del is null and pro_id='$pro_id' and customerid=$uid")->execute();
        //   echo "delete";    
        
          
          $response['error']=false;
          $response['error_mgs']="Your alredy like a product";
      }
      
      
      echo json_encode($response);
}


if($sub_type == 2){ 
    // print_r($_POST);
  
    // echo "selva";
   $ip=$db1->sql(" CREATE OR REPLACE VIEW listing_mobile AS SELECT `id`, `aid`, `uid`, `bid`, `cid`, `sub_cat`, `client_name`, `client_whatsapp`, `client_mobile`, 
                            `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, 
                            `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`,
                            `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`,
                            `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`,
                            `user_upload_by`, `paid`, `date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `del`, `is_d`, `act`, `dtime`,
                            (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null and listing_for!='' and  size_type!='' ")->execute();

    

$datacount=$db1->sql("select pro_id from sm_main_form_1022 where del is null  and customerid=$uid")->many();

foreach($datacount as $val){
 $result = $db1->sql("select * from listing_mobile where id=".$val['pro_id']."")->one();

$sk['price_in_number']=  $result['price_in_number'];
$sk['product_title']=  $result['product_title'];
$sk['area']=  $result['area'];
$sk['pro_type']=  $result['pro_type'];
$sk['city']=  $result['city'];
$sk['id']=  $result['id'];
$sk['img1']=  $result['img1'];

$skk[]=$sk;
}
echo json_encode($skk);
}
    
    



if($sub_type == 3){ 
    
   $insert=$db1->sql("UPDATE `sm_main_form_1022` SET `del` = '1' WHERE del is null and pro_id='$pro_id' and customerid=$uid")->execute();
        //   echo "delete";    
          if($insert==true){
          $response['error']=false;
          $response['error_mgs']="Your Dislike a product";
          }
      echo json_encode($response);
}   


if($sub_type == 4){ 
    
  $date=date('Y-m-d');
      $datacount=$db1->sql("select * from sm_main_form_1022 where del is null and pro_id='$pro_id' and customerid=$uid")->many();
      $datacount=count($datacount);


      if($datacount==0){
          
        //  echo "insert";
          $response['status']=0;  
          $response['error']=false;
          $response['error_mgs']="Not like a product";
      }
      else{
          
          
          $response['status']=1;  
          $response['error']=true;
          $response['error_mgs']="Your liked a product";
      }
      
      
      echo json_encode($response);
}   












            }



?>