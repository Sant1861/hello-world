<?php
/*SAVE QUERY*/
//  ini_set("display_errors",0);
$cid=21472147;

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
$type = $_POST['type'];
$data=$_POST;

  
if($type==1){
    
// print_r($_POST);

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

$cidd=$data ['cid'];
$name=$data ['a_name'];
$num=$data['m_number'];
$wh_num=$data['wh_number'];
$add=$data['a_address'];
 $city=$data['a_district'];
 $state=$data['a_state'];
 $pincode=$data['a_pincode'];
 $comname=$data['com_name'];
$comadd= $data['com_address'];
$mail=$data['a_email'];
 $join=$data['a_join'];
 $refname= $data['ref_name'];
$ref_id= $data['ref_type'];
$bank= $data['a_bank'];
 $acc=$data['a_account'];
 $ifsc=$data['a_ifsc'];
 $upi=$data['a_upi'];
 $branch=$data['branch'];
 $specialties=$data['specialties'];
 $upi_num=$data['upi_num'];
 $role_type=$data['role_type'];
 $role_name=$data['role_name'];
 $descr=$data['descr'];
 
 
//  $agentid=$data['a_id'];
 $digits = 3;
$code12= str_pad(rand(0, pow(10, $digits)-1), $digits, '0', STR_PAD_LEFT);

 $prosts = $db1->sql("SELECT * FROM sm_main_form_127 WHERE id='$ref_id' and del is null")->one();
 $counter=count($prosts);
//  echo$counter;
 if($counter!=0){
     $procode=$refname.$code12;
    //  echo"prer"
 }
 else{
     $digits5=5;
$code13= str_pad(rand(0, pow(10, $digits5)-1), $digits5, '0', STR_PAD_LEFT);

$procode=$_POST['state'].$_POST['city'].$code13;
 }
  $target_dir = "../uploads/profilepic/";
        $target_file1 = $target_dir . basename($_FILES["imageapi"]["name"]);
        $pk=$_FILES['imageapi']['tmp_name'];
        $img=basename($_FILES["imageapi"]["name"]);
        $file_name=explode(".",$img);
        $imageFileType = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
         $mat_pic1 = $file_name[0].".".$imageFileType;
        $target_file = $target_dir.$procode.$mat_pic1;
             // Valid extension
                 $valid_ext = array('png','jpeg','jpg');
                 // Check extension
                 if(in_array($imageFileType,$valid_ext)){
                 // Compress Image
                 compressImage($_FILES['imageapi']['tmp_name'],$target_file,60);
            





 $data1 = array('cid'=>$cidd,'refer_by'=>$ref_id, 'c_name'=>$comname,'name'=>$name,'r_add'=>$add, 'bank_name'=>$bank, 'branch'=>$data['branch'],'acc_num'=>$acc, 'date_join'=>$join, 'city'=>$city, 'email'=>$mail, 'ifsc_code'=>$ifsc, 'c_add'=>$data['com_address'],'other_pin'=>$data['other_pin'], 'phone_num'=>$num, 'pin_code'=>$pincode,  'state'=>$state, 'upi_id'=>$upi, 'upi_num'=>$data['upi_num'], 'w_num'=>$wh_num, 'zip_code'=>$data['zip_code'], 'role_type'=> $z,'role_name'=>$a, 'descr'=>$data['descr'], 'profile_img'=>$target_file, 'add_code'=>$data['add_code'], 'pro_code'=>$procode,'branch'=>$branch,'specialties'=>$specialties,'upi_num'=>$upi_num,'role_type'=>$role_type,'role_name'=>$role_name,'descr'=>$descr);
 $qury1=$db1->from('sm_main_form_127')->insert($data1)->execute();
 if($qury1==TRUE){
     
      $response['error']=FALSE;
    $response['error_mgs']="upload sucessfull";
    $response['pro_code']=$procode;
 }
 
  if (move_uploaded_file($_FILES['imageapi']['tmp_name'],$target_file)) {
                                  $response['error']=FALSE;
                                  $response['error_mgs']="image upload sucessfull";
                                 
                              } else {
                        
                                 
                                  $response['error']=TRUE;
                                  $response['error_mgs']="Sorry, there was an error uploading your file.";
                                
                              }
 
 
 
  echo json_encode($response);  
 
  
                 }

}


// if($type==50){
//     print_r($_POST);
//      print_r($_FILES);
     
     
    
//  $prosts = $db1->sql("SELECT * FROM sm_main_form_127 WHERE id='$agentid' and del is null")->one();
// $refer_id=$prosts[''];
//   $z='1960';
//      $target_dir = "../uploads/profilepic/";
//      $target_file1 = $target_dir . basename($_FILES["imageapi"]["name"]);
//      $img=basename($_FILES["imageapi"]["name"]);
//      $file_name=explode(".",$img);
//      $imageFileType = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
//      $mat_pic1 = $file_name[0].".".$imageFileType;
//      $target_file = $target_dir.$mat_pic1;
//      // Valid extension
     
//      // Check extension
     
//      // Compress Image
   
//      $ref_id=$_POST['refer_by'];
//     if(($data['role_type']==1960) && ($data['refer_by']!=0)){
        
//         // echo"hoooooooo";
        
//         $ref_id=$_POST['refer_by'];
//         $check=$db1->sql("select * from sm_main_form_127 where del is null and id=$ref_id ")->one();
//      $bc=$check['pro_code']; 
// $code1=$bc.$code12;

//      }
//       if(($data['role_type']==1960) && ($data['refer_by']==0)){
//          echo"else";
//         $ref_id=$_POST['refer_by'];
//         $check=$db1->sql("select * from sm_main_form_127 where del is null and id=$ref_id ")->one();
//       $bc=$check['pro_code']; 
// $code1=$_POST['state'].$_POST['city'].$code12;

//      }
     
     
     
//      if($data['role_type']==1961){
         
// $digits5=5;
// $code13= str_pad(rand(0, pow(10, $digits5)-1), $digits5, '0', STR_PAD_LEFT);

// $code1=$_POST['state'].$_POST['city'].$code13;

//      }
//       if($data['role_type']==1962){
         
   

// $code1=$_POST['state'].$_POST['city'].$code12;



//      }
     
//      $check=$db->sql("select name from sm_main_form_11 where del is null and value=$z ")->one();
//       $a=$check['name'];
    
     
//     $data1 = array('cid'=>$cidd,'refer_by'=>$ref_id, 'c_name'=>$data['com_name'],'name'=>$data['a_name'], 'bank_name'=>$data['bank_name'], 'branch'=>$data['branch'],'acc_num'=>$data['acc_num'], 'date_join'=>$data['a_join'], 'city'=>$data['a_district'], 'email'=>$data['a_email'], 'ifsc_code'=>$data['ifsc_code'], 'c_add'=>$data['com_address'],'other_pin'=>$data['other_pin'], 'phone_num'=>$data['m_number'], 'pin_code'=>$data['pin_code'], 'a_pincode'=>$data['a_address'], 'state'=>$data['a_state'], 'upi_id'=>$data['upi_id'], 'upi_num'=>$data['upi_num'], 'w_num'=>$data['wh_number'], 'zip_code'=>$data['zip_code'], 'role_type'=> $z,'role_name'=>$a, 'descr'=>$data['descr'], 'imageapi'=>$target_file, 'add_code'=>$data['add_code'], 'pro_code'=>$code1);
//  echo $qury1=$db1->from('sm_main_form_127')->insert($data1)->sql();
//     print_r ($qury1);
//     $result1=$db1->sql($qury1)->execute();
//     $yearr=2023;
//     if($data['w_num']!= ""){
//   $sms="Dear,"." ".$data['name']." Thankyou For Choosing Truebroker,Your Registration is Completed Your ID Number is [$code1]";
// 	                       $wsms=array('cid'=>$cid,'mobile'=>$data['w_num'],'message'=>$sms);
//                          $wsms_sav=$db->from('send_wsms')->insert($wsms)->execute();  
//     }
//             $namey=$data['name'];              
// if($data['phone_num']!= " "){

// $mesg="Thank you!
// Dear $namey,Your TRUEBROKER registration has been completed successfully. We will contact you very soon!

// [Smart Global Solutions - $yearr]";

               


// 	                       $data2=array('cust_id'=>$code1,'cid'=>$cid,'sender'=>"917448812555",'mobile'=>$data['phone_num'],'message'=>$mesg);
//                          $qury2=$db->from('send_sms')->insert($data2)->execute();
                          
                          
                           
 

// }
//   }

  // Compress image
function compressImage($source, $destination, $quality) {

  $info = getimagesize($source);

  if ($info['mime'] == 'image/jpeg') 
    $image = imagecreatefromjpeg($source);

  elseif ($info['mime'] == 'image/gif') 
    $image = imagecreatefromgif($source);

  elseif ($info['mime'] == 'image/png') 
    $image = imagecreatefrompng($source);

  imagejpeg($image, $destination, $quality);

}
?>









