
<?php 

ini_set("display_errors",1);
// $db = new Dbclass();
// $db1 = new Dbclass($cid);
$cid = $_POST['cid'];
 $con2 = mysqli_connect('localhost','softuser','Soft@2021',"s_".$cid); 
// echo $cid;

$response = array();
if(isset($_POST['cid']))
{
$cid = $_POST['cid'];
    //   require_once('../../app/sys/config/dbconfig2.php');
    //   $con2->sql("SET NAMES utf8")->execute();	
}
//print_r($_POST);
if(isset($_POST['type']) && $_POST['type'] !=''){
    
	if($_POST['type']==1){
	     include_once("login.php");
	} 
	elseif($_POST['type']==2){
	   include_once("sjc_receipt.php");
	}
	elseif($_POST['type']==3){
	    include_once("sjc_viewreceipt.php");
	}
	elseif($_POST['type']==4){
	    include_once("sjc_receipt.php");
	}
	elseif($_POST['type']==5){
	    include_once("sjc_dashboard.php");
	}
      
  
 
	
}
else {
    // required post params is missing
    $response["error"] = TRUE;
	
    $response["error_msg"] = $code."Required parameters  missing!";
    echo json_encode($response);
}

?>
