<?php
// Log..

ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1=new Dbclass($cid);

extract($_POST);




if($type==100){

                                     
                                    $data1 = array(
                                          'cid' => $cid,
                                  'date' => date('Y-m-d',strtotime($date)),
                                  's_name' => $s_name,                    
                                    'last_name' => $last_name,                    
                                    'dob' =>  date('Y-m-d',strtotime($dob)),                    
                                  'address' => $address,
                                  'mobile' => $mobile,
                                  'email' => $email,
                                    'm_status' => $m_status,
                                   'passport' => $passport,
                                   'passport_number' => $passport_number,
                                  'source_enquiry' => $source_enquiry,
                                  'source_enquiry_value' => $other_value,
                                  'refr' => $refr,

                                  'hsc_mark' => $hsc_mark,
                                  'hsc_omark' => $hsc_omark,
                                  'hsc_date' => date('Y-m-d',strtotime($hsc_date)),
                                  'hsc_course' => $hsc_course,


                                  'd_english_mark' => $d_english_mark,
                                  'd_overall_mark' => $d_overall_mark,
                                  'd_course_studied' => $d_course_studied,
                                  'd_date' => date('Y-m-d',strtotime($d_date)),  

                                  'ug_overall_mark' => $ug_overall_mark,
                                  'ug_date' => date('Y-m-d',strtotime($ug_date)),
                                  'ug_course_studied' => $ug_course_studied,

                                  'pg_overall_mark' => $pg_overall_mark,
                                  'pg_date' => date('Y-m-d',strtotime($pg_date)),
                                  'pg_course_studied' => $pg_course_studied,

                                  'work_exp' => $work_exp,

                                  'ielts' => $ielts,
                                  'reading' => $reading,
                                  'listing' => $listing,
                                  'writing' => $writing,
                                  'speaking' => $speaking,
                                  'overall' => $over_all,

                                  'country1' => $country1,
                                  'course1' => $course1,  
                                  'country2' => $country2,
                                  'course2' => $course2,  

                                  'q1' => $q1,
                                  'q2' => $q2,
                                  'q3' => $q3,
                                  'q4' => $q4,
                                  'q5' => $q5,
                                  'q6' => $q6,    

                                   'q1_ans' => $q1_ans,
                                   'q2_ans' => $q2_ans,
                                   'q3_ans' => $q3_ans,
                                   'q4_ans' => $q4_ans,
                                   'q5_ans' => $q5_ans,
                                   'q6_ans' => $q6_ans,                                                            

                                 );                    
                                                     
                    $qury12=$db1->from('sm_main_form_101')->insert($data1)->sql();                    

                    // echo $qury1;
                    $result21=$db1->sql($qury12)->execute();
                    $lastid_2 = $db1->insert_id;    

   


      $data1 = array('cid' => $cid,
                    'enq_id' => $lastid_2,     
                    'date' => $date,
                    'time' => $time,                    
                    'branch' => $branch,
                    'type' => $appointment_type,
                );        

                    $qury12=$db1->from('sm_main_form_115')->insert($data1)->sql();                    
                    $qury1=$db1->sql("UPDATE `sm_main_form_101` SET `status` = '1' WHERE `sm_main_form_101`.`id` = $lastid_2")->execute();   
                    $result21=$db1->sql($qury12)->execute();

                    

    

            echo json_encode($result21);
    

  
    
}




?>