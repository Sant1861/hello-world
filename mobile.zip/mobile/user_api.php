<?php 
ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);

$type = $_POST['type'];
$data=$_POST;


//mychit user (user)
if($type==17){
   // print_r($data);
    // $user= $db1->from('sm_main_form_1417')->where('del #',null)->where('cid',$data['cid'])->where('name',$data['user_id'])->select('gname')->one();
//echo $user; 



  /*start request save*/ 
     $url="user_api.php.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      

$name=$data['user_id'];
$user=$db1->sql("SELECT a.gname as gname ,b.due as dueno, b.date as duedate FROM sm_main_form_1417 a
            INNER JOIN sm_main_form_1425 b
            ON a.name=b.led_id
            WHERE a.del is null AND a.name=$name AND a.cid=$cid ")->many();
            // echo $user;
    //  echo $user;       
       foreach($user as &$u) 
         if(empty($u['gname'])) {
        $u['gname']="0";
      }  
         
             echo json_encode($user);
}


//user dashboard -it 
if($type==21){
    
    
    /*start request save*/ 
     $url="user_api.php.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
      
    // $grp = $db1->sql("select a.grp_no as grp_no,a.gname as gname,b.name as name,a.temp_id as temp_id
    // from sm_main_form_1417 a
    // inner join sm_main_form_1401 b
    // on a.name=b.id
    // where a.name='".$data['user_id']."' and a.del is null ")->many();
    
    
    $grp = $db1->from('sm_main_form_1417')->where('cid',$data['cid'])->where('del #',null)->where('name',$data['user_id'])->select(array('grp_no','name','ch_value','temp_id','id as chit_id','gname'))->many();
    
    // print_r($grp);
        // echo $grp;
    foreach($grp as &$g){
        $gname = $db1->sql("select name as gname from sm_main_form_1416 where id='".$g['grp_no']."' and del is null")->one();
        $g['gname'] = $gname['gname'];
        if(empty($g['gname'])){
        $g['gname'] = '0';
        }
        if(empty($g['grp_no'])){
        $g['grp_no'] = '0';
        }
        $name = $db1->from('sm_main_form_1401')->where('del #',null)->where('id',$g['name'])->one();
        $g['name'] = $name['name'];
    }
    
    echo json_encode($grp);
    
}
//outstanding menu
if($type==19){
//      $u= $db1->from('sm_main_form_1417')->where('del #',null)->where('cid',$data['cid'])->where('name',$data['user_id'])->select('gname')->one();
//      foreach($u as &$val)
//     {
//         $bal = $db1->from('sm_main_form_140')
//           ->where('del #',null)
//           ->where('led_id',$val['name'])
//           ->where('chit_id',$val['id'])
//           ->select('sum(amount)')
//           ->one();
//     }
          
//      echo json_encode($u);
// }

    
       /*start request save*/ 
     $url="user_api.php.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
      
    $u = $db1->sql("SELECT gname,name,id as chit_id FROM sm_main_form_1417 WHERE del IS NULL AND name='".$data['user_id']."' AND cid=$cid ")->many();
// echo $u;
foreach($u as &$d)
{
    
         $name=$db1->from('sm_main_form_1401')->where('del #',null)->where('cat',1)->where('id',$d['name'])->one();
     $d['name'] = $name['name'];
     
    // if(!empty($d['gname'])){
          $bal = $db1->from('sm_main_form_140')
          ->where('del #',null)
          ->where('led_id',$d['name'])
          ->where('chit_id',$d['id'])
          ->select('sum(amount)')
          ->one();
        //  print_r($bal);
      if(empty($bal['sum(amount)'])) {
              $bal['sum(amount)']="0";
          
            
      }  else{
          $bal['sum(amount)']="'".$bal['sum(amount)']."'";
      } 
      $d['balance'] =  $bal['sum(amount)']; 

  if(empty($d['gname'])) {
      $d['gname']="0";
      } 
    // }
 
  
}


//  $rs['gname']=$u['gname'];
//  $rs['balance']=$u['balance'];
 
echo json_encode($u);
}



// //save query for payment menu
if($type==24){
    
       /*start request save*/ 
     $url="user_api.php.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
      
  $image = $data['image'];
    $folderPath ="../../uploads/payment_image/";
    $image_base64 = base64_decode($image);
    $fileName = uniqid().'.png'; 
    $file = $folderPath . $fileName;
    $sa = file_put_contents($file, $image_base64);
    
// $data['image'] = $fileName;

    // echo json_encode($imageFileType);
/* 'ef'=>1
     is mobile save  entry different */
    
$d=array('date'=>date('Y-m-d',strtotime($data['date'])),'cid'=>$data['cid'],'ef'=>1,'uid'=>$data['uid'],'amount'=>$data['amount'],'p_type'=>$data['pay_type'],'image'=>$fileName,'acc_no'=>$data['acc_no'],'remark'=>$data['remark']);
    
    $save=$db1->from('sm_main_form_1420')
              ->insert($d)
             ->execute();
          // echo $save;
             
           	$lastid = $db1->insert_id;
           	
           	//save query for 140
        //  $re = array('cid'=>$data['cid'],'uid'=>$data['uid'],'trans_type'=>12,'trans_name'=>'Chit Payment','trans_no'=>$lastid,'date'=>date('Y-m-d',strtotime($data['date'])),'led_id'=>$data['led_id'],'amount'=>'-'.$data['amount'],'chit_id'=>$data['chit_id'],'descr'=>$data['temp_id'],'remark'=>$data['mobile'].",".$data['address']);
                         
        //                  $name = $db1->from('sm_main_form_140')->insert($re)->sql();
                       
        //                 $db1->sql($name)->execute();
                        
                        //  print_r($name);
                        
            $re = array('cid'=>$data['cid'],'uid'=>$data['uid'],'trans_type'=>12,'trans_name'=>'Chit Payment','trans_no'=>$lastid,'date'=>date('Y-m-d',strtotime($data['date'])),'led_id'=>$data['led_id'],'amount'=>'-'.$data['amount'],'grp_id'=>$data['grp'],'chit_id'=>$data['chit_no'],'descr'=>$data['chit_name'],'remark'=>$data['mobile'].",".$data['address']);
                         
                         $name = $db1->from('sm_main_form_140')->insert($re)->sql();
                       
                        $db1->sql($name)->execute();
                        
                        //  print_r($name);
                        
                        if($data['pay_acc'] >0 ){
                         $re1 = array('cid'=>$data['cid'],'uid'=>$data['uid'],'trans_type'=>12,'trans_name'=>'Chit Payment','trans_no'=>$lastid,'date'=>date('Y-m-d',strtotime($data['date'])),'led_id'=>$data['pay_acc'],'amount'=>$data['amount'],'grp_id'=>$data['grp'],'chit_id'=>$data['chit_no'],'descr'=>$data['chit_name'],'remark'=>$data['mobile'].",".$data['address']);
                         
                         $name1 = $db1->from('sm_main_form_140')->insert($re1)->sql();
                       
                        $db1->sql($name1)->execute();
           
           
            if($save==true&&$re==true){
          $response['error']=false;
          $response['error_msg']="Payment Saved successfully";
            }
            else {
                 $response['error']=true;
          $response['error_msg']="Payment Not Saved";
            }
            echo json_encode($response);
   
    
}
}


//Enquiry menu
 if($type==25){
     
       /*start request save*/ 
     $url="user_api.php.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
      
     /* 'ef'=>1
     is mobile save  entry different */
     
     $dr=array('cid'=>$data['cid'],'ef'=>1,'aid'=>$data['aid'],'uid'=>$data['uid'],'name'=>$data['user_id'],'amount'=>$data['amount'],'ch_value'=>$data['ch_value'],'email'=>$data['email'],'mobile'=>$data['mobile'],'address'=>$data['address']);
     $enquiry= $db1->from('sm_main_form_1437')
                   ->insert($dr)
                   ->execute();
                   //echo $enquiry;
                   
                   
                   
                    if($enquiry==true){
          $response['error']=false;
          $response['error_msg']="Inserted successfully";
            }
            else {
                 $response['error']=true;
          $response['error_msg']="Data Not Insert";
            }
            echo json_encode($response);
 }
 
 //user statement
if($type==30){
   
   
     /*start request save*/ 
     $url="user_api.php.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
      
    // $u=  $db1->from('sm_main_form_1423')->where('del #',null)->where('cid',$data['cid'])->select(array('name','date','type','amount'))->many();
    
    // foreach($u as &$val){
    //       $member=$db1->from('sm_main_form_1401')->where('del #',null)->where('cat',3)->where('id',$val['name'])->one();
    //  $val['name'] = $member['name'];
    // }
    
    //  $statement = $db1->sql("SELECT b.led_id as name,b.date as d_date,b.type as d_type,sum(b.amount) as debit ,a.date as c_date,a.type as c_type,sum(a.amount) as credit
    //                         FROM sm_main_form_1423 a 
    //                         INNER JOIN sm_main_form_1424 b
    //                         ON a.led_id=b.led_id 
    //                         WHERE a.del IS NULL AND a.led_id='".$data['user_id']."' ")->one();
                            
    
    // $agent =  $db1->from('sm_main_form_1401')->where('del #',null)->where('id',$statement['name'])->one();
    // $statement['name'] = $agent['name'];
     
    // $c_type = $db->from('sm_main_form_11')->where('list_id',134)->where('value',$statement['c_type'])->where('del #',null)->one();
    // $statement['c_type']=$c_type['name'];
     
     
    // $d_type = $db->from('sm_main_form_11')->where('list_id',135)->where('value',$statement['d_type'])->where('del #',null)->one();
    // $statement['d_type']=$d_type['name'];
     
    //  echo json_encode(array($statement));
    
    $led_id=$data['user_id'];
    // $chit_id=$data['chit_id'];
    $rdate=$date['date'];
     $cond='';
            if(!empty($led_id)){
                $cond .= " and led_id='".$led_id."' ";
            }
            // if(!empty($chit_id)){
            //     $cond .= " and chit_id='".$chit_id."' ";
            // }
            if(!empty($rdate)){
                $cond .= " and date <='".date('Y-m-d',strtotime($rdate))."' ";
            }
        $qry = $db1->sql("SELECT date,amount,trans_type,trans_name,(CASE WHEN sm_main_form_140.amount<0 THEN sm_main_form_140.amount ELSE 0 END) as credit,
(CASE WHEN sm_main_form_140.amount>=0 THEN sm_main_form_140.amount ELSE 0 END) as debit FROM sm_main_form_140  WHERE del IS NULL $cond  order by date,id")->many();
// echo $qry;
 foreach($qry as &$qr)
                    {
//                       if(empty($qr['trans_name'])){
//                           $aa = $db->from('sm_main_form_11')->where('list_id',140)->where('value',$qr['trans_type'])->where('del #',null)->select('name')->one();
//                       $qr['trans_name'] = $aa['name'];
                           
//                       }

$qr['date']=date('d-m-Y',strtotime($qr['date']));

}
  echo json_encode($qry);
}


if($type==1){
    
    
     /*start request save*/ 
     $url="user_api.php.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
      

$res=$data['data'];
$json=json_decode($res);
$json1=json_encode($json);

// echo $json1;

$d=array('date'=>date('Y-m-d',strtotime($data['date'])),'cid'=>$data['cid'],'uid'=>$data['uid'],'led_id'=>$data['led_id'],'payment_id'=>$data['payment_id'],'mobile'=>$data['user_contact'],'email'=>$data['user_email'],'signature'=>$data['signature'],'balance'=>$data['external_wallet'],'status'=>$data['status'],'responses'=>$json1);
    
    $paymentcheck=$db1->from('sm_main_form_1446')
              ->insert($d)
             ->execute();
            //  echo $paymentcheck;
             
             
          // echo $paymentcheck;
             
        //   	$lastid = $db1->insert_id;
           	
        //   	//save query for 140
        //  $re = array('cid'=>$data['cid'],'uid'=>$data['uid'],'trans_type'=>12,'trans_name'=>'Chit Payment','trans_no'=>$lastid,'date'=>date('Y-m-d',strtotime($data['date'])),'led_id'=>$data['led_id'],'amount'=>'-'.$data['amount'],'chit_id'=>$data['chit_id'],'descr'=>$data['temp_id'],'remark'=>$data['mobile'].",".$data['address']);
                         
        //                  $name = $db1->from('sm_main_form_140')->insert($re)->sql();
                       
        //                 $db1->sql($name)->execute();
                        
                        //  print_r($name);
                        
            if($paymentcheck==true){
          $response['error']=false;
          $response['error_msg']="Payment Saved successfully";
            }
            
            echo json_encode($response);
   
    

}

if($type==2){


   /*start request save*/ 
     $url="user_api.php.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
$res=$data['data'];
$json=json_decode($res);
$json1=json_encode($json);

// echo $json1;

$d=array('date'=>date('Y-m-d',strtotime($data['date'])),'cid'=>$data['cid'],'uid'=>$data['uid'],'led_id'=>$data['led_id'],'payment_id'=>$data['payment_id'],'mobile'=>$data['user_contact'],'email'=>$data['user_email'],'signature'=>$data['signature'],'balance'=>$data['external_wallet'],'status'=>$data['status'],'responses'=>$json1,'error'=>$data['error']);
    
    $paymentcheck=$db1->from('sm_main_form_1446')
              ->insert($d)
             ->execute();
            //  echo $paymentcheck;
             
             
          // echo $paymentcheck;
             
        //   	$lastid = $db1->insert_id;
           	
        //   	//save query for 140
        //  $re = array('cid'=>$data['cid'],'uid'=>$data['uid'],'trans_type'=>12,'trans_name'=>'Chit Payment','trans_no'=>$lastid,'date'=>date('Y-m-d',strtotime($data['date'])),'led_id'=>$data['led_id'],'amount'=>'-'.$data['amount'],'chit_id'=>$data['chit_id'],'descr'=>$data['temp_id'],'remark'=>$data['mobile'].",".$data['address']);
                         
        //                  $name = $db1->from('sm_main_form_140')->insert($re)->sql();
                       
        //                 $db1->sql($name)->execute();
                        
                        //  print_r($name);
                        
            if($paymentcheck==true){
          $response['error']=false;
          $response['error_msg']="Payment Saved successfully";
            }
            
            echo json_encode($response);
   
    

}


?>