<?php 


// ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$response=array();
// print_r($_POST);
if($_POST['sub_type']==1){
    $data1=$_POST;

 $ip = json_decode($data1['data'][0], true);
$ipp=$ip[0];
     $db1->sql("SET NAMES utf8")->execute();	
	$selectdata = $db1->from("sm_main_form_1003")->where("main","1")->where("form_id",'add_property')->select("name")->many();

foreach($selectdata as &$val ){
	$vall = $val['name'];
	if (array_key_exists($vall, $ipp)){
		$data[$vall] = $ipp[$vall];
	}
}	
$form = "add_property";
$result =$db1->from($form)
    ->insert($ipp)
    ->sql();
 $db1->sql($result)->execute();
	$lastid = $db1->insert_id;
	
	function intLen(int $num) {
    return strlen((string) abs($num));
}
$rand=(rand(10000,99999));

 $mxid=$lastid;
// echo $mxid=12345;
$scount=intLen($mxid);
// echo $scount."...............";
// echo $rand."prem";
if($scount==1){
  $rand1= sprintf('%06s', $mxid);
}
if($scount==2){
  $rand1= sprintf('%06s', $mxid);
}
if($scount==3){
 $rand1= sprintf('%06s', $mxid);
}
if($scount==4){
   $rand1= sprintf('%06s', $mxid);
}
if($scount==5){
   $rand1= sprintf('%06s', $mxid);
}
if($scount==6){
   $rand1= sprintf('%06s', $mxid);
}
	
	
	
	
    $data2 = array('category'=>$data1['cat_id'],'sub_cat'=>$data1['sub_cat_id'],'pro_type'=>$data1['pro_type_id'],'product_code'=>$rand.$rand1,'uid'=>$data1['uid'],'cid'=>$data1['cid'],'latitude'=>$data1['lt'],'logitute'=>$data1['ln'],'type'=>'2','paid'=>1,'date'=>date("y-m-d") );
  $result=$db1->from('add_property')->where('id',$lastid)->update($data2) ->execute();
  
   $response["error"] = FALSE;
    $response["error_msg"] = "Save Sucessfully";
    $response["last_id"] = $lastid;
  echo json_encode($response);
}

if($_POST['sub_type']==2){
    
   extract($_POST);
//   print_r($_POST);
   
 $data1 = array('postal_code'=>$postal_code,'area'=>$area,'city'=>$city,'post_id'=>$post_id);
  $result=$db1->from('add_property')->where('id',$last_id)->update($data1) ->execute();
    if($result==TRUE){
       $response["error"] = FALSE;
    $response["error_msg"] = "Save Sucessfully"; 
    }
    else{
         $response["error"] = TRUE;
    $response["error_msg"] = "Some thin went wrong"; 
    }
    echo json_encode($response);
}



?>