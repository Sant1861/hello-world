<?php 

ini_set("display_errors",0);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();

$db1=new Dbclass($cid);

extract($_REQUEST);
$idd=$_COOKIE['uid'];
if ($type == 37) {
    $recent = $db1->sql("SELECT id,date,product_code,product_size,size_type,category,sub_cat,pro_type,propriter_name,listing_for,product_title,price_in_alphabet,area,city,
        (SELECT name FROM truebroker_new_1.sm_main_form_11 WHERE del IS NULL AND list_id=193 AND value=add_property.listing_for LIMIT 1) AS list,
        (SELECT category FROM sm_main_form_1000 WHERE id=add_property.category LIMIT 1) AS cat,
        (SELECT sub_category FROM sm_main_form_1001 WHERE id=add_property.sub_cat LIMIT 1) AS sub,
        (SELECT pro_type FROM sm_main_form_1002 WHERE id=add_property.pro_type LIMIT 1) AS protype,
        (SELECT img_3 FROM sm_main_form_1009 WHERE pro_id=add_property.id AND img_3 !='' LIMIT 1) AS img,
        (SELECT COUNT(id) FROM sm_main_form_1017 WHERE pro_id=add_property.id) AS count
        FROM add_property WHERE del IS NULL AND category=1 AND pro_view=1 ORDER BY id DESC LIMIT 5")->many();

    foreach ($recent as &$r) {
        $pro_for = $db->sql("SELECT name FROM sm_main_form_11 WHERE value='" . $r["listing_for"] . "' AND list_id=193 AND del IS NULL")->one();
     
         if($r['product_size']!=""){
                                     $pro_size_type = $db->sql("SELECT name FROM sm_main_form_11 WHERE value= '".$r["size_type"]."'  and list_id=216 and del IS NULL")->one();                    
                                                      if(preg_match('/[a-zA-Z]/', $r['product_size'])){
                                                        $prod=$r['product_size'];
                                                      }else{
                                                        $prod=$r['product_size'] . " " . $pro_size_type['name']; 
                                                      }
                                                  }else{
                                                      $prod="Size unspecified"; 
                                                  }

        $likecnt1 = $db1->sql("SELECT * FROM sm_main_form_1022 WHERE del IS NULL AND pro_id='" . $r['id'] . "' AND customerid='$idd'")->many();
        $likecnt = count($likecnt1);
        if ($likecnt == 1) {
            $likeclass = "likecolor";
        } else {
            $likeclass = " ";
        }
        
        //   $item['price_in_alphabet'] = formatIndianNumber($item['price_in_number']);
    $r['final_size'] = $prod;
    }

    echo json_encode($recent);
}

?>