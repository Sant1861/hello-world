<?php
 if($type==13)
  {
    extract($_POST);
     $item = $db1->from('sm_main_form_1602')->where('mobile',$mobile)->where('del #',null)->one();
     $count = count($item);
    
    
    // if($mobile=='8903442347')
     if($count!=0)
     {
         $del = $db->from('otp')->where('led_id',$item['cus_id'])->update(array('status'=>2))->execute();
         $otp = $user->generateotp(6);
         $name = $item['name'];
   $phone = $mobile;
   //$msg = "Dear $name ,Your OTP number for login is $otp. If you are not requested any otp send SMS as BLOCK from mobile 9159042233";
	$msg = "<#> DTHAPP: Dear $name ,Your OTP number for login is $otp Don't share this code with others	$tok";
  
   $sid ="";
 $user->sendsms($phone,$msg,$sid);
 $pna = $db->from('sm_main_form_7')->where('cid',$item['cid'])->one();
 	$in = array('date'=>date('Y-m-d'),'cid'=>$item['cid'],'led_id'=>$item['cus_id'],'otp'=>$otp,'device_id'=>$device_id);
 	$ins = $db->from('otp')->insert($in)->execute();
 	
         $data = array('cus_id'=>$item['cus_id']);
         $data['cid'] = $item['cid'];
         $data['comp_name'] = $pna['name'];
         //$data = array('id'=>5);
         	$data["error"]= FALSE;
		 $data["error_msg"] = "Allow to next page";
     }
     else
     {
        $data["error"] = TRUE;
    $data["error_msg"] = "Your phone number is wrong"; 
     }
     
             echo json_encode($data);
  }
  ?>