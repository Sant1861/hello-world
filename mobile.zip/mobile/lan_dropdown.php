<?
ini_set("display_errors",1);
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
extract($_REQUEST);
$db = new Dbclass();
$db1 = new Dbclass($cid);
$db->sql("SET NAMES utf8")->execute();
$db1->sql("SET NAMES utf8")->execute();

if($type==24){
    
    $lan_drop=$db1->sql("select id,name from sm_main_form_1041 where del is null ")->many();
    echo json_encode($lan_drop);
}
?>
