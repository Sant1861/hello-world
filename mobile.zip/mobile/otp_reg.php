<?php
// ini_set("display_errors",1);
// error_reporting(0);


$cid=$_POST['cid'];

// $cid='21472147';

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
// print_r($_POST);
// $type = $_POST['type'];
// $data=$_POST;

 if(isset($_POST['mobile'])&&($_POST['role_id']))
  {
       $logincheck =$db1->sql("SELECT * from sm_main_form_127 where phone_num='".$_POST['mobile']."' or w_num='".$_POST['mobile']."' and del is null")->one();
       $cot=count($logincheck);
    //   echo $cot."prem";
       if($cot != 0){
       
       
       
    //   echo "kumar";
       
       
       
       
       
       $dataw['id']=$logincheck['id'];   
        $dataw['cid']=$logincheck['cid'];   
        $dataw['c_name']=$logincheck['c_name'];   
        $dataw['c_add']=$logincheck['c_add'];   
        $dataw['refer_by']=$logincheck['refer_by'];   
        $dataw['name']=$logincheck['name'];   
        $dataw['city']=$logincheck['city'];   
        $dataw['email']=$logincheck['email'];   
        $dataw['phone_num']=$logincheck['phone_num'];   
        $dataw['pin_code']=$logincheck['pin_code'];   
        $dataw['r_add']=$logincheck['r_add'];   
        $dataw['w_num']=$logincheck['w_num'];   
        $dataw['role_type']=$logincheck['role_type'];   
        $dataw['profile_img']=$logincheck['profile_img'];   
        $dataw['pro_code']=$logincheck['pro_code'];   
       $dataw['error']=FALSE;
      $dataw['error_msg']="truebroker";
      
      
      
    //   print_r($_POST);
    //   echo"selva";
      
      echo json_encode($dataw);  
       }
     
    elseif($cot == 0){
        // print_r($_POST);
    // extract($_POST);
    // echo $_POST['mobile'];
     //print_r($_POST);
     $item = $db->from('sm_main_form_20')->where('mobile',$_POST['mobile'])->where('del #',null)->one();
     $count = count($item);
    //   echo $count."prem";
     if($count==0){
    //   print_r($_POST);
    
     $mobnum1=array('cid' => $cid,'role_id'=>$_POST['role_id'],'mobile'=>$_POST['mobile'],'lati'=>$_POST['lati'],'longt'=>$_POST['longt'],'dev_id'=>$_POST['dev_id'],'dev_loc'=>$_POST['dev_loc']);
     $qury1=$db->from('sm_main_form_104')->insert($mobnum1)->sql();
    //   echo $qury1;
    $result1=$db1->sql($qury1)->execute();
     $itemno = $db1->from('sm_main_form_104')->where('mobile',$_POST['mobile'])->where('del #',null)->one();
  $ledid= $itemno['id'];
  
$cdate=date("Y-m-d");
  $mobnum2=array('cid' => $cid,'role_id'=>$_POST['role_id'],'date'=>$cdate,'mobile'=>$_POST['mobile'],'led_id'=>$ledid,'lati'=>$_POST['lati'],'longt'=>$_POST['longt'],'dev_id'=>$_POST['dev_id'],'dev_loc'=>$_POST['dev_loc']);
     $qury2=$db->from('sm_main_form_20')->insert($mobnum2)->sql();
        //   echo $qury2;
      $result2=$db->sql($qury2)->execute();
      include('../mobile/mobile_otp.php');
 }
 else{
    //  $data["error_msg"] = "Already Registered";
    //   echo json_encode($data);
    include('../mobile/mobile_otp.php'); 
 }
  }
  
  } 
  
  
  
  
  ?>