 <?php
/*SAVE QUERY*/
//  ini_set("display_errors",1);
$cid=21472147;

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
$type = $_POST['type'];
$data=($_POST);
$date=date("Y/m/d");
$count=$data['count'];
//  $data1=$_FILES;
//   print_r($_FILES);
//   print_r($_POST);
$z= $data["pro_sts"];
$y=$data["cat_name"];    
$x=$data["pro_type"];
$w=$data["seller"];
$v=$data["area"];
$u=$data["seller_name"];
$catn1=$db1->sql("SELECT * FROM sm_main_form_100 WHERE cat_code=$x and del IS NULL")->one();
                           $prosk= $catn1['name'];
    // echo $prosk."prem1";
   
   

  
    $check=$db->sql("select name from sm_main_form_11 where del is null and value=$z ")->one();
      $a=$check['name'];
    //   echo $a."prem2";
      $catn=$db1->sql("SELECT * FROM sm_main_form_101 WHERE cat_code=$y and del IS NULL")->one();
                           $cat_name1= $catn['cat_name'];
                            // echo $cat_name1."prem3";
                            

if ($type==14) {
    // echo"hiiiiiiiii";
    // print_r($_FILES);
    // print_r($_POST);
if($count!=0){
  


    
  function generateRandomString($length = 6) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}


$ran=generateRandomString();

$alfa=$ran;
$rand=(rand(100000,999999));

if($data['pay_id']==" " ||$data['pay_id']==0 ){
  $data['pay_done']=1;  
}else{
    $data['pay_done']=2; 
}

  $data1 = array('cid' => $data['cid'],'pro_code' => $rand,'pro_alfa_code' => $alfa,'bid' => $data['bid'],'uid' => $data['uid'],'aid' => $data['aid'],'cat_name' => $data['cat_name'],'pro_type'=>$x,'pro_price'=>$data['pro_price'],'category_name'=>$cat_name1,'sts_name'=>$a,'property_type'=>$prosk,'pro_size'=>$data['pro_size'],'room'=>$data['room'],'bathroom'=>$data['bathroom'],'garage'=>$data['garage'],'garage_size'=>$data['garage_size'],'bed_room'=>$data['bed_room'],'year_build'=>$data['year_build'],'land_mark'=>$data['land_mark'],'pro_sts'=>$z,'pro_name'=>$data['pro_name'],'address'=>$data['address'],'city'=>$data['city'],'c_mobile'=>$data['c_mobile'],'state'=>$data['state'],'post_code'=>$data['post_code'],'pro_desc'=>$data['pro_desc'],'pro_occ'=>$data['pro_occ'],'pro_stories'=>$data['pro_stories'],'pro_building'=>$data['pro_building'],'park_space'=>$data['park_space'],'pro_feature'=>$data['pro_feature'],'clocation'=>$data['clocation'],'area'=>$v,'upcoming'=>$data['upcoming'],'pay_id'=>$data['pay_id'],'ln'=>$data['ln'],'lt'=>$data['lt'],'price_no'=>$data['price_no'],'seller'=>$data['seller'],'c_whatsapp'=>$data['c_whatsapp'],'seller_name'=>$data['seller_name'],'sel_name'=>$data['sel_name'],'pay_done'=>$data['pay_done'],'pay_show'=>$data['pay_show'],'update_date'=>$data['update_date'],'end_date'=>$data['end_date'],'c_date'=>$data['c_date'],'client_name'=>$data['client_name'],'upload_date'=>$date);
 
 
//   print_r($qury1); 
 $qury1=$db1->from('sm_main_form_102')->insert($data1)->execute(); 
  if($data['c_whatsapp']!= " "){
   $sms="Dear,"." ".$data['name']." Thankyou For Choosing Truebroker,Your Registration is Completed Your url is https://truebroker.in/$rand";
	                       $wsms=array('cid'=>$cid,'mobile'=>$data['c_whatsapp'],'message'=>$sms);
                         $wsms_sav=$db->from('send_wsms')->insert($wsms)->execute();  
    }
    
    
    $scall=$db1->sql("select * from sm_main_form_136 where del is null")->many();
foreach($scall as $call){
    
    $numw=$call['w_num'];
    
    
     $sms1="Dear team one property uploaded now property name is,"." ".$data['pro_name']." and url is https://truebroker.in/$rand please check and approval it";

	                       $wsms=array('cid'=>$cid,'mobile'=>$numw,'message'=>$sms1);
                         $wsms_sav=$db->from('send_wsms')->insert($wsms)->execute();
    
}

    
    
    
 if($qury1==true){
//   print_r($qury1);
  
  
  
  
  
  
  
    $check=$db1->sql('select * from sm_main_form_102 order by dtime desc LIMIT 1 ')->one(); 
                                  $pid=$check['id'];
   
                                //   echo $pid.'prem';
   
    // print_r($_FILES);
    for ($i = 0;$i < $count; $i++) { //loop to get individual element from the array
    
//   echo 'prem';
    
    
     $imageProcess = 0;
   
        $fileName = ($_FILES["imageapi$i"]["name"]); 
        $sourceProperties = getimagesize($fileName);
        $resizeFileName = time();
        $uploadPath = "../uploads/proimg/100*100/";
        $uploadPath1 = "../uploads/proimg/";
        
        $fileExt = pathinfo($_FILES["imageapi$i"]['name'], PATHINFO_EXTENSION);
        $uploadImageType = $sourceProperties[2];
        $sourceImageWidth = $sourceProperties[0];
        $sourceImageHeight = $sourceProperties[1];
        switch ($uploadImageType) {
            case IMAGETYPE_JPEG:
                $resourceType = imagecreatefromjpeg($fileName); 
                $imageLayer = resizeImage($resourceType,$sourceImageWidth,$sourceImageHeight);
                imagejpeg($imageLayer,$uploadPath."thump_".$resizeFileName.'.'. $fileExt);
                //imagejpeg($_FILES["pro_img"]['tmp_name'],$uploadPath1."thump_".$resizeFileName.'.'. $fileExt);
                $target_file=$uploadPath."thump_".$resizeFileName.'.'. $fileExt;
                break;
 
            case IMAGETYPE_GIF:
                $resourceType = imagecreatefromgif($fileName); 
                $imageLayer = resizeImage($resourceType,$sourceImageWidth,$sourceImageHeight);
                imagegif($imageLayer,$uploadPath."thump_".$resizeFileName.'.'. $fileExt);
                //imagejpeg($_FILES["pro_img"]['tmp_name'],$uploadPath1."thump_".$resizeFileName.'.'. $fileExt);
                $target_file=$uploadPath."thump_".$resizeFileName.'.'. $fileExt;
                break;
 
            case IMAGETYPE_PNG:
                $resourceType = imagecreatefrompng($fileName); 
                $imageLayer = resizeImage($resourceType,$sourceImageWidth,$sourceImageHeight);
                imagepng($imageLayer,$uploadPath."thump_".$resizeFileName.'.'. $fileExt);
                //imagejpeg($_FILES["pro_img"]['tmp_name'],$uploadPath1."thump_".$resizeFileName.'.'. $fileExt);
                $target_file=$uploadPath."thump_".$resizeFileName.'.'. $fileExt;
                break;
 
            default:
                $imageProcess = 0;
                break;
        }
        //move_uploaded_file($file, $uploadPath. $resizeFileName. ".". $fileExt);
        //compressImage($_FILES['pro_img']['tmp_name'],$uploadPath1,40);
        $imageProcess = 1;
        if($imageProcess == 1){
            $pro=$data['pro_name'];
        $proexp =explode("||",$pro);
        $pro_id=$proexp[2];
     move_uploaded_file($fileName, $uploadPath1."thump_". $resizeFileName. ".". $fileExt);
 
$target_dir = "../uploads/proimg/";
                             
                             $target_file1 = $target_dir . basename($_FILES["imageapi$i"]["name"]);
                             
                            $imageFileType1 = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));

                            $mat_pic1 =$lastid1.'imageapi'.time().''.$i.'.'.$imageFileType1;

                            $target_file = $target_dir . $mat_pic1;

                            if (move_uploaded_file($_FILES["imageapi$i"]["tmp_name"], $target_file)) {
                                //   echo "The file ". htmlspecialchars( basename( $_FILES["imageapi$i"]["name"])). " has been uploaded.";
                                // print_r($_FILES);
                                  $wmgs1="../uploads/proimg/$mat_pic1"; 
                                  $data2=array('cid'=>$cid,'pro_id'=>$pid,'pro_name'=>$data['pro_name'],'order1'=>$i,'img_cap'=>$data['img_cap'],'pro_img'=>$wmgs1,'upcoming'=>$data['upcoming']);
                                  $qury2=$db1->from('sm_main_form_103')->insert($data2)->execute(); 
                                //  echo"prem";
                                  $response['error']=FALSE;
                                  $response['error_mgs']="image upload sucessfull";
                                   $response['id']=$rand;
                                  //echo "image upload sucessfull";
                              } else {
                                 
                                  $response['error']=TRUE;
                                  $response['error_mgs']="Sorry, there was an error uploading your file.";
                                
                              }
                             
                            //  print_r($response); 
                             
    
                    //   echo "hiiiiiiiiii";
                    
}
// $response=array();

}
// echo "11";
echo json_encode($response);
}
   
}
else{
     $response['error']=TRUE;
$response['error_mgs']="Sorry, Atleast Upload One Image To List Your Property.";
  echo json_encode($response);  
}
// $response=array();


// date_default_timezone_set('Asia/Kolkata');
//     $new=fopen("img_upload.txt",'a');
//     $CURRENTDATE=date("Y-m-d H:i:s"); 
//     // $write= "[" . $CURRENTDATE  .",  DATA :  " . json_encode($_POST). "--- FILE ".json_encode($_FILES)."  RESPONSE --".json_encode($response). " ]" ;
//     $write= "[" . $CURRENTDATE  .",  DATA :  " . json_encode($_POST). "--- FILE ".json_encode($_FILES)."  ]" ;
    
//     fwrite($new,$write);
//     fwrite($new,"\r\n");
//     fclose($new);
//   print_r($_FILES);
//   print_r($_POST);

    
}



function resizeImage($resourceType,$image_width,$image_height) {
    $resizeWidth = 1600/4;
    $resizeHeight = 1600/4;
    $imageLayer = imagecreatetruecolor($resizeWidth,$resizeHeight);
    imagecopyresampled($imageLayer,$resourceType,0,0,0,0,$resizeWidth,$resizeHeight, $image_width,$image_height);
    return $imageLayer;
}
?>






















