
<?
$cid=$_POST['cid'];

// $cid='21472147';

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~api fro Otp send~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if($_POST['sub_type']==1){
 if(isset($_POST['mobile'])&&($_POST['role_id']))
  {
   

$item = $db->from('sm_main_form_20')->where('mobile',$_POST['mobile'])->where('del #',null)->one();
     $count = count($item);
     
     if($count==0){
         $mobnum1=array('cid' => $cid,'role_id'=>$_POST['role_id'],'mobile'=>$_POST['mobile'],'lati'=>$_POST['lt'],'longt'=>$_POST['ln'],'dev_id'=>$_POST['device_id'],'dev_loc'=>$_POST['dev_loc']);
     $qury1=$db->from('sm_main_form_104')->insert($mobnum1)->sql();
    //   echo $qury1;
    $result1=$db1->sql($qury1)->execute();
     $itemno = $db1->from('sm_main_form_104')->where('mobile',$_POST['mobile'])->where('role_id',$_POST['role_id'])->where('del #',null)->one();
  $ledid= $itemno['id'];
$cdate=date("Y-m-d");
  $mobnum2=array('cid' => $cid,'role_id'=>$_POST['role_id'],'date'=>$cdate,'mobile'=>$_POST['mobile'],'led_id'=>$ledid,'lati'=>$_POST['lt'],'longt'=>$_POST['ln'],'dev_id'=>$_POST['device_id'],'dev_loc'=>$_POST['dev_loc']);
     $qury2=$db->from('sm_main_form_20')->insert($mobnum2)->sql();
        //   echo $qury2;
      $result2=$db->sql($qury2)->execute();
       $lastid = $db->insert_id;
            $coim=$db1->sql("select * from sm_main_form_1012 where del is null and reward_type=1")->one();
      $ins1=array('cid' => $cid,'mobile'=>$_POST['user'],'user_id'=>$lastid,'coin'=>$coim['coins'],'description'=>"Welcome Bonus",'date'=>date('Y-m-d'));
      $coinn=$db->from('sm_main_form_20_1')->insert($ins1)->execute();
            
      	$sms = "Dear," . " " . $_POST['mobile'] . "Thankyou For Registration.,Welcome to TrueBroker Family We Are Hoply Helps To Promot Your Products or Property.,Plz Keep In Touch.,";
	$wsms = array('cid' => $cid, 'mobile' => $_POST['mobile'], 'message' => $sms);
	$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();
	
	$scall=$db1->sql("select * from sm_main_form_1024")->many();

	foreach ($scall as $call) {

// 		$numw = $call['w_num'];


		$sms1 = "Dear Team One New Person Login On Trubroker App Mobile='".$_POST['mobile']."' Kindly Follow Him.,";

		$wsms = array('cid' => $cid, 'mobile' => $call['mobile'], 'message' => $sms1);
		$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();
	}
      
      include('../mobile/mobile_otp.php');
     }
     
     else{
         include('../mobile/mobile_otp.php'); 
     }

    }
    else{
    $data1["error"] = TRUE;
    $data1["error_msg"] = "WE DIDN'T GET YOUR MOBILE NUMBER"; 
 echo json_encode($data1);
    }
}
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~api fro Otp send end~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
// --------------------------------------------------------------------------------------------------confrim otp start-------------------------------------------------------------------------------------------------------
  if($_POST['sub_type']==2){
//   echo "hiiii";
       extract($_POST);
   
    if(!empty($mobile) && !empty($led_id) && $led_id !='0'){
        // echo "1.prem";
        $check = $db->from('otp')->sortDesc('id')->where('mobile',$mobile)->where('led_id',$led_id)->where('status',1)->where('cid',$cid)->select()->one();

if($otp===$check['otp'])
     {
         
        //  echo "2.prem";
      $data = $db->from('sm_main_form_20')->where('led_id',$led_id)->where('cid',$cid)->one();
          
        
             $check=$db1->sql("select email,f_name from sm_main_form_104 where del is null and mobile='".$_POST["mobile"]."'and role_id='".$_POST["role_id"]."' and f_name is not null and email is not null")->one();
      $check1 = count($check);
    //   print_r($check1);
       // $ch =$db1->from('sm_main_form_108')->where('del #,null')->where('cid',$cid)->where('name',$data['led_id'])->select()->one();
        	
            if($check1>0){
                //  echo "3.prem";
                //  print_r($_POST);
                $data1['mobile'] = $data['mobile'];
			$data1['email']=$check['email'];
				$data1['f_name']=$check['f_name'];
         $data1["error"]= false;
         $data1["error_msg"] = "Already register";
                
            }
        
            else{
                //  echo "4.prem";
$in = array('uid'=>$data['id'],'date'=>date('Y-m-d'),'cid'=>$data['cid'],'name'=>$data['led_id'],'mobile'=>$mobile,'device_id'=>$device_id,'cus_name'=>$data['name']);
 
$pn = $db1->from("sm_main_form_108")->insert($in)->execute();
        
      
			   
			
				// $stmt1 = $db->sql("SELECT cid,name,address,phone FROM sm_main_form_7 WHERE cid = '$cid' ")->one();
				
				// $row2 = $stmt1;
				 $data1['mobile'] = $data['mobile'];
			     $data1['uid']=$data['id'];
         $data1["error"]= false;
         $data1["error_msg"] = "Login Successfull";
        
     }
    
    }
    
    
    }
    else{
         $data1["error"]= TRUE;
		 $data1["error_msg"] = "Required parameters  missing!";
    }
     
             echo json_encode($data1);
  

  }   

// --------------------------------------------------------------------------------------------------confrim otp End-------------------------------------------------------------------------------------------------------

?>