<?php 


// ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$response=array();
// print_r($_POST);
extract($_REQUEST);
if($_POST['sub_type']==1){
    
    $sel=$db1->sql("select a.pro_type,a.id,(select count(id) from add_property where del is null and pro_view=1 and pro_type=a.id) as count,(select img from sm_main_form_1054 where del is null and pro_type=a.id )as img from sm_main_form_1002 as a where del is null and category=4 and (select img from sm_main_form_1054 where del is null and pro_type=a.id ) !='' ")->many();
  echo json_encode($sel);
}
if($_POST['sub_type']==2){
    // $subcatlist=$id;
    
      $viewQuery = "CREATE OR REPLACE VIEW listing1 AS SELECT a.id, a.aid, a.uid, a.bid, a.cid, a.sub_cat,a.client_address, a.listing_for, a.product_title, a.product_code,a.date, a.date_listing, a.expired_date, a.pro_view, a.user_approved_by, a.del, a.dtime,a.pro_type,(SELECT img_2 as c FROM sm_main_form_1009 WHERE pro_id = a.id AND del IS NULL LIMIT 1) as img1,(SELECT category FROM sm_main_form_1000 WHERE id = a.category AND del IS NULL) as category1,a.address,(SELECT pro_type FROM sm_main_form_1002 WHERE id = a.pro_type AND del IS NULL) as pro_type1,a.propriter_name,a.contact_number,a.business_name,a.company_address,a.description,a.price_in_number,a.product_name,a.postal_code,a.area,a.city,a.business_proof,a.years_been_in_the_field,a.website FROM add_property as a WHERE a.pro_view = 1 AND del IS NULL";
              
$viewCreation = $db1->sql($viewQuery)->execute();


    $resu = $db1->sql("SELECT * FROM listing1 WHERE pro_type = $id")->many();
    echo json_encode($resu);
}
if($_POST['sub_type']==3){
    // $subcatlist=$id;
    
//       $viewQuery = "";
              
// $viewCreation = $db1->sql($viewQuery)->execute();


    $resu = $db1->sql("SELECT * FROM add_property WHERE del is null and id=$id")->one();
    $resu = $db1->sql("SELECT * FROM add_property WHERE del is null and id=$id")->one();
    // if($resu['category']==2){
    $resu1 = $db1->sql("SELECT a.id,a.date,a.product_code,a.category,a.sub_cat,a.pro_type,a.customer_name,a.contact_number,a.price_in_alphabet,a.postal_code,a.area,a.city,a.description,a.vehicle_name,(select group_concat(img_og) from sm_main_form_1009 where pro_id=a.id limit 1) as img FROM add_property as a WHERE a.del is null and a.uid=".$resu['uid']."")->many();
    // echo json_encode($resu);}
    // }
    // else{
    //     $resu1 = $db1->sql("SELECT * FROM add_property WHERE del is null and uid=".$resu['uid']."")->many();
    // }
    foreach($resu1 as $val){
        // print_r($val['img']) ;
    
    $sk['price']=  $val['price_in_alphabet'];
$sk['client_name']=$val['customer_name'];
$sk['product_title']=  $val['vehicle_name'];
$sk['area']=  $val['area'];
// $sk['pro_type']=  $val['pro_type'];
$sk['city']=  $val['city'];
$sk['id']=  $val['id'];
$sk['client_mobile']=  $val['contact_number'];
$sk['img1']=  $val['img'];
$sk['description']=$val['description'];
// $sk['pro_size']=$val['description'];
// $sk['size_type']=$val['size_type'];
$sk['pro_code']=$val['product_code'];
// $sk['paid']=$val['paid'];
// $sk['Approved']=$val['pro_view'];
// $sk['pro_code']=$val['product_code'];
$skk[]=$sk;
    
    }  
    
    echo json_encode($skk);
}
if($_POST['sub_type']==4){
    // $subcatlist=$id;
    
//       $viewQuery = "";
              
// $viewCreation = $db1->sql($viewQuery)->execute();


    // $resu = $db1->sql("SELECT * FROM add_property WHERE del is null and id=$id")->one();
    // $resu = $db1->sql("SELECT * FROM add_property WHERE del is null and id=$id")->one();
    // if($resu['category']==2){
    $resu1 = $db1->sql("SELECT a.id,a.date,a.product_code,a.category,a.sub_cat,a.pro_type,a.customer_name,a.contact_number,a.price_in_alphabet,a.postal_code,a.area,a.city,a.description,a.vehicle_name,(select group_concat(img_og) from sm_main_form_1009 where pro_id=a.id limit 1) as img FROM add_property as a WHERE a.del is null and a.id=".$id."")->one();
   
    
    echo json_encode($resu1);
}


?>