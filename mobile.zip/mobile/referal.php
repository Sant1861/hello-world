
<?
$cid=$_POST['cid'];

// $cid='21472147';

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
// table for payment graph

if($_POST['sub_type']==1){
    extract($_POST);
    $otp = $user->generateotp(6);
    $otp1 = $user->generateotp(3);
    $dbb=$db1->sql("select MAX(id) as idd from sm_main_form_1018 ")->one();
    $cc=$dbb['idd']+1;
    $code="TBK".$otp1.$cc.$otp;
    $ins=array('user_id'=>$uid,'refral_code'=>$code,'status'=>1);
    $ins1=$db1->from('sm_main_form_1018')->insert($ins)->execute();
    $dataw['error']=FALSE;
    $dataw['error_mgs']="send valid mobile number";
    $dataw['code']=$code;
    $dataw['msg']="Truebroker: Dear Customer this is your referral code $code.Click to Claim coins https://truebroker.in/refer?redeem=$code Do share with your friends and earn your coins Free...!";
    echo json_encode($dataw); 
}
?>