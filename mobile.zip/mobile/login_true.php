<?php 


// ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);

$response=array();

$log = new LOGIN();
// if(!empty($_POST['role_id'])){
    

    
   if(isset($_POST['user']) && isset($_POST['password']) && isset($_POST['cid'])) {
        
    // receiving the post params
    $email = $_POST['user']; 
    $password = $_POST['password'];
    $companyid = $_POST['cid'];
    $device_id = $_POST['device_id'];
    $lt = $_POST['lt'];
    $ln = $_POST['ln'];
    $tok = $_POST['tok'];
    $token = $_POST['token'];


    // get the user by email and password
    $user_data = $log->getMobileLogin_new($email, $password,$companyid,$device_id,$lt,$ln,$tok,$token);
    if($user_data["error"] == FALSE) {
        
    	$response = $user_data;
    	$response["error"]= FALSE;
    	$response["error_msg"] = "Login Successfull";
		
		
		$new=fopen("sch_login.txt",'a');
        $CURRENTDATE=date("Y-m-d H:i:s"); 
        $write= $CURRENTDATE  ." - " .json_encode($_POST)."-".$response["error_msg"];
        fwrite($new,$write);
        fwrite($new,"\r\n");
        fclose($new);
    
       
        
        
        $arr=$db->sql("select led_id,name,aid,uid,bid from sm_main_form_20 where user_id='".$email."' and password='".$password."' and  del is null ")->one();
        $c_date=date('Y-m-d');
        $c_time=date('H:i:sa');
        $inf=array('uid'=>$user_data['uid'],'device_id'=>$device_id,'cid'=>$_POST['cid'],'status'=>"LogIn",'date'=>$c_date,'time'=>$c_time,'user_name'=>$email,'password'=>$password,'led_id'=>$user_data['led_id'],'name'=>$arr['name'],'latitude'=>$lt,'longitude'=>$ln); 
        $information=$db1->from('mobile_login')->insert($inf)->execute();
	
	 
    } else {
        
        // user is not found with the credentials
        $response["error"] = TRUE;
        $response["error_msg"] = "Login credentials are wrong. Please try again!";
        
        $new=fopen("sch_login.txt",'a');
        $CURRENTDATE=date("Y-m-d H:i:s"); 
        $write= $CURRENTDATE  ." - " .json_encode($_POST)."-".$response["error_msg"];;
        fwrite($new,$write);
        fwrite($new,"\r\n");
        fclose($new);
// 		exit();
    }

    } else {
    
    $response["error"] = TRUE;
    $response["error_msg"] = "user password missing!";
   
} 


// }
// else{
// $response["error"] = TRUE;
// $response["error_msg"] = "User Cannot find"; 
// }




 echo json_encode($response);



  ?>
  
  
  
  

  
  
  
  