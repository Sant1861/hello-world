<?php 
ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);

$type = $_POST['type'];
$data=$_POST;
//print_r($_POST);
$cdate=date('Y-m-d');


 //transaction--receipt--paytype
if($type==1) 
{
    
    
   $paytype= $db1->from('sm_main_form_1408')->where('del #',null)->select(array('id','name'))->many();
   echo json_encode($paytype);
   
   $url="receipt_api.php";
  $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE." CID -  " .$data['cid']."  TYPE  - " .$data['type']." MENU : " .$r_t." URL :  " .$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new); 
  
}



//transaction--receipt--payaccount
if($type==2)  
{
    
    $url="receipt_api.php";
    $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
    
    
    $payacc =  $db1->from('sm_main_form_1401')->where('del #',null)->where('cat @',array('4','5'))->select(array('id','name'))->many();
    echo json_encode($payacc);

}



//transaction--receipt--route
if($type==3){ 
    
    $url="receipt_api.php";
    $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
    
     $route =  $db1->from('sm_main_form_1410')->where('del #',null)->select(array('id','name','code'))->many();
     echo json_encode($route);
}



//transaction--receipt--collagent
if($type==4)  
{
    
    $url="receipt_api.php";
    $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new); 
    $collagent =  $db1->from('sm_main_form_1401')->where('del #',null)->where('cat',2)->select(array('id','name'))->many();
    echo json_encode($collagent);
    
}



//transaction--receipt--name autocomplete
if($type==5){ 
    
     $name = $data['name'];
     $url="receipt_api.php";
    $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$name."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
    
 
    $data = $db1->sql("select name as label,name,id as cusid,code,mobile,address from sm_main_form_1401 where del is null and cid=$cid and cat=1 and (name like '%".$name."%' or `code` like '%".$name."%' or `mobile` like '%".$name."%') ")
    ->many();
foreach($data as &$d)
{
    $d['label'] = $d['label']."-".$d['code'];
}
echo json_encode($data);
}



//transaction--receipt--mobile
if($type==6){  
    
    $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
    
     $mobile =  $db1->from('sm_main_form_1401')->where('del #',null)->select(array('id','name','mobile'))->many();
     echo json_encode($mobile);
}



//transaction--receipt--address
if($type==7){  
    
    $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
    
 $address =  $db1->from('sm_main_form_1401')->where('del #',null)->select(array('id','name','address'))->many();
     echo json_encode($address);
}



//chitid autocomplete receipt
if($type==8){
    // print_r($data);
    
     $search = $data['term'];
    $name=$data['name'];
    
    $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url."-".$search."-".$name  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
    
    // $search = $data['term'];
    // $name=$data['name'];
    
    $data = $db1->sql("SELECT id as chitid,id as value,name,gname,grp_no,ch_value,t_no FROM sm_main_form_1417 WHERE del IS NULL AND name=$name AND (gname LIKE "."'%".$search."%' or t_no LIKE "."'%".$search."%' or id LIKE "."'%".$search."%')")->many();

foreach($data as &$d)
{
        //   $bal = $db1->from('sm_main_form_140')
        //   ->where('del #',null)
        //   ->where('led_id',$d['name'])
        //   ->where('chit_id',$d['id'])
        //   ->select('sum(amount)')
        //   ->one();
          
          $d['value'] = $d['value']." - ".$d['gname']." | ".$d['t_no'];
          
    $bal = $db1->sql("select sum(amount) as running_amt from sm_main_form_140 where  chit_id='".$d['value']."' and trans_type not in (12,14,16,17,18) and date <= '".$cdate ."' and  del is null and status is null")->one();
             
          $col_type = $db1->from('sm_main_form_1416')->where('id',$d['grp_no'])->where('del #',null)->select('ins_type')->one();
    $d['col_type'] = $col_type['ins_type'];
    if(empty($d['col_type'])){
        $d['col_type']='0';
    }
    
      if(empty($bal['running_amt'])) {
              $bal['running_amt']="0";
          
            
      }  else{
           $bal['running_amt']=abs($bal['running_amt']);
      } 
      $d['balance'] =  $bal['running_amt']; 

   if(empty($d['gname'])) {
       $d['gname']="0";
      }  else{
        $d['gname']=$d['gname'];
      } 
      if(empty($d['grp_no'])) {
        $d['grp_no']="0";
      }  else{
         $d['grp_no']=$d['grp_no'];
      } 
 
     
  
}
echo json_encode($data);
}


//save query --receipt
if($type==9){
    
    /* request save*/ 
    
    $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
    
    /* 'ef'=>1
     is mobile save  entry different */
      
    
        $chit_id=$data['chit_id'];
   
  
//     if($data['cid']=="85798178"){
//      // $data['agent']=$data['led_id'];
      
//       $ss=$db->sql("select def_acc,led_id from sm_main_form_20 where del is null and id='".$data['uid']."' ")->one();
//       $data['pay_acc']=$ss['def_acc'];
//       $data['agent']=$ss['led_id'];
//   }
  
 $data = array('date'=>date('Y-m-d',strtotime($data['date'])),'cid'=>$data['cid'],'ef'=>1,'aid'=>$data['aid'],'uid'=>$data['uid'],'led_id'=>$data['led_id'],'name'=>$data['name'],'mobile'=>$data['mobile'],'address'=>$data['address'],'chit_id'=>$chit_id,'balance'=>$data['balance'],'amount'=>$data['amount'],'p_type'=>$data['p_type'],'pay_acc'=>$data['pay_acc'],'route'=>$data['route'],'col_type'=>$data['col_type'],'agent'=>$data['agent'],'refr'=>$data['refr']);
       $data1 =  $db1->from('sm_main_form_1419')
             ->insert($data)
             ->execute();
             
                	$lastid = $db1->insert_id;
           	
           	//save query for 140
         $re = array('cid'=>$data['cid'],'uid'=>$data['uid'],'trans_type'=>11,'trans_name'=>'Chit Receipt','trans_no'=>$lastid,'date'=>date('Y-m-d',strtotime($data['date'])),'led_id'=>$data['led_id'],'amount'=>'-'.$data['amount'],'chit_id'=>$chit_id,'descr'=>$data['temp_id'],'remark'=>$data['mobile'].",".$data['address']);
                         
                         $name = $db1->from('sm_main_form_140')->insert($re)->sql();
                       
                        $db1->sql($name)->execute();
                        
                        //  print_r($name);
                        
                        if($data['p_type'] !='2'){
                         $re1 = array('cid'=>$data['cid'],'uid'=>$data['uid'],'trans_type'=>11,'trans_name'=>'Chit Receipt','trans_no'=>$lastid,'date'=>date('Y-m-d',strtotime($data['date'])),'led_id'=>$data['pay_acc'],'amount'=>$data['amount'],'descr'=>$data['temp_id'],'remark'=>$data['mobile'].", ".$data['address']);
                         
                         $name1 = $db1->from('sm_main_form_140')->insert($re1)->sql();
                       
                        $db1->sql($name1)->execute();
                        //  print_r($name1);
                        }

           
            //  $user =new USER();
     
             
                      
    //                  if ($cid=='45281857' || $cid=='21472147') {
                            
    //                         $grpdata=$db1->sql("select * from sm_main_form_1417 where del is null and name='".$data['led_id']."' and id='".$data['chit_id']."' ")->one();
                             
    //                          $gs=$grpdata['gname']."/".$grpdata['ch_value'];
    //   $message="We have received your payment of ".$data['amount']." towards SJVCPL Chits Group $gs, Ticket #".$grpdata['t_no'].". Thank you.";
	   //// $message="Dear ".$data['name'].", ReciptNo: ".$lastid.", Amount: ".$data['amount'].",Balance: ".$data['balance'].", Thank you for Payment at Thank you SriJothivinayaga chits Contact: 9566616720. From CHITSOFT";
	    
	   // $phone=$data["mobile"];
	   //// $template_id="22";
	   //$template_id="54";
    //     $user->sendsms_api($phone,$message,$cid,$template_id);

	   //// return true;
    //     }
        
         if($data1==true  &&  $re==true){
          $response['error']=false;
          $response['error_msg']="Receipt Saved successfully";
            }
            else {
                 $response['error']=true;
          $response['error_msg']="Receipt Not Saved";
            }
            echo json_encode($response);
                
}



//viewlist 
if($type==10){
    
      /* request save*/ 
      $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
    
    $result = $db1->sql("SELECT id,date,led_id,name,mobile,amount,chit_id,p_type,pay_acc,route,agent,address,refr,grp_name as gname,grp_no as t_no from sm_main_form_1419 WHERE  del is null ORDER BY dtime DESC limit 10")->many();
    
    //  $result =  $db1->from('sm_main_form_1419')
    // //  ->limit(10)
    //  ->where('del #',null)->where('ef',1)->select(array('date','name','mobile','amount','chit_id','p_type','pay_acc','route','agent'))->sortDesc('date')->many();
     
      foreach($result as &$val)
    {
        
        $val['date']=date('d-m-Y',strtotime($val['date']));
        
//   $name =  $db1->from('sm_main_form_1401')->where('del #',null)->where('id',$val['led_id'])->one();
//      $val['led_id'] = $name['name'];
        
     $paytype =  $db1->from('sm_main_form_1408')->where('del #',null)->where('id',$val['p_type'])->one();
     $val['p_type_name'] = $paytype['name'];
    
     $payacc =  $db1->from('sm_main_form_1401')->where('del #',null)->where('id',$val['pay_acc'])->one();
     $val['pay_acc_name'] = $payacc['name'];
    
     $route =  $db1->from('sm_main_form_1410')->where('del #',null)->where('id',$val['route'])->one();
     $val['route_name'] = $route['name'];
    
     $agent =  $db1->from('sm_main_form_1401')->where('del #',null)->where('id',$val['agent'])->one();
     $val['agent_name'] = $agent['name'];  
     
        $gname =  $db1->from('sm_main_form_1417')->where('del #',null)->where('id',$val['chit_id'])->one();
     $val['gname'] = $gname['gname'];
      $val['t_no'] = $gname['t_no'];
     
     
      if(empty($val['name'])) {
       $val['name']="0";
      }  
      if(empty($val['mobile'])) {
        $val['mobile']="0";
      }
       if(empty($val['amount'])) {
       $val['amount']="0";
      }
       if(empty($val['chit_id'])) {
       $val['chit_id']="0";
      }
       if(empty($val['p_type'])) {
       $val['p_type']="0";
      }
       if(empty($val['pay_acc'])) {
       $val['pay_acc']="0";
      }
       if(empty($val['route'])) {
       $val['route']="0";
      }
       if(empty($val['agent'])) {
       $val['agent']="0";
      }
    }
     
    
 
     echo json_encode($result);
}



//view list -- today date
if($type==11){
    
    
      /* request save*/
      $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
    
    
// print_r($cdate);
     $res = $db1->sql("SELECT id,date,led_id,name,mobile,amount,chit_id,p_type,pay_acc,route,agent,grp_name as gname,grp_no as t_no  from sm_main_form_1419 WHERE  date='$cdate' and del is null ORDER BY dtime DESC ")->many();
     
      foreach($res as &$val)
    {
        $val['date']=date('d-m-Y',strtotime($val['date']));
    
         $gname =  $db1->from('sm_main_form_1417')->where('del #',null)->where('id',$val['chit_id'])->one();
     $val['gname'] = $gname['gname'];
      $val['t_no'] = $gname['t_no'];
      
     $paytype =  $db1->from('sm_main_form_1408')->where('del #',null)->where('id',$val['p_type'])->one();
     $val['p_type_name'] = $paytype['name'];
    
     $payacc =  $db1->from('sm_main_form_1401')->where('del #',null)->where('id',$val['pay_acc'])->one();
     $val['pay_acc_name'] = $payacc['name'];
    
     $route =  $db1->from('sm_main_form_1410')->where('del #',null)->where('id',$val['route'])->one();
     $val['route_name'] = $route['name'];
    
     $agent =  $db1->from('sm_main_form_1401')->where('del #',null)->where('id',$val['agent'])->one();
     $val['agent_name'] = $agent['name'];    
    }
     
     echo json_encode($res);
}



// dashboard
if($type==12){
    
      /*start request save*/
      $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/ 
    
    
      $resm = array();
      $member=$db1->from('sm_main_form_1401')
     ->where('del #',null)
     ->where('cat',1)
//   ->where('aid',111)
     ->select(array('count(*) as member'))
     ->one();
     
      $res['title']="member";
      $res['value']= $member['member'];
      $res = array_push($resm,$res);
      $res = array();
//    echo json_encode(array($res));

   
$chitgroup=$db1->from('sm_main_form_1416')
     ->where('del #',null)
//   ->where('aid',111)
     ->select(array('count(*) as chitgroup'))
     ->one();
     
     //$res['2'] = $chitgroup;
       $res['title']="chitgroup";
       $res['value']=$chitgroup['chitgroup'];
       $res = array_push($resm,$res);
       $res = array();
//     echo json_encode($chitgroup);
   
$employee=$db1->from('sm_main_form_1401')
     ->where('del #',null)
     ->where('cat',3)
//   ->where('aid',111)
     ->select(array('count(*) as employee'))
     ->one();
     
//    $res['3'] =$employee;
      $res['title']="employee";
      $res['value']=$employee['employee'];
      $res = array_push($resm,$res);
      $res = array();
//    echo json_encode($employee);  
   if($cid=='45281857'){
       $totalcollection =$db1->from('sm_main_form_1419')
     ->where('del #',null)
  ->where('date',$cdate)
     ->select(array('sum(amount) as  totalcollection '))
     ->one();
     
//    $res['4'] =$totalcollection;
      $res['title']="totalcollection";
      $res['value']=number_format($totalcollection['totalcollection']);
      $res = array_push($resm,$res);
      $res = array();
   }

      else{
          $con2 = mysqli_connect('localhost','softuser','Soft@2021',"s_".$cid);    
$machine_id = "select  SUM(collectamt) as totalcollection from transact where collectdt='$cdate' and cancel='N' " ; 
$result = mysqli_query($con2,$machine_id);

while($row= mysqli_fetch_array($result, MYSQLI_ASSOC))
  {
    // $res['4'] =$totalcollection;
      $res['title']="totalcollection";
      $res['value']=number_format($row['totalcollection']);
      $res = array_push($resm,$res);
      $res = array();
  }
      }

  
  
  
    $res['title']="Regular";
    $res = array_push($resm,$res);
      $res = array();
    $res['title']="Arrears";
    $res = array_push($resm,$res);
      $res = array();

      

      
      
    //  $res['title']=array('member','chitgroup','employee','totalcollection');   //  $res['value']=array($member['member'],$chitgroup['chitgroup'],$employee['employee'],$totalcollection['totalcollection']);
     
    
    //  $r=array('member'=>$member['member'],'chitgroup'=>$chitgroup['chitgroup'],'employee'=>$employee['employee'],'totalcollection'=>$totalcollection['totalcollection']);
    
     
  echo json_encode($resm);
}



//chitgroup
if($type==13){
     $gname = $data['value'];
     /*start request save*/ 
     
     $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." CID :  " . $data['cid'] ." TYPE  : " . $data['type']." MENU  : " . $r_t."  URL  : ".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
     
      
$chitgroup1 = $db1->sql("select id,name from sm_main_form_1416 where del is null and cid=$cid and  (name like '%".$gname."%') ")->many();
    // $chitgroup1= $db1->from('sm_main_form_1416')
    // // ->limit(10)
    // ->where('del #',null)
    // ->select(array('id','name'))
    // ->many();
     echo json_encode($chitgroup1);
     
      
}



//balance menu (report)
if($type==14){
    
     /*start request save*/ 
     $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t ."-".$url ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
    
 $p = $db1->from('sm_main_form_1419')->where('ef',1)->where('del #',null)->where('cid',$data['cid'])->where('route',$data['route'])->select(array('chit_id','route','grp_name','name'))->many();
//  echo $p;
 foreach($p as &$q)
 {
   if(empty($q['route'])) {
      $q['route']="0";
      }  
     
   if(empty($q['grp_name'])) {
      $q['grp_name']="0";
      }  
      
 
   if($q==true){
      $q['pending']="0";
      }
      
 }
   echo json_encode($p);
    
}


//statement viewlist
if($type==18){
   
    /*start request save*/
    $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
//   print_r($data);
    
    $led_id=$data['user_id'];
    $chit_id=$data['chit_id'];
    $rdate=$date['date'];
     $name=$data['device_name'];
     
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $name." - " . $led_id." - " . $chit_id." - " . $rdate  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
    
    
    
     $cond='';
            if(!empty($led_id)){
                $cond .= " and led_id='".$led_id."' ";
            }
            if(!empty($chit_id)){
                $cond .= " and chit_id='".$chit_id."' ";
            }
            if(!empty($rdate)){
                $cond .= " and date <='".date('Y-m-d',strtotime($rdate))."' ";
            }
        $qry = $db1->sql('SELECT date_format(date, "%d/%m/%Y") as date,ABS(amount) as amount,trans_type,trans_name,ABS(CASE WHEN sm_main_form_140.amount<0 THEN sm_main_form_140.amount ELSE 0 END) as credit,
ABS(CASE WHEN sm_main_form_140.amount>=0 THEN sm_main_form_140.amount ELSE 0 END) as debit FROM sm_main_form_140  WHERE   del IS NULL '.$cond.'  order by date')->many();
// echo $qry;

  
  echo json_encode($qry);
}



//filter menu(report menu)
if($type==22){ 
    
     /*start request save*/
     $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
      
    
      $search = $data['term'];
    $cond ="";
    if(!empty($data['date'])){
    $cond .= " AND date='".$data['date']."' ";
    }
                $qry = $db1->sql("SELECT date,name,mobile,amount,chit_id,p_type,pay_acc,route,agent FROM sm_main_form_1419 WHERE del is null $cond AND (name LIKE "."'%".$search."%' or agent LIKE "."'%".$search."%')")->many();
                foreach($qry as &$val)
    {
        $val['date']=date('d-m-Y',strtotime($val['date']));
        
    //  $name =  $db1->from('sm_main_form_1401')->where('del #',null)->where('id',$val['led_id'])->one();
    //  $val['led_id'] = $name['name'];
        
     $paytype =  $db1->from('sm_main_form_1408')->where('del #',null)->where('id',$val['p_type'])->one();
     $val['p_type'] = $paytype['name'];
    
     $payacc =  $db1->from('sm_main_form_1401')->where('del #',null)->where('id',$val['pay_acc'])->one();
     $val['pay_acc'] = $payacc['name'];
    
     $route =  $db1->from('sm_main_form_1410')->where('del #',null)->where('id',$val['route'])->one();
     $val['route'] = $route['name'];
    
     $agent =  $db1->from('sm_main_form_1401')->where('del #',null)->where('id',$val['agent'])->one();
     $val['agent'] = $agent['name']; 
     
       if(empty($val['route'])){
        $val['route'] = '0';
       }
         if(empty($val['agent'])){
        $val['agent'] = '0';
       }
    }
                echo json_encode($qry); 
  
}




//User paymentmenu
if($type==23){
    
     /*start request save*/ 
     $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
    
     $search = $data['term'];
   
                 $paymentmenu = $db1->sql("SELECT sub_name,bank_ac as Bank_Ac,bank_name as Bank_Name,bank_branch as Branch,bank_ifsc as IFSC FROM sm_main_form_1434 WHERE del is null  AND (Bank_Ac LIKE "."'%".$search."%')")->many();
                
   // $paymentmenu= $db1->from('sm_main_form_1434')->where('del #',null)->where('cid',$data['cid'])->where('bank_ac %', '%'.$search.'%')->select(array('sub_name','bank_ac as Bank_Ac','bank_name as Bank_Name','bank_branch as Branch','bank_ifsc as IFSC'))->many();

    
    //   foreach($paymentmenu as &$val){
    //      if(empty($paymentmenu['sub_name'])){
    //   $val['sub_name'] = '0';
    //   }else {
    //     $val['sub_name']="'".$val['sub_name']."'";
    //     }
    //     if(empty($val['Bank_Name'])){
    //         $val['Bank_Name']='0';
    //     }
    //     else{
    //     $val['Bank_Name']="'".$val['Bank_Name']."'";
    //     }  
        
        
    //      if(empty($val['Bank_Ac'])){
    //     $val['Bank_Ac']='0';
    //     }
    //     else{
    //     $val['Bank_Ac']="'".$val['Bank_Ac']."'";
    //     } 
        
        
    //      if(empty($val['Branch'])){
    //       $val['Branch']='0';
    //     }
    //     else{
    //      $val['Branch']="'".$val['Branch']."'";
    //     } 
        
    //     if(empty($val['IFSC'])){
    //       $val['IFSC']='0';
    //     }
    //     else{
    //      $val['IFSC']="'".$val['IFSC']."'";
    //     } 
        
        
    //   }
    
    echo json_encode($paymentmenu);
}




 
 
 
 
//Admin Payment
 if($type==26){
     
      /*start request save*/ 
      $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
      $data=array('cid'=>$data['cid'],'ef'=>1,'uid'=>$data['uid'],'aid'=>$data['aid'],'date'=>date('Y-m-d',strtotime($data['date'])),'amount'=>$data['amount'],'ch_value'=>$data['chit_value'],'chit_id'=>$data['chit_id'],'refer'=>$data['reference'],'cus_name'=>$data['cus_name'],'ac_no'=>$data['ac_no'],'ac_date'=>$data['ac_date'],'req_by'=>$data['req_by']);
      
    //   'pre_date'=>$data['pre_date'],'pay_date'=>$data['pay_date'],
     
     $adminpayment= $db1->from('sm_main_form_1445')
                   ->insert($data)
                   ->execute();
                   //echo $enquiry;
                   
                   	$lastid = $db1->insert_id;
           	
           	//save query for 140

	$led_id=$data['led_id'];
	
	$r= $db1->from('sm_main_form_1401')->where('del #',null)->where('id',$data['led_id'])->select(array('name','mobile'))->one();

                         $re = array('cid'=>$data['cid'],'uid'=>$data['uid'],'trans_type'=>22,'trans_name'=>'payment dairy','trans_no'=>$lastid,'date'=>date('Y-m-d',strtotime($data['date'])),'led_id'=>$data['led_id'],'amount'=>$data['amount'],'chit_id'=>$data['chit_id'],'descr'=>$data['temp_id'],'remark'=>$r['name']."-".$r['mobile']);
                         
                         $name = $db1->from('sm_main_form_140')->insert($re)->sql();
                       echo $name;
                        $db1->sql($name)->execute();
           
           
            if($adminpayment==true&&$re==true){
          $response['error']=false;
          $response['error_msg']="Payment Saved successfully";
            }
            else {
                 $response['error']=true;
          $response['error_msg']="Payment Not Saved";
            }
            echo json_encode($response);
   
                
     
 }
 
 
 
 
 //Req_by field (Admin Payment)
 if($type==27){
     
      /*start request save*/ 
      $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
     $req_by =$db->from('sm_main_form_11')->where('list_id',137)->select(array('name','value as id'))->many();
echo json_encode($req_by);

 }
 
 
 
 
 
 //ac_date (Admin Payment)
 if($type==28){
    //  print_r()
    
     /*start request save*/ 
     $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
        $ac_date = $db1->from('sm_main_form_1425')
->where('cid', $data['cid'])
->where('chit_id',$data['chit_id'])
->where('led_id',$data['led_id'])
->where('due',$data['ac_no'])
 ->where('del #',null)
->select('date')
->one();

$ac_date['date'] = date('d-m-Y',strtotime($ac_date['date']));


echo json_encode($ac_date);

 }
 
 //admin payment viewlist
 if($type==29){
      /*start request save*/ 
      $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
    //  $paymentviewlist= $db1->from('sm_main_form_1445')->where('del #',null)->where('ef',1)->select(array('date,amount,ch_value,chit_id,refer,cus_name,ac_no,ac_date,req_by'))->many();
       $paymentviewlist = $db1->sql("SELECT date_format(date, '%d-%m-%Y') as date,amount,ch_value,chit_id,refer,cus_name,ac_no,ac_date,req_by,chit_id as gname,chit_id as t_no from sm_main_form_1445 WHERE del is null ORDER BY dtime DESC ")->many();
     foreach($paymentviewlist as &$val){
         
         $req_by =$db->from('sm_main_form_11')->where('list_id',137)->where('value',$val['req_by'])->where('del #',null)->one();
            $val['req_by']=$req_by['name'];
         
          $gname =  $db1->from('sm_main_form_1417')->where('del #',null)->where('id',$val['chit_id'])->one();
     $val['gname'] = $gname['gname'];
      $val['t_no'] = $gname['t_no'];
     }
     
     echo json_encode($paymentviewlist);
 }


//delete query for Receipt
if($type==30){
    // print_r($data);
    
     /*start request save*/
     $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
    
$id=$data['id'];    
$data1 = array('del' => 1);
$where = array('id'=>$id,'ef' => 1);

$delete_rec= $db1->from('sm_main_form_1419')
    ->where($where)
    ->update($data1)
    ->execute();
    
         if($delete_rec==true){
          $response['error']=false;
          $response['error_msg']="Deleted successfully";
            }
            else {
                 $response['error']=true;
          $response['error_msg']="Data Not deleted";
            }
    echo json_encode($response);
}

/* update for receipt */
if($type==31){
    // print_r($data);
    
     /*start request save*/ 
     $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
    
$id=$data['id']; 

$data1 = array('id'=>$id,'date'=>date('Y-m-d',strtotime($data['date'])),'cid'=>$data['cid'],'uid'=>$data['uid'],'led_id'=>$data['led_id'],'name'=>$data['name'],'mobile'=>$data['mobile'],'address'=>$data['address'],'chit_id'=>$data['chit_id'],'balance'=>$data['balance'],'amount'=>$data['amount'],'p_type'=>$data['p_type'],'pay_acc'=>$data['pay_acc'],'route'=>$data['route'],'col_type'=>$data['col_type'],'agent'=>$data['agent'],'refr'=>$data['refr']);
$where = array('ef' => '1','id'=>$id);

$update_rec= $db1->from('sm_main_form_1419')
    ->where($where)
    ->update($data1)
    ->execute();
    // echo $update_rec;
    
                    if($update_rec==true){
          $response['error']=false;
          $response['error_msg']="Updated successfully";
            }
            else {
                 $response['error']=true;
          $response['error_msg']="Data Not Updated";
            }
    echo json_encode($response);
}




if($type==32){
    
     /*start request save*/ 
     $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
    $details=$db1->from('sm_main_form_1401')->where('cid',$data['cid'])->where('cat',1)->select(array('fhname as short_time','id','name','mobile','phone'))->limit(10)->many();
    echo json_encode($details);
}
if($type==33){
    
     /*start request save*/
     $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
    $agent=$db1->from('sm_main_form_1401')->where('cat',3)->select(array('name','mobile','phone'))->limit(10)->many();
    echo json_encode($agent);
}

/*  pay type for online payment*/
if($type==34) 
{
    
     /*start request save*/ 
     $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
   $paytype= $db1->from('sm_main_form_1408')->where('del #',null)->where('id @',array('2','3','4','5'))->select(array('id','name'))->many();
   echo json_encode($paytype);
  
}


// dashboard
if($type==35){
    
     /*start request save*/
     $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
      $resm = array();
      
      /*scheme */      
  $Scheme = $db1->from('sm_main_form_1415')
    ->where('del #',null)
 //   ->where('cat',2)
    ->select(array('count(*) as cnt'))
    ->one(); 
    
    //    $res['4'] =$Scheme;
      $res['title']="Scheme";
      $res['value']=number_format($Scheme['cnt']);
      $res = array_push($resm,$res);
      $res = array();
    
    
$result2 = $db1->from('sm_main_form_1417')
    ->where('del #',null)
    ->select(array('count(*) as cnt'))
    ->one();
    
    
       //    $res['4'] =$result2;
      $res['title']="Chit Tickets";
      $res['value']=number_format($result2['cnt']);
      $res = array_push($resm,$res);
      $res = array();
      
      
      $receipt1=$db1->from('sm_main_form_1419')
    ->where('del #',null)
    ->where('p_type',1)
    ->select(array('sum(amount) as amt','count(*) as cnt'))
    ->one();
    
      //    $res['4'] =$result2;
      $res['title']="Receipt-Cash";
      $res['value']=number_format($receipt1['cnt']);
      $res = array_push($resm,$res);
      $res = array();
      
      
    $receipt2=$db1->from('sm_main_form_1419')
    ->where('del #',null)
    ->where('p_type',2)
    ->select(array('sum(amount) as amt','count(*) as cnt'))
    ->one();
    
      
      $res['title']="Receipt-Cheque";
      $res['value']=number_format($receipt2['cnt']);
      $res = array_push($resm,$res);
      $res = array();
      
      
    
$payment1=$db1->from('sm_main_form_1420')
    ->where('del #',null)
    ->select(array('sum(amount) as amt','count(*) as cnt'))
    ->one(); 
    
   
      $res['title']="Payment";
      $res['value']=number_format($payment1['cnt']);
      $res = array_push($resm,$res);
      $res = array();
      
      
    
$divident=$db1->from('sm_main_form_1435')
    // ->where('del #',null)
    ->select(array('sum(amount) as amt','count(*) as cnt'))
    ->one(); 
    
     
      $res['title']="Dividents";
      $res['value']=number_format($divident['cnt']);
      $res = array_push($resm,$res);
      $res = array();
         
         
           $res['title']="Receipt-Cash";
      $res['value']="Rs.".number_format($receipt1['amt']);
      $res = array_push($resm,$res);
      $res = array();
      
      $res['title']="Receipt-Cheque";
      $res['value']="Rs.".number_format($receipt2['amt']);
      $res = array_push($resm,$res);
      $res = array();
      
       $res['title']="Payment";
      $res['value']="Rs.".number_format($payment1['amt']);
      $res = array_push($resm,$res);
      $res = array();

 $res['title']="Receipt-Cheque";
      $res['value']="Rs.".number_format($divident['amt']);
      $res = array_push($resm,$res);
      $res = array();


    
     
  echo json_encode($resm);
}


if($type==36){
    // print_r($_POST);
    // extract($_POST);
    
    $name = $data['value'];
    
    // print_r($data['name']);
  $data = $db1->sql("select a.id as id,a.id as value ,a.temp_id,a.gp_tno,b.name,b.name as name,b.id as led_id,a.grp_no as grpno,b.route as route,a.temp_id as temp_id,a.t_no as t_no,a.gname as gname,b.mobile as mobile,b.address as address,a.cd_date as cd_date,a.td_date as td_date,a.lname as lname,a.agent as agent from sm_main_form_1417 AS a INNER JOIN sm_main_form_1401 AS b ON a.name=b.id where a.del is null and a.cid=$cid and  ( a.id like '%".$name."%'  OR a.t_no like '%".$name."%' OR a.gname like '%".$name."%' OR a.mobile like '%".$name."%') limit 20" )->many();
    
    // echo $data['led_id'];
    foreach($data as &$d)
{
    $d['value'] = $d['id']." | ".$d['name']." | ".$d['gp_tno']." | ".$d['temp_id'];
}
    echo json_encode($data);
    
    
      /*start request save*/
  
     $url="receipt_api.php";
     $r_t="AUTOCOMPLETE";
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." CID : " . $cid ." TYPE : " . $type." MENU : " . $r_t."  URL : ".$url." serach response ".$name  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
}


   



if($type==37){
    
    
     /*start request save*/
     $name=$data['name'];
     $url="receipt_api.php";
     $r_t="member_report";
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url."-".$name  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
    $name=$data['name'];
    $chitid=$db1->sql("SELECT id,name,sub_name,gname FROM sm_main_form_1417 WHERE name=$name")->many();
    echo json_encode($chitid);
    
    
}
if($type==38){
    

      
    $name=$data['cus_id'];
    $chitid=$db1->sql("SELECT id  FROM sm_main_form_1417 WHERE name=$name")->many();
    echo json_encode($chitid);
    
    
}



?>