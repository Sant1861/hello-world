<?php
ini_set("display_errors",1);
$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db=new Dbclass();
$db1=new Dbclass($cid);

$type=$_POST['type'];
extract($_POST); 

if($type==17){
    
    $response=array();
$date=date('Y-m-d',strtotime($_POST['date']));
 $send=$db1->sql("select chit_id as cl_no,amount,name,id as receiptno,p_type,dtime from sm_main_form_1419 where del is null and date='$date' and cid='$cid' and agent='".$_POST['led_id']."' ")->many();
foreach($send as &$d){

    
        $pay_t=$db1->sql("select * from sm_main_form_1408 where id='".$d['p_type']."' and del is null  ")->one();
        $d['p_type']=$pay_t['name'];
        
        $gl=$db1->sql("select * from sm_main_form_1417 where del is null and id='".$d['cl_no']."' ")->one();
        $d['cl_no']=$gl['chit_no'];
        
}

//  $cash=$db1->sql("select count(id) as cash,sum(amount) as cashamt from sm_main_form_1419 where p_type='1' and del is null and date='$date' and cid='$cid' and agent='".$_POST['led_id']."'  ")->one();
//  $bank=$db1->sql("select count(id) as bank,sum(amount) as bankamt from sm_main_form_1419 where p_type='2' and del is null and date='$date' and cid='$cid' and agent='".$_POST['led_id']."'  ")->one();
  
    // $response[] = $send;
    // $response[] = $cash;
    // $response[] = $bank;
   echo json_encode($send);
   
//   echo json_encode(array_merge($cash,$bank));
    
    $url="mcpl_agent_recycle_view.php";
     $r_t='Recycleview';
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." CID :  " . $_POST['cid'] ." TYPE  : " . $_POST['type']." DATE  : " . $date ." MENU  : " . $r_t."  URL  : ".$url."  AGENT   : ".$_POST['led_id']  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);    
    
// extract($_POST);   
/* Start Save Request */
    
    
}






?>