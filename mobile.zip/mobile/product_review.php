<?php 
$cid=$_POST['cid'];
require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db= new Dbclass();
$db1=new Dbclass($cid);
ini_set("display_errors",0);
$citys="";
extract($_REQUEST);
$cid=13051305;



if($type == 17){
    
    
if($sub_type == 1){ 
    
    // print_r($_POST);
   $insert=$db1->from('sm_main_form_1021')
                     ->insert(array("pro_id"=>$pro_id,"cus_id"=>$customer_id,"features"=>$one,"price"=>$two,"safety"=>$three,"locality"=>$four,"review"=>"$comments"))
                     ->execute();
                     if($insert==true){
                        $response['error']=false;
                        $response['error_mgs']="Your data is  insert";
                     }
                     else{
                        $response['error']=true;
                        $response['error_mgs']="Your data is not insert";
                     }
                     
                     
                     echo json_encode($response);
            }
if($sub_type == 2){ 
  $select=$db1->sql("select * from sm_main_form_1021 where pro_id='$pro_id' and  del is null")->many();
  foreach($select as &$val){
  $user=$db->sql("select u_name from sm_main_form_20 where id=".$val['cus_id']."")->one();
  $val['user_name']= $user['u_name'];

}
echo json_encode($select);

            }
}
?>