<?
ini_set("display_errors",1);

$cid=$_POST['cid'];
 $con2 = mysqli_connect('localhost','softuser','Soft@2021',"s_".$cid); 

$type = $_POST['type'];
$data=$_POST;



if($type==5){
  
    $cdate=date('Y-m-d');
    
$resm=array();


$view_receipt = "select sum(collectamt) as cash,count(collectamt) as c from transact where collectdt='$cdate' and modepay='C' "; 
$result = mysqli_query($con2,$view_receipt);
$row1 = mysqli_fetch_array($result, MYSQLI_ASSOC);
$res['title']="Cash";
$res['value']=$row1['cash'];
$res['nom']=$row1['c'];
$res = array_push($resm,$res);
$res = array();



$view_receipt1 = "select sum(collectamt) as cheque,count(collectamt) as q from transact where collectdt='$cdate' and modepay='Q' "; 
$result1= mysqli_query($con2,$view_receipt1);
$row2 = mysqli_fetch_array($result1, MYSQLI_ASSOC);
$res['title']="Cheque";
$res['value']=$row2['cheque'];
$res['nom']=$row2['q'];
$res = array_push($resm,$res);
$res = array();


$view_receipt2 = "select sum(collectamt) as total ,count(collectamt) as t from transact where collectdt='$cdate' "; 
$result2= mysqli_query($con2,$view_receipt2);
$row3 = mysqli_fetch_array($result2, MYSQLI_ASSOC);
$res['title']="Totalcollection";
$res['value']=$row3['total'];
$res['nom']=$row3['t'];
$res = array_push($resm,$res);
$res = array();

    echo json_encode($resm);
     

}

  
?>