<?php
if($type==14)
  {
    extract($_POST);
     $check = $db->from('sm_main_form_otp')->where('led_id',$id)->where('status',1)->one();
     //$check['otp']=242347;
     if($otp==$check['otp'])
     {
       $cid = $check['cid'];
      require_once('../../app/sys/config/dbconfig2.php');
         $data = $db1->from('sm_main_form_1601')->where('id',$id)->one();
        $pn = $db1->from("sm_main_form_1602")->where('cid',$cid)->where('cus_id',$data['id'])->update(array('device_id'=>$device_id))->execute();
         	$data["error"]= FALSE;
		 $data["error_msg"] = "Login Successfull";
     }
     else
     {
        $data["error"] = TRUE;
    $data["error_msg"] = "Your otp number is wrong"; 
     }
             echo json_encode($data);
  }
  ?>