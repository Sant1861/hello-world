<?php
// LOG..

ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1=new Dbclass($cid);

$type=$_POST['type'];

if($type==19){
    
    $name = $_POST['name'];
     $url="mcpl_subs_auto.php";
    $r_t="name_auto";
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." CID :  " . $_POST['cid'] ." TYPE  :  " . $_POST['type']." MENU :  " . $r_t." SEARCH  :  ".$name." URL  :  ".$url . "]" ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
    
 
$data = $db1->sql("select name as label,name,id as cusid,code,mobile,address from sm_main_form_1401 where del is null and cid=$cid and cat=1 and (name like '%".$name."%' or `code` like '%".$name."%' or `mobile` like '%".$name."%') ")
    ->many();
foreach($data as &$d)
{
    $d['label'] = $d['label']."-".$d['code'];
}
echo json_encode($data);
    
}



?>