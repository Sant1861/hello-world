<?php
// Log..

ini_set("display_errors",1);
$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1=new Dbclass($cid);

$type=$_POST['type'];
extract($_POST);

if($type==8){
    
     $ds=$db1->sql("select * from sm_main_form_1401 where del is null and id='$led_id' ")->one();
    $agent=$ds['code'];
   
    
    $send=$db1->sql("select * from sm_main_form_1417 where agent='$agent' and del is null order by id desc ")->many();
    
    foreach($send as &$row){
        $a_name=$db1->sql("select * from sm_main_form_1401 where code='$agent' and del is null ")->one();
        $row['agent_name']=$a_name['name'];
    }
    
    echo json_encode($send);
    
/* Start Request SAVE */

$url="mcpl_agent_zerocollection.php";
$new=fopen("log.txt",'a');
date_default_timezone_set("Asia/Kalkata");
$CURRENTDATE=date("Y-m-d H:i:s");

$write="[".$CURRENTDATE."-".$cid."-".$type."-".$url."-".$led_id;

fwrite($new,$write);
fwrite($new,"\r\n");
fclose($new);

/* End Save Request */
    
}



?>