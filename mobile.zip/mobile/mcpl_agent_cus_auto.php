<?php
// LOG..

ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1=new Dbclass($cid);

$type=$_POST['type'];

if($type==11){
    
      $agent=$_POST['led_id'];
    $name=$_POST['name'];
    
      $ds=$db1->sql("select * from sm_main_form_1401 where del is null and id='$agent' ")->one();
    $agent1=$ds['code'];
    
  
    
    $send1=$db1->sql("select sub_name as name,id as chit_id,chit_sno as label,chit_no as cl_no from sm_main_form_1417 where del is null and agent= $agent1 and  (chit_no LIKE '%".$name."%' or `sub_name` LIKE '%".$name."%' ) and del is null ")->many();
    foreach($send1 as &$row){
        $row['label']=$row['cl_no']."-".$row['name'];
    }
    
    echo json_encode($send1);
    
  extract($_POST);         
            /*Start Request SAVE */
             $url="mcpl_agent_cus_auto.php";
             $new=fopen("log.txt",'a');
             date_default_timezone_set("Asia/Kalkata");
             $CURRENTDATE=date("Y-m-d H:i:s");

             $write=$CURRENTDATE."-".$cid."-".$type."-".$url."-".$agent1;

             fwrite($new,$write);
             fwrite($new,"\r\n");
             fclose($new);
            
            /* End Request SAVE */    
    
}



?>