<?php 
ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);

$type = $_POST['type'];


if($type==4){ 
    
    $t_no = $_POST['t_no'];
    
     /*start request save*/ 
     
     $url="autocomplete.php";
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." CID  : " . $_POST['cid'] ." TYPE : " . $_POST['type']."  T_NO : " . $t_no." URL  : ".$url ." ] " ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
  
   $res = $db1->sql("select t_no as label,t_no,gname,name as led_id,sub_name,address,mobile,id as chit_id from sm_main_form_1417 where del is null and cid=$cid and  (t_no like '%".$t_no."%') ")
    ->many();
        
    foreach($res as &$d)
{
    $d['label'] = $d['label']."-".$d['sub_name']." - ".$d['gname']." - ".$d['chit_id'];
}
echo json_encode($res);

}

if($type==5){ 
    
    
    $gname = $_POST['gname'];
    
   /*start request save*/ 
     
     $url="autocomplete.php";
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." CID  : " . $_POST['cid'] ." TYPE : " . $_POST['type']."  GNAME : " . $gname."  URL  :".$url ." ] " ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
  
   $res = $db1->sql("select id,name as gname from sm_main_form_1416 where del is null and cid=$cid and  (name like '%".$gname."%') ")
    ->many();
        

echo json_encode($res);

}

if($type==6){ 
    
    
    
    $name = $_POST['name'];
    $gname = $_POST['gname'];
    
    
    
    /*start request save*/ 
     
     $url="autocomplete.php";
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." CID : " . $_POST['cid'] ." TYPE : " . $_POST['type']." GNAME  : " . $gname."  NAME  : ".$name."  URL  : ".$url." ] "  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
    
    
    if(!empty($gname)){
         $res = $db1->sql("SELECT id as chitid,id,sub_name as name,name as led_id,ch_type_id,ch_type,grp,gname,grp_no,t_no,temp_id,address,mobile,route FROM sm_main_form_1417 WHERE del IS NULL AND gname ='".$gname."' AND (id LIKE "."'%".$name."%' or sub_name LIKE "."'%".$name."%') ")->many();
foreach($res as &$d)
{
    $d['label'] = $d['name']."-".$d['code'];
}
    } else{
       
        $res = $db1->sql("SELECT id as chitid,id,sub_name as name,name as led_id,ch_type_id,ch_type,grp,gname,grp_no,t_no,temp_id,address,mobile,route FROM sm_main_form_1417 WHERE del IS NULL AND  (id LIKE "."'%".$name."%' or sub_name LIKE "."'%".$name."%') ")->many();
foreach($res as &$d)
{
    $d['label'] = $d['name']."-".$d['code'];
}
    }
    
       
echo json_encode($res);

}




if($type==1){
     $name = $_POST['term'];
        $data = $db1->sql("select name as label,name,id,act from sm_main_form_1416 where del is null and cid=$cid  ")->many();

echo json_encode($data);

 /*start request save*/ 
     
     $url="autocomplete.php";
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." CID : " . $_POST['cid'] ." TYPE : " . $_POST['type']." Autosearch  : " . $name."   URL  : ".$url." ] "  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
}
if($type==2){
    
    if($_POST['grp']!=null){
        $grp=$_POST['grp'];
    // print_r($data);  
    $name = $_POST['value'];
    $data = $db1->sql("SELECT name as label,sub_name as name,name as cusid,gname,t_no,act FROM sm_main_form_1417 WHERE del IS NULL AND gname ='".$grp."' AND  (sub_name LIKE "."'%".$name."%') LIMIT 10 ")->many();
foreach($data as &$d)
{
    $d['label'] = $d['name']." - ".$d['gname']."|".$d['t_no'];
    
   
          
}
echo json_encode($data);
    }else{
        
    // print_r($data);  
    $name = $_POST['term'];
        $data = $db1->sql("SELECT id as label,id as cusid, name FROM sm_main_form_1401 WHERE del IS NULL AND (name LIKE "."'%".$name."%') LIMIT 10 ")->many();
foreach($data as &$d)
{
    $d['label'] = $d['name'];
    
   
          
}
echo json_encode($data);
    }
    
  /*start request save*/ 
     
     $url="autocomplete.php";
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." CID : " . $_POST['cid'] ." TYPE : " . $_POST['type']." GNAME  : " . $grp."   Autosearch  : ".$name."   URL  : ".$url." ] "  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/

}

if($type==3){
    
    if($_POST['led_id']!=null){
        $led_id=$_POST['led_id'];
    // print_r($data);  
    $name = $data['term'];
    $data = $db1->sql("SELECT sub_name as label,sub_name as name,name as cusid,gname,t_no,id,temp_id,act  FROM sm_main_form_1417 WHERE del IS NULL AND name ='".$led_id."' AND  (id LIKE "."'%".$name."%') LIMIT 10 ")->many();
foreach($data as &$d)
{
    $d['label'] = $d['id']." - ".$d['gname']."|".$d['t_no'];
    
   
          
}
echo json_encode($data);
    }else{
        
    // print_r($data);  
    $name = $_POST['term'];
        $data = $db1->sql("SELECT id as label,sub_name as name,name as cusid,gname,t_no,id,grp,act  FROM sm_main_form_1417 WHERE del IS NULL  AND  (id LIKE "."'%".$name."%') LIMIT 10 ")->many();
foreach($data as &$d)
{
    $d['label'] = $d['id']." - ".$d['name']."|".$d['gname'];
    
   
          
}
echo json_encode($data);
    }
    
  /*start request save*/ 
     
     $url="autocomplete.php";
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." CID : " . $_POST['cid'] ." TYPE : " . $_POST['type']." Ledid  : " . $led_id."   Autosearch  : ".$name."   URL  : ".$url." ] "  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/

}


?>