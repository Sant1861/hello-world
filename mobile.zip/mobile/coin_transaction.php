<?
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();

extract($_POST);

if($sub_type=='1'){
    // print_r($_POST);
    if($uid!=''){
    //  $co=$db->sql("select sum(coin) as coin from sm_main_form_20_1 where del is null and user_id='".$uid."' ")->one();
        $coin=$db->sql("select date,coin,pro_id,user_id from sm_main_form_20_1 where del is null and user_id='".$uid."' order by date desc")->many();
         foreach($coin as &$aa){
            $pro=$db1->sql("select * from add_property where del is null and id='".$aa['pro_id']."' ")->one();
            
            $aa['description'] = $pro['product_title'];
            $aa['pro_code'] = $pro['product_code'];

         }
        //  $coin['balance'] = $co['coin'];
// 		 $coin['date']=$aa['da
// 		 $data['description'] = $pro['product_title'];
//          $data['code'] = $pro['product_code'];
         
        //  if($data['code']==NULL){
        //      $data['code']="";
        //  }
         
}
else{
     $data["error"]= TRUE;
		 $data["error_msg"] = "Your User Id Is  missing!";
}
echo json_encode($coin);
}

if($sub_type=='2'){
 
  if($uid!=''){
     $co=$db->sql("select sum(coin) as bal from sm_main_form_20_1 where del is null and user_id='".$uid."' ")->one();
  }
  
  echo json_encode($co);
  
}