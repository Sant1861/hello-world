<?php
ini_set("display_errors",0);
extract($_REQUEST);
// $cid = $_POST['cid'];
require_once("../index.php");
require_once(BASEPATH . 'config/autoloader.php');
require_once(BASEPATH . 'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
// ini_set("display_errors",1);
$db->sql("SET NAMES utf8")->execute();
$db1->sql("SET NAMES utf8")->execute();
if($type==26){
if ($sub_type == 1) {
    // echo"hiiiiiiiiiiii";
//   select a.pro_code,a.video_url,(select img from sm_main_form_1044 as b where b.del is null and a.pro_code=b.pro_code limit 1) as thumb,(select img_og from sm_main_form_1009 as c where c.del is null and a.pro_code=c.pro_id limit 1)as img from sm_main_form_1023 as a where a.del is null and a.video_url !=""; 
    
    $data1=$db1->sql("select a.pro_code,a.video_url,(select img from sm_main_form_1044 as b where b.del is null and a.pro_code=b.pro_code limit 1) as thumb,(select img_og from sm_main_form_1009 as c where c.del is null and a.pro_code=c.pro_id limit 1)as img,(select product_title from add_property as d where d.del is null and a.pro_code=d.id limit 1) as title from sm_main_form_1023 as a where a.del is null and a.video_url !='' ORDER BY a.id desc ")->many();
   
    echo json_encode($data1);
    
}
}





?>