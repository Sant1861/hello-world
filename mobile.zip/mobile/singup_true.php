<?


/*SAVE QUERY*/
// ini_set("display_errors",1);
$cid=$_POST['cid'];

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
$response = array();
// $type = $_POST['type'];
// $data=$_POST;
extract($_POST);
 $date=date('Y-m-d');
$db1->sql("SET NAMES utf8")->execute();
$db->sql("SET NAMES utf8")->execute();
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Login Register~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if($sub_type==1){
  
    if($mobile!='' && $email!='' && $password!=''){
        $check=$db->sql("select count(mobile)as ccount from sm_main_form_20 WHERE del is null and mobile=$mobile")->one();
       $count1=$check['ccount'];
        // echo $count.'prem';
        if($count1==0){
            
    
      
  $ldata=array('cid'=>$cid,'date'=>$date,'f_name'=>$f_name,'address'=>$address,'role_id'=>1,'mobile'=>$mobile,'email'=>$email,'state'=>$state,'city'=>$city,'dist'=>$dist,'password'=>$password,'dev_id'=>$device_id,'dev_loc'=>$dev_loc,'lati'=>$lt,'longt'=>$ln);
       $ledinsert=$db1->from('sm_main_form_104')->insert($ldata)->execute();
     $last_id=$db1->insert_id;
     
     
     
      $ldata1=array('cid'=>$cid,'date'=>$date,'f_name'=>$f_name,'address'=>$address,'role_id'=>1,'mobile'=>$mobile,'email'=>$email,'state'=>$state,'city'=>$city,'dist'=>$dist,'register_status'=>'mobile','password'=>$password,'led_id'=>$last_id,'dev_id'=>$device_id,'dev_loc'=>$dev_loc,'lati'=>$lt,'longt'=>$ln);
  $ledinsert1=$db->from('sm_main_form_20')->insert($ldata1)->execute();
 $last_id1=$db->insert_id;
      
      
      
      
      
      
       $check1=$db->sql("select * from sm_main_form_20 where del is null and mobile=$mobile and id=$last_id1")->one();
       $coins=$db1->sql("select * from sm_main_form_1012 where del is null and reward_type=1")->one();
       
      $ldata2=array('cid'=>$check1["cid"],'date'=>$date,'f_name'=>$check1["f_name"],'mobile'=>$check1['mobile'],'address'=>$check1["address"],'email'=>$check1["email"],'state'=>$check1["state"],'city'=>$check1["city"],'dist'=>$check1['dist'],'coin'=>$coins['coins'],'description'=>"Welcome Bonus",'user_id'=>$last_id1,'date'=>date("Y-m-d"));
    $ledinsert1=$db->from('sm_main_form_20_1')->insert($ldata2)->execute();
      
      
      
      $sms = "அன்புள்ள $f_name,
பதிவு செய்ததற்கு நன்றி. TrueBroker குடும்பத்திற்கு வரவேற்கிறோம்! உங்கள் ப்ராடக்ட்  அல்லது ப்ரொபேர்ட்டி-யை  விளம்பரப்படுத்த உங்களுக்கு உதவ நாங்கள்  இருக்கிறோம். தயவுசெய்து தொடர்பில் இருங்கள்.URL:https://truebroker.in/ Youtube:https://www.youtube.com/channel/UCAHB84nlT-1D_mmbEMpWAqw Instagram:https://www.instagram.com/truebroker_india/ Facebook:https://www.facebook.com/profile.php?id=100088318544015";
	$wsms = array('cid' => $cid, 'mobile' => $mobile, 'message' => $sms);
	$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();
	
	$scall=$db1->sql("select * from sm_main_form_1024 where del is null")->many();

	foreach ($scall as $call) {

// 		$numw = $call['w_num'];


		$sms1 = "Dear Team One New Person Login On Trubroker App Name=$f_name,Mobile=$mobile Kindly Follow Him.,";

		$wsms = array('cid' => $cid, 'mobile' => $call['mobile'], 'message' => $sms1);
		$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();
	}

	
    
    $response["error"] = false;
    // $response['role_id']=$data['role_id'];
     $response['f_name']=$f_name;
      $response['email']=$email;
      $response['coin']=$ldata2['coin'];
      $response['uid']=$check1['id'];
  $response["error_msg"] = " Register successfully";
  
        }
       
        
        else{
            
            
             $check=$db->sql("select * from sm_main_form_20 WHERE del is null and mobile=$mobile ")->one();
            
            
            
            $response['f_name']=$check['f_name'];
            $response['uid']=$check['id'];
            $response["error"] = true;
             $response["error_msg"] = "Already User";
  
        }
        
        echo json_encode($response);
    }
    
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ email login ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

if($sub_type==2){
    // echo "hiiiiiiiii";
    
    if($email!='' && $password!=''){
        // echo "hiiiiiiiii";
        
     $check=$db->sql("select * from sm_main_form_20 WHERE del is null and email='".$email."' and password='".$password."'")->one();
    $countt=count($check);
        if($countt!=0){
            
      
         $response['f_name']=$check['f_name'];
            $response['uid']=$check['id'];
            $response["error"] = false;
             $response["error_msg"] = "Allow To Next Page";
    }
    else{
        
            $response["error"] = true;
             $response["error_msg"] = "Email and password didn't match";
    }
    echo json_encode($response);
}
    
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Forget password~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if($sub_type==3){
    // echo "hiiiiiiiii";
    
    if($mobile='' &&  $email!='' && $password!=''){
        // echo "hiiiiiiiii";
        
     $check=$db->sql("select * from sm_main_form_20 WHERE del is null and email='".$email."' and mobile='".$mobile."'")->one();
    $countt=count($check);
        if($countt!=0){
             $data1 = array('password'=>$password);
  $result=$db->from('sm_main_form_20')->where('id',$check['id'])->update($data1) ->execute();
  $result1=$db1->from('sm_main_form_104')->where('mobile',$mobile)->where('email',$email)->update($data1) ->execute();
      
         $response['f_name']=$check['f_name'];
            $response['uid']=$check['id'];
            $response["error"] = false;
             $response["error_msg"] = "Allow To Next Page";
    }
    else{
        
            $response["error"] = true;
             $response["error_msg"] = "Email and password didn't match";
    }
    echo json_encode($response);
}
    
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ email valiadation ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

if($sub_type==4){
   
    
    if($email!=''){
        
        
     $check=$db->sql("select * from sm_main_form_20 WHERE del is null and email='".$email."'")->one();
    $countt=count($check);
        if($countt!=0){
             
      
      
            $response["error"] = true;
             $response["error_msg"] = "Already Exist";
    }
    else{
        
            $response["error"] = false;
             $response["error_msg"] = "ok";
    }
    echo json_encode($response);
}
    
}


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


$data=$_POST;

if($data['sub_type']==5){
//   ini_set("display_errors",1);
// print_r($data);

    /* Role id check */
    if($data['role_id'] != '' && $data['role_id'] !='0' && $data['mobile'] ){
        
        $check=$db->sql("SELECT count(id)as cc FROM `sm_main_form_20` where mobile=".$data['mobile']."  ")->one();
         $cc=$check['cc'];
        
        
        if($cc==0){
            $ldata=array('cid'=>$data["cid"],'f_name'=>$data["f_name"],'email'=>$data["email"],'mobile'=>$data['mobile'],'role_id'=>1,'token_email'=>$data['token'],'date'=>date("Y-m-d"));
        $ledinsert=$db1->from('sm_main_form_104')->insert($ldata)->execute();
         $last_id=$db1->insert_id;
     
      $ldata1=array('cid'=>$data["cid"],'f_name'=>$data["f_name"],'email'=>$data["email"],'mobile'=>$data['mobile'],'role_id'=>1,'led_id'=>$last_id,'token_email'=>$data['token'],'date'=>date("Y-m-d"));
     $ledinsert1=$db->from('sm_main_form_20')->insert($ldata1)->execute();
           $last_id1=$db->insert_id;  
      
        
   $check1=$db->sql("select * from sm_main_form_20 where del is null and mobile=$mobile and id=$last_id1")->one();
       $coins=$db1->sql("select * from sm_main_form_1012 where del is null and reward_type=1")->one();
       
      $ldata2=array('cid'=>$check1["cid"],'mobile'=>$check1['mobile'],'email'=>$data["email"],'coin'=>$coins['coins'],'description'=>"Welcome Bonus",'user_id'=>$last_id1,'date'=>date("Y-m-d"));
    $ledinsert1=$db->from('sm_main_form_20_1')->insert($ldata2)->execute();
      
      $fname=$data['f_name'];
      $email=$data['email'];
      $mobile=$data['mobile'];
      
      $sms = "அன்புள்ள $f_name,
பதிவு செய்ததற்கு நன்றி. TrueBroker குடும்பத்திற்கு வரவேற்கிறோம்! உங்கள் ப்ராடக்ட்  அல்லது ப்ரொபேர்ட்டி-யை  விளம்பரப்படுத்த உங்களுக்கு உதவ நாங்கள்  இருக்கிறோம். தயவுசெய்து தொடர்பில் இருங்கள்.URL:https://truebroker.in/ Youtube:https://www.youtube.com/channel/UCAHB84nlT-1D_mmbEMpWAqw Instagram:https://www.instagram.com/truebroker_india/ Facebook:https://www.facebook.com/profile.php?id=100088318544015";
	$wsms = array('cid' => $cid, 'mobile' => $mobile, 'message' => $sms);
	$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();
	
	$scall=$db1->sql("select * from sm_main_form_1024 where del is null")->many();

	foreach ($scall as $call) {

// 		$numw = $call['w_num'];


		$sms1 = "Dear Team One New Person Login On Trubroker App Name=$f_name,Mobile=$mobile Kindly Follow Him.,";

		$wsms = array('cid' => $cid, 'mobile' => $call['mobile'], 'message' => $sms1);
		$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();
	}

	
    
    $response["error"] = false;
    // $response['role_id']=$data['role_id'];
     $response['f_name']=$f_name;
      $response['email']=$email;
      $response['coin']=$ldata2['coin'];
      $response['uid']=$check1['id'];
  $response["error_msg"] = " Register successfully";
  
        }
       
        
        else{
            
            
           $check=$db->sql("select * from sm_main_form_20 WHERE del is null and mobile= ".$data['mobile']." ")->one();
            
            
             $ldata1=array('cid'=>$data["cid"],'email'=>$data["email"],'token_email'=>$data['token'],'f_name'=>$data["f_name"]);
       $ledinsert1=$db->from('sm_main_form_20')->where('id',$check['id'])->update($ldata1)->execute();
      
      
            $response['f_name']=$check['f_name'];
            $response['uid']=$check['id'];
            $response["error"] = true;
             $response["error_msg"] = "Already User";
  
        }
        
        echo json_encode($response);
    }
}



?>