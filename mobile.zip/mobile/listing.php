<?php 


// ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$response=array();
// print_r($_POST);
$db1->sql("SET NAMES utf8")->execute();
 extract($_POST);
if($sub_type==1){
    
  
  $sele=$db1->sql("SELECT a.*,b.* FROM `add_property` as a INNER JOIN `sm_main_form_1009` as b ON a.id=b.pro_id where a.del is null and b.del is null and a.uid=$uid and a.type=2")->many();
   
  echo json_encode($sele);
}


if($sub_type==2){
    $data=array();
    $sel=$db1->sql("select * from  add_property where del is null and uid=$uid ")->many();
    
    
    
    
    foreach($sel as $sel1){
      $sel3=$db1->sql("select img_1 from  sm_main_form_1009 where del is null and pro_id='".$sel1['id']."' limit 1")->one();
        // echo $sel4=$db1->sql("select * from  add_property where del is null and type=2 and id='".$sel1['id']."' ")->sql();
        $data['pro']=$sel1;
        $data['img']=$sel3;
         $data1[]=$data;
    }
    
    // $data=array($data);
    echo json_encode($data);
}
if($sub_type==3){
    // ini_set("display_errors",1);
  $ip=$db1->sql("SELECT product_title,seller_name,area,pro_type,city,id,mobile_number,product_code,paid,pro_view,description,(SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and img_1 !='' and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE  del is null  and uid=$uid order by id desc ")->many();  
                            // print_r($ip); ")->many();
    
    // $data=array($data);
     foreach($ip as &$val){
        //   print_r($val);
        //   print_r($val);
    // $pro_for = $db->sql("SELECT name FROM sm_main_form_11 WHERE value=" . $val["mobile_brand"] . " and list_id=224 and del IS NULL")->one();    
              
$sk['price_in_number']=  $val['product_title'];
$sk['listing_for']=$val['seller_name'];
$sk['product_title']=  $val['description'];
$sk['area']=  $val['area'];
$sk['pro_type']=  $val['pro_type'];
$sk['city']=  $val['city'];
$sk['id']=  $val['id'];
$sk['client_mobile']=  $val['mobile_number'];
$sk['img1']=  $val['img1'];
$sk['pro_size']=$val['description'];
// $sk['size_type']=$val['size_type'];
$sk['pro_code']=$val['product_code'];
$sk['paid']=$val['paid'];
$sk['Approved']=$val['pro_view'];
// $sk['pro_code']=$val['product_code'];
$skk[]=$sk;
                        }
        
    

echo json_encode($skk);
}



if($sub_type==4){
    // print_r($_POST);
    // print_r($_FILES);
    if($cname!='' && $cmbl!='' && $message!=''){
            // echo"hh:";
            $msssagepost=$_POST;
            
            $allowTypes = array('pdf', 'doc', 'docx', 'jpg', 'png', 'jpeg');
     	if (!empty($_FILES["resume"]["name"])) {
     	     
     	    $uploadDir1='../../uploads/resume/';
				// File path config 
				$fileName1 = basename($_FILES["resume"]["name"]);
				$t=time();
				$targetFilePath1 = $uploadDir1 .$t.$fileName1;
				$roll=$t.$fileName1;
				$fileType1 = pathinfo($targetFilePath1, PATHINFO_EXTENSION);
			
// echo $fileType1;
				// Allow certain file formats to upload 
				if (in_array($fileType1, $allowTypes)) {
				    // 	echo "hloooooooooooooooo";
					// Upload file to the server 
					if (move_uploaded_file($_FILES["resume"]["tmp_name"], $targetFilePath1)) {
					   // echo "hloooooooooooooooo";
						$uploadedFile1 ="https://truebroker.in/web_new/uploads/resume/".$roll;
					} else {
						$uploadStatus = 0;
						$response['message'] = 'Sorry, there was an error uploading your file.';
					}
				} else {
					$uploadStatus = 0;
					$response['message'] = 'Sorry, only ' . implode('/', $allowTypes) . ' files are allowed to upload.';
				}
			}
            
            
            
            
            
           $mgsinsert=$db1->from('sm_main_form_1020')
                     ->insert(array("uid"=>$uid,"cid"=>$cid,"pro_id"=>$pro_id,"cname"=>"$cname","cmbl"=>"$cmbl","message"=>"$message","customerid"=>$pro_id,'file'=>$uploadedFile1))
                     ->execute();
                    //  $response['error']
                        $response['message']="upload sucess";
                   
            echo json_encode($response);         
        }	
}


if($sub_type==5){
 $message=$db1->sql("select a.*,b.*,a.id as idd from sm_main_form_1020 as a INNER JOIN add_property as b ON a.pro_id=b.id where a.del is null and  a.status is null and b.uid='".$uid."' ")->many();
foreach($message as $msg){
    
    $data['id']=$msg['idd'];
    $data['pro_id']=$msg['pro_id'];
    $data['name']=$msg['c_name'];
    $data['mobile']=$msg['cmbl'];
    $data['msg']=$msg['message'];
    $data['file']=$msg['file'];
    $data1[]=$data;
}
echo json_encode($data1);  
}

// if($sub_type==6){
//     // ini_set("display_errors",1);
//     // $ip=array();
//  $ip=$db1->sql("SELECT product_code,id from add_property where del is null and uid=$uid and pro_view=1")->many();
// print_r($ip) ;              
//                         echo json_encode($ip);  
        
    


// }


?>