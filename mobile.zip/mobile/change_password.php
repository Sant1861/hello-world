<?
/*SAVE QUERY*/
// ini_set("display_errors",1);
$cid=$_POST['cid'];

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
$response = array();

$db->sql("SET NAMES utf8")->execute();
// $type = $_POST['type'];
// $data=$_POST;

 $date=date('Y-m-d');
 
  extract($_POST);

if($type==1){
    

    // echo "hiiiiiiiii";
    // print_r($_POST);
  
    if($cid!='' &&  $cur_pass!='' && $new_pass!=''){
        // echo "hiiiiiiiii";
        
     $check=$db->sql("select * from sm_main_form_20 WHERE del is null and password='".$cur_pass."' and id='".$uid."'")->one();
    $countt=count($check);
        if($countt!=0){
             $data1 = array('password'=>$new_pass);
  $result=$db->from('sm_main_form_20')->where('id',$check['id'])->update($data1) ->execute();
 
      
         
            $response["error"] = false;
            $response["error_msg"] = "Password Change Succesfully";
    }
    else{
        
            $response["error"] = true;
             $response["error_msg"] = "Password Can't Updated";
    }
    echo json_encode($response);
}
    
}
 
 
 
 ?>