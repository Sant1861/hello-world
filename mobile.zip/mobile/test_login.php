<?php 
// print_r($_POST);
// ini_set("display_errors",1);
$cid=13051305;
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// print_r($_POST);
$db = new Dbclass();
$db1 = new Dbclass($cid);
extract($_POST);
// $type = $_POST['type'];
if($type==1){
    $ins=$db1->sql("INSERT INTO `sm_main_form_666`(`user_id`, `password`) VALUES ('$user_id','$password')")->execute();
    
    
    if($ins==true){
         $response["error"]= FALSE;
		 $response["error_msg"] = "Login Created Successfull";
    }
         
    
         echo json_encode($response);
    
}
if($type==2){
    // echo "selva";
    $sk=$db1->sql("select * from sm_main_form_666 where user_id='$user_id' and password ='$password'")->many();
    
   $con=count($sk);
    
    if($con>=1){
    	 $response["error"]= FALSE;
		 $response["error_msg"] = "Login Successfull";
    }else{
         $response["error"]= true;
		 $response["error_msg"] = "User id or Password is Worng";
    }
    
    echo json_encode($response);
}