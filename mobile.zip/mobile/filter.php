<?php 


// ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$response=array();
// print_r($_POST);

 extract($_POST);
if($sub_type==1){
    // print_r($ip);
    // print_r($_POST);
       
     $data1=$_POST;
      $ip = json_decode($data1['data'][0], true);
    //   print_r($ip);
       $cp=  count($ip);
    // echo $cp;
    $ss="";
    for($i=0;$i<$cp;$i++){
        // echo $ip[$i];
       $bbb= explode("-",$ip[$i]);
    //   print_r($bbb);
//       $ins1=array('mid'=>$data1['last_id'],'ans'=>$bbb[1],'ques'=>$bbb[0]);
//   	$d=$db1->from("add_property_1")->insert($ins1)->execute();
$ss.= $bbb[0]." = '" .$bbb[1] . "' and ";
    }
    //   echo $ss;
      
     echo $sel=$db1->sql("select * from add_property where $ss del is null")->sql();
      echo json_encode($sel);
}


if($sub_type==2){
   $sel=$db->sql("select name,value from sm_main_form_11 where list_id=193 and del is null")->many();
      echo json_encode($sel);
}
if($sub_type==3){
   
  
//   $sel=$db->sql("select name,value from sm_main_form_11 where list_id=193 and del is null")->many();
   $teach=$db1->sql("select pincode from sm_main_form_1007 where del is null and (pincode Like '%$name%') group by pincode limit 20")->many();
      echo json_encode($teach);
}

if($sub_type==4){
   
  
//   $sel=$db->sql("select name,value from sm_main_form_11 where list_id=193 and del is null")->many();
  $teach=$db1->sql("select area from sm_main_form_1007 where del is null and (pincode = $pin)  limit 20")->many();
      echo json_encode($teach);
}
if($sub_type==5){
//   print_r($_POST);
  
//   $sel=$db->sql("select name,value from sm_main_form_11 where list_id=193 and del is null")->many();
 $teach=$db1->sql("select city from sm_main_form_1007 where del is null and (pincode = $name) group by city")->many();
      echo json_encode($teach);
}
if($sub_type==6){
   
  
//   $sel=$db->sql("select name,value from sm_main_form_11 where list_id=193 and del is null")->many();
//   $teach=$db1->sql("select city from sm_main_form_1007 where del is null and (pincode = $pin) group by city  limit 20")->many();

$sel=$db1->sql("select coins from sm_main_form_1012 where reward_type=3 and del is null")->one();
      echo json_encode($sel);
}
if($sub_type==7){
   
  print_r($_POST);
// //   $sel=$db->sql("select name,value from sm_main_form_11 where list_id=193 and del is null")->many();
//   $teach=$db1->sql("select city from sm_main_form_1007 where del is null and (pincode = $pin) group by city  limit 20")->many();
//       echo json_encode($teach);
}
if($sub_type==8){
   
  
//   $sel=$db->sql("select name,value from sm_main_form_11 where list_id=193 and del is null")->many();
  $teach=$db1->sql("SELECT *  FROM `sm_main_form_1007` WHERE `area` LIKE '%$name%' and pincode=$pin limit 20")->many();
      echo json_encode($teach);
}

if($sub_type==9){
   
  
//   $sel=$db->sql("select name,value from sm_main_form_11 where list_id=193 and del is null")->many();
  $teach=$db1->sql("SELECT city as id,city  FROM `sm_main_form_1007` WHERE `city` LIKE '%$name%' group by city")->many();
      echo json_encode($teach);
}

if($sub_type==10){
   
  
//   $sel=$db->sql("select name,value from sm_main_form_11 where list_id=193 and del is null")->many();
  $teach=$db1->sql("SELECT  id,area  FROM `sm_main_form_1007` WHERE `area` LIKE '%$name%' group by area")->many();
      echo json_encode($teach);
}
?>