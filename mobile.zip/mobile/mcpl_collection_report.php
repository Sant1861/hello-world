<?
ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);

$type = $_POST['type'];
$data=$_POST;


if($type==16){
     
     
    $edate = date('Y-m-d',strtotime($data['date']));
    $agent=$data['agent'];
    $paytype=$data['p_type'];
    
    
    $cond='';
         
            if(!empty($agent) && $agent !='0'){
                $cond .=" and agent='".$agent."' ";
            }
            if(!empty($paytype) && $paytype !='0'){
                $cond .=" and p_type='".$paytype."' ";
            } 
            if($ndate){
                $cond .=" and date ='".$edate."' ";
            } 
     
     
     
    

/*start request save*/ 
    $url="report_api.php";
    date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[ " . $CURRENTDATE  ." CID : " . $data['cid'] ." TYPE : " . $data['type']." DATE : " . $edate." URL  :  ".$url."  AGENT  : ".$agent ."  PAYMENT TYPE  : ".$paytype . " ]" ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
/* end request save*/

     
    // extract($_POST);
    
    $response = array();
    
    if($paytype==='1'){
         $data6 = array('SNO','GLNO','GLNAME','AMOUNT','REMARK');
    }elseif($paytype==='2'){
         $data6 = array('SNO','GLNO','GLNAME','AMOUNT','CHQ_DATE','REMARK');
    }else{
         $data6 = array('SNO','GLNO','GLNAME','AMOUNT','P_TYPE','CHQ_DATE','REMARK');
    }
    // $data6 = array('SNO','COLLECTION_DATE','RECEIPTS','NAME','GLNO','AMOUNT','PAYMENT_TYPE','CHQ_DATE','REMARK');
   

//  SELECT `id`, `aid`, `uid`, `bid`, `cid`, `ef`, `machine_id`, `date`, `led_id`, `name`, `mobile`, `address`, `grp_no`, `grp_name`, `chit_id`, `balance`, `p_type`, `status`, `other`, `r_type`, `refr`, `remarks`, `chq_date`, `c_date`, `amount`, `pay_acc`, `route`, `agent`, `col_type`, `del`, `is_d`, `act`, `dtime` FROM `sm_main_form_1419` WHERE 1 
     
     
 $active_agent=$db1->sql("SELECT name,amount,id as receiptno,p_type,date,chit_id,refr,remarks,chq_date,agent,route,pay_acc FROM sm_main_form_1419 WHERE  del is null $cond group by date")->many();
    //  echo $active_agent;
    
            $i=1;
               foreach($active_agent as &$sa){
                 $date = date('d-m-Y',strtotime($sa['date']));
                 
                 $gl=$db1->sql("select id,chit_no from sm_main_form_1417 where del is null and id='".$sa['chit_id']."'  ")->one();
                 $sa['chit_id']=$gl['chit_no'];
                 
                 $ptype=$db1->sql("select id,name from sm_main_form_1408 where del is null and id='".$sa['p_type']."'  ")->one();
                 $sa['p_type']=$ptype['name'];
                 
                 if($sa['p_type'] =='2'){
                     $sa['chq_date']=date('d-m-Y',strtotime($sa['chq_date']));
                 }else{
                     $sa['chq_date']='';
                 }
                 
                 if($paytype==='1'){
         $data4[]=array('SNO'=>$i,'GLNO'=>$sa['chit_id'],'GLNAME'=>$sa['name'],'AMOUNT'=>$sa['amount'],'REMARK'=>$sa['refr']);
    }elseif($paytype==='2'){
         $data4[]=array('SNO'=>$i,'GLNO'=>$sa['chit_id'],'GLNAME'=>$sa['name'],'AMOUNT'=>$sa['amount'],'CHQ_DATE'=>$sa['chq_date'],'REMARK'=>$sa['refr']);
    }else{
        $data4[]=array('SNO'=>$i,'GLNO'=>$sa['chit_id'],'GLNAME'=>$sa['name'],'AMOUNT'=>$sa['amount'],'P_TYPE'=>$sa['p_type'],'CHQ_DATE'=>$sa['chq_date'],'REMARK'=>$sa['refr']);
    }
                 
                    
                    $rcount +=$sa['amount'];
                    // $co +=$i;
            $i++;
                    }

      
                 if($paytype==='1'){
        $data4[]=array('SNO'=>'','GLNO'=>'','GLNAME'=>'TOTAL','AMOUNT'=>$rcount,'REMARK'=>'');
    }elseif($paytype==='2'){
         $data4[]=array('SNO'=>'','GLNO'=>'','GLNAME'=>'TOTAL','AMOUNT'=>$rcount,'CHQ_DATE'=>'','REMARK'=>'');
    }else{
        $data4[]=array('SNO'=>'','GLNO'=>'','GLNAME'=>'TOTAL','AMOUNT'=>$rcount,'P_TYPE'=>'','CHQ_DATE'=>'','REMARK'=>'');
    }
    
 
    
    $response['header'] = $data6;
    $response['cont'] = $data4;

  echo json_encode($response);

}