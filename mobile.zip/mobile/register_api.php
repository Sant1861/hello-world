<?php  
/*SAVE QUERY*/
ini_set("display_errors",1);
$cid=21472147;

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
$type = $_POST['type'];
$data=$_POST;

if($type==10){
   
//   print_r($data);

    /* Role id check */
    if($data['role_id'] != '' && $data['role_id'] !='0'  ){
        
        $check=$db->sql("select * from sm_main_form_20 where del is null and mobile='".$data["mobile"]."' ")->one();
        if($check["mobile"] != $data["mobile"]){
            
                    if($data['role_id'] !='3'){
    
    $ldata=array('cid'=>$data["cid"],'cat'=>$data['role_id'],'f_name'=>$data["f_name"],'mobile'=>$data["mobile"]);

$ledinsert=$db1->from('sm_main_form_104')->insert($ldata)->execute();
$lastid = $db1->insert_id;

 $form_id=20; 
$form = "sm_main_form_".$form_id;

$rdata=array('cid'=>$data["cid"],'date'=>date('Y-m-d'),'role_id'=>$data['role_id'],'name'=> $data["f_name"],'mobile'=>$data["mobile"],'email'=>$data["email"],'led_id'=>$lastid,);
	$new1 = $user->NewUser($form);
	$sdata = array_merge($rdata,$new1);
$result =$db->from("sm_main_form_20")
    ->insert($sdata)
    ->execute();
$eresult = $result;
if ($eresult) {
       
              $pin1="";
// $message ="Dear ".$data["name"]." your user name ".$new1["user_id"]." password ".$new1["password"].", thanks from CHITSOFT ".$pin1."";
$message ="Your Mobile app was activated successfully your username ".$new1["user_id"].",password ".$new1["password"]." Thanks from TRUEBROKER.";
$phone=$data["mobile"];
	    $template_id="29"; 
        $user->web_sendsms_api($phone,$message,$cid,$template_id);
// print_r($user);
	   // return true;
	    
	   
        }

    $response["error"] = FALSE;
    $response["error_msg"] = "Register Successfully";
    
}else{
    
    $ldata=array('cid'=>$data["cid"],'cat'=>$data['role_id'],'fname'=>$data["f_name"],'mobile'=>$data["mobile"]);

$ledinsert=$db1->from('sm_main_form_105')->insert($ldata)->execute();
$lastid = $db1->insert_id;

 $form_id=20; 
$form = "sm_main_form_".$form_id;

$rdata=array('cid'=>$data["cid"],'date'=>date('Y-m-d'),'role_id'=>$data['role_id'],'name'=> $data["f_name"],'mobile'=>$data["mobile"],'email'=>$data["email"],'led_id'=>$lastid,);
	$new1 = $user->NewUser($form);
	$sdata = array_merge($rdata,$new1);
$result =$db->from("sm_main_form_20")
    ->insert($sdata)
    ->execute();
$eresult = $result;
if ($eresult) {
       
              $pin1="";
// $message ="Dear ".$data["name"]." your user name ".$new1["user_id"]." password ".$new1["password"].", thanks from CHITSOFT ".$pin1."";
$message ="Your Mobile app was activated successfully your username ".$new1["user_id"].",password ".$new1["password"]." Thanks from TRUEBROKER.";
$phone=$data["mobile"];
	    $template_id="29"; 
        $user->web_sendsms_api($phone,$message,$cid,$template_id);
// print_r($user);
	   // return true;
	    
	   
        }
     $response["error"] = FALSE;
  $response["error_msg"] = "student Register successfully";
    
}
        }else{
            $response["error"] = TRUE;
	
    $response["error_msg"] ="User is Already Register!";
   
        }


// echo json_encode($response);

        }
        
        else {
    // required post params is missing
    $response["error"] = TRUE;
	
    $response["error_msg"] ="Required parameters  missing!";
    
}
    

    echo json_encode($response);


            
             /*start request save*/ 
     
     $url="register_api.php";
     $r_t="Register Page";
      date_default_timezone_set('Asia/Kolkata');
    $new=fopen("successpoint.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." CID : " . $data['cid'] ." TYPE :  " . $data['type']." MENU  :  " . $r_t." ROLEID  :  ".$data['role_id'] ." RESPONSE : ".$response["error_msg"] ." ] " ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
            
}


