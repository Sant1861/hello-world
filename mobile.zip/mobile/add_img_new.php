<?php


// ini_set("display_errors", 1);
$cid = $_POST['cid'];
require_once('../index.php');
require_once(BASEPATH . 'config/autoloader.php');
require_once(BASEPATH . 'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$response = array();
// print_r($_FILES);
// print_r($_POST);
if ($_POST['sub_type'] == 1) {

    extract($_POST);
    $pro_id = $last_id;
    $aid = (rand(10000, 99999));
    $date1 = time();

    $t = time();
    $cc = count($_FILES);
    for ($i = 0; $i < $count; $i++) { //loop to get individual element from the array
        if ($_FILES["imageapi$i"]["size"] > 0) {
            $target_dir = "../../uploads/Pro_img/img_og/";

            $target_file1 = $target_dir . basename($_FILES["imageapi$i"]["name"]);

            $imageFileType1 = strtolower(pathinfo($target_file1, PATHINFO_EXTENSION));

            $mat_pic1 = $lastid1 . 'imageapi' . time() . '' . $i . '.' . $imageFileType1;

            $target_file = $target_dir . $mat_pic1;

            if (move_uploaded_file($_FILES["imageapi$i"]["tmp_name"], $target_file)) {
                //   echo "The file ". htmlspecialchars( basename( $_FILES["imageapi$i"]["name"])). " has been uploaded.";
                //  print_r($_FILES);
                $wmgs1 = "https://truebroker.in/web_new/uploads/Pro_img/img_og/$mat_pic1";
                $data2 = array('cid' => $cid, 'pro_id' => $pid, 'pro_img' => $wmgs1);
                $qury2 = $db1->from('sm_main_form_103')->insert($data2)->execute();
                //   echo "image upload sucessfull";
            } else {
                // echo "Sorry, there was an error uploading your file.";
            }


            $data1 = array('cid' => $cid, 'bid' => $bid, 'uid' => $uid, 'aid' => $aid, 'pro_id' => $pro_id, 'img_ord' => $img_ord, 'img_cap' => $img_cap, 'img_1' => $img_1, 'img_2' => $img_2, 'img_3' => $img_3, 'img_4' => $img_4, 'img_og' => $wmgs1);
            $qury1 = $db1->from('sm_main_form_1009')->insert($data1)->sql();
            // echo $qury1;
            $result1 = $db1->sql($qury1)->execute();

            $last_id11 = $db1->insert_id;

            //  <------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
            $photo_file = $mat_pic1;

            //   size-1 CODE 200*130 img_1
            $img = imagecreatefromjpeg($wmgs1);
            $sourceProperties = getimagesize($wmgs1);
            $sourceImageWidth = $sourceProperties[0];
            $sourceImageHeight = $sourceProperties[1];
            $imageLayer = imagecreatetruecolor(420, 320);
            imagesavealpha($imageLayer, true);
            $trans_colour = imagecolorallocatealpha($imageLayer, 0, 255, 128, 0);
            imagefill($imageLayer, 0, 0, $trans_colour);
            imagecopyresampled($imageLayer, $img, 0, 0, 0, 0, 420, 320, $sourceImageWidth, $sourceImageHeight);
            imagepng($imageLayer, "../../uploads/Pro_img/img_2/$photo_file");
            $watermark_image = imagecreatefrompng("https://truebroker.in/web_new/api/csave/tb_ic400.png");
            $margin_right = 0;
            $margin_bottom = 0;

            $watermark_image_width = imagesx($watermark_image);
            $watermark_image_height = imagesy($watermark_image);
            imagecopy($imageLayer, $watermark_image, imagesx($imageLayer) - 420 - $margin_right, imagesy($imageLayer) - 230 - $margin_bottom, 0, 0, $watermark_image_width, $watermark_image_height);
            //  imagecopy($imageLayer, $watermark_image, imagesx($imageLayer) - $watermark_image_width - $margin_right, imagesy($imageLayer) - $watermark_image_height - $margin_bottom, 10, 10, $watermark_image_width, $watermark_image_height); 
            imagepng($imageLayer, "../../uploads/Pro_img/img_2/$photo_file");

            $pic2 = "https://truebroker.in/web_new/uploads/Pro_img/img_2/$photo_file";


            // echo "<img src='https://truebroker.in/web_new/$photo_file'>";
            $data2 = array('img_2' => $pic2);
            $result = $db1->from('sm_main_form_1009')->where('id', $last_id11)->update($data2)->execute();

            //  <------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->

            //  size-2 CODE 400*300 img_2 

            $img = imagecreatefromjpeg($wmgs1);
            $sourceProperties = getimagesize($wmgs1);
            $sourceImageWidth = $sourceProperties[0];
            $sourceImageHeight = $sourceProperties[1];
            $imageLayer = imagecreatetruecolor(220, 150);
            imagesavealpha($imageLayer, true);
            $trans_colour = imagecolorallocatealpha($imageLayer, 0, 255, 128, 0);
            imagefill($imageLayer, 0, 0, $trans_colour);
            imagecopyresampled($imageLayer, $img, 0, 0, 0, 0, 220, 150, $sourceImageWidth, $sourceImageHeight);
            imagepng($imageLayer, "../../uploads/Pro_img/img_1/$photo_file");
            $watermark_image = imagecreatefrompng("https://truebroker.in/web_new/api/csave/tb_ic73.png");
            $margin_right = 0;
            $margin_bottom = 0;

            $watermark_image_width = imagesx($watermark_image);
            $watermark_image_height = imagesy($watermark_image);
            //  imagecopy($imageLayer, $watermark_image, imagesx($imageLayer) - 220 - $margin_right, imagesy($imageLayer) - 130 - $margin_bottom, 0, 0, $watermark_image_width, $watermark_image_height); 
            //  imagecopy($imageLayer, $watermark_image, imagesx($imageLayer) - $watermark_image_width - $margin_right, imagesy($imageLayer) - $watermark_image_height - $margin_bottom, 10, 10, $watermark_image_width, $watermark_image_height); 
            imagecopy($imageLayer, $watermark_image, imagesx($imageLayer) - 220 - $margin_right, imagesy($imageLayer) - 120 - $margin_bottom, 0, 0, $watermark_image_width, $watermark_image_height);
            imagepng($imageLayer, "../../uploads/Pro_img/img_1/$photo_file");

            $pic3 = "https://truebroker.in/web_new/uploads/Pro_img/img_1/$photo_file";


            // echo "<img src='https://truebroker.in/web_new/$photo_file'>";
            $data2 = array('img_1' => $pic3);
            $result = $db1->from('sm_main_form_1009')->where('id', $last_id11)->update($data2)->execute();



            //  <------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->


            //  size-3 CODE 810*540 img_3 
            $img = imagecreatefromjpeg($wmgs1);

            $sourceProperties = getimagesize($wmgs1);

            $sourceImageWidth = $sourceProperties[0];
            $sourceImageHeight = $sourceProperties[1];
            $imageLayer = imagecreatetruecolor(830, 560);
            imagesavealpha($imageLayer, true);
            $trans_colour = imagecolorallocatealpha($imageLayer, 0, 255, 128, 0);
            imagefill($imageLayer, 0, 0, $trans_colour);
            imagecopyresampled($imageLayer, $img, 0, 0, 0, 0, 830, 560, $sourceImageWidth, $sourceImageHeight);

            imagepng($imageLayer, "../../uploads/Pro_img/img_3/$photo_file");

            $watermark_image = imagecreatefrompng("https://truebroker.in/web_new/api/csave/tb_ic800.png");
            $margin_right = 0;
            $margin_bottom = 0;
            $watermark_image_width = imagesx($watermark_image);
            $watermark_image_height = imagesy($watermark_image);
            imagecopy($imageLayer, $watermark_image, imagesx($imageLayer) - 820 - $margin_right, imagesy($imageLayer) - 430 - $margin_bottom, 0, 0, $watermark_image_width, $watermark_image_height);
            //  imagecopy($imageLayer, $watermark_image, imagesx($imageLayer) - $watermark_image_width - $margin_right, imagesy($imageLayer) - $watermark_image_height - $margin_bottom, 10, 10, $watermark_image_width, $watermark_image_height); 
            imagepng($imageLayer, "../../uploads/Pro_img/img_3/$photo_file");

            $pic4 = "https://truebroker.in/web_new/uploads/Pro_img/img_3/$photo_file";

            // echo "<img src='https://truebroker.in/web_new/$photo_file'>";
            $data2 = array('img_3' => $pic4);
            $result = $db1->from('sm_main_form_1009')->where('id', $last_id11)->update($data2)->execute();
            //  <------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->

            //  size-4 CODE 1366*911 img_4  
            $img = imagecreatefromjpeg($wmgs1);
            // echo $img."prem";
            $sourceProperties = getimagesize($wmgs1);
            // print_r($sourceProperties);
            // echo "kumar";
            $sourceImageWidth = $sourceProperties[0];
            $sourceImageHeight = $sourceProperties[1];
            $imageLayer = imagecreatetruecolor(1396, 931);
            imagesavealpha($imageLayer, true);
            $trans_colour = imagecolorallocatealpha($imageLayer, 0, 255, 128, 0);
            imagefill($imageLayer, 0, 0, $trans_colour);
            imagecopyresampled($imageLayer, $img, 0, 0, 0, 0, 1396, 931, $sourceImageWidth, $sourceImageHeight);
            // imagecopy($im, $img, 0 , 0, 0, 0, 300, 300); 
            // imagestring($im, 1, 5, 5,  'A Simple Text String', $text_color);
            imagepng($imageLayer, "../../uploads/Pro_img/img_4/$photo_file");
            // imagedestroy($im);

            // echo "<img src='https://truebroker.in/web_new/$photo_file'>";
            // print_r($imageLayer);
            // truebroker/public_html/web_new/api/csave/tb_icon_200_100.png

            $watermark_image = imagecreatefrompng("https://truebroker.in/web_new/api/csave/tb_ic800.png");
            $margin_right = 0;
            $margin_bottom = 0;

            $watermark_image_width = imagesx($watermark_image);
            $watermark_image_height = imagesy($watermark_image);
            imagecopy($imageLayer, $watermark_image, imagesx($imageLayer) - 1100 - $margin_right, imagesy($imageLayer) - 680 - $margin_bottom, 0, 0, $watermark_image_width, $watermark_image_height);
            //  imagecopy($imageLayer, $watermark_image, imagesx($imageLayer) - $watermark_image_width - $margin_right, imagesy($imageLayer) - $watermark_image_height - $margin_bottom, 10, 10, $watermark_image_width, $watermark_image_height); 
            imagepng($imageLayer, "../../uploads/Pro_img/img_4/$photo_file");

            $pic5 = "https://truebroker.in/web_new/uploads/Pro_img/img_4/$photo_file";


            // echo "<img src='https://truebroker.in/web_new/$photo_file'>";
            $data2 = array('img_4' => $pic5);
            $result = $db1->from('sm_main_form_1009')->where('id', $last_id11)->update($data2)->execute();

            $dataw['error'] = FALSE;
            $dataw['error_mgs'] = "allow to next page";
        } else {

            $dataw['error'] = TRUE;
            $dataw['error_mgs'] = "Image size is 0";
            //  echo json_encode($dataz);
        }
    }


    echo json_encode($dataw);
}



if ($_POST['sub_type'] == 2) {
    extract($_POST);
    $sell = $db1->sql("select id as img_id,img_og,bid from sm_main_form_1009 where pro_id=$last_id and del is null")->many();
    foreach ($sell as &$sel) {
        $res = $db1->sql("select product_code from add_property where del is null and id=$last_id")->one();
        $sel['bid'] = $res['product_code'];
    }
    // $dataw['error']=FALSE;
    // $dataw['error_mgs']="allow to next page";

    echo json_encode($sell);
}
if ($_POST['sub_type'] == 3) {
    extract($_POST);
    $data1 =  $_POST;

    //  print_r($_POST);
    //  print_r($_FILES);
    $ip = json_decode($data1['order'][0], true);

    // $ipp=$ip[0];
    //  print_r($ipp);
    $pk = count($ip);
    // echo $pk."prem";

    for ($i = 0; $i < $pk; $i++) {
        // echo $ip[$i]['img_id'].'<br>';

        $data3 = array('pro_id' => $data1['last_id'], 'img_cap' => $ip[$i]['caption'], 'img_ord' => $ip[$i]['order'], 'pro_code' => $pro_code);
        $result = $db1->from('sm_main_form_1009')->where('id', $ip[$i]['img_id'])->update($data3)->execute();
    }

    $dataw['error'] = FALSE;
    $dataw['error_mgs'] = "allow to next page";

    echo json_encode($dataw);
}
