<?php


ini_set('display_errors', 1);


extract($_GET);
extract($_POST);


require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');


$db = new Dbclass();

$db1 = new Dbclass(21472147);


// form table---------->



if($type==13){

// print_r($_POST);


$appointment_type   = $appointId;
$date =  date("Y-m-d",strtotime (  $date ));
$time = $time;
$branch = $branch;
$enq_id = $id;


    $count=$db1->sql("SELECT * FROM sm_main_form_115 where del is null and enq_id=$enq_id")->one();

if(empty($count)){
      $data1 = array('cid' => $cid,
                    'enq_id' => $enq_id,     
                    'date' => $date,
                    'time' => $time,                    
                    'branch' => $branch,
                    'type' => $appointment_type,
                );        

                    $qury12=$db1->from('sm_main_form_115')->insert($data1)->sql();                    
                    $qury1=$db1->sql("UPDATE `sm_main_form_101` SET `status` = '1' WHERE `sm_main_form_101`.`id` = $enq_id")->execute();   
                    $result21=$db1->sql($qury12)->execute();

                    
}else if(!empty($count)){
    
      $data1 = array('cid' => $cid,
                    'enq_id' => $enq_id,     
                    'date' => $date,
                    'time' => $time,                    
                    'branch' => $branch,
                    'type' => $appointment_type,
                );        

                    $qury12=$db1->from('sm_main_form_115')->where('enq_id' , $enq_id)->update($data1)->sql();                    
                    $result21=$db1->sql($qury12)->execute();
                    
                  

}

      if($result21==true){
          $response['error']=false;
          $response['error_msg']="Enquiry Save successfully";
            }
            else {
          $response['error']=true;
          $response['error_msg']="Something Went Wrong pls try again later";
            }
            
            echo json_encode($response);
    
    
}




?>




