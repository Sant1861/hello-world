<?php

// Log..

ini_set("display_errors",1);
$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1=new Dbclass($cid);

$type=$_POST['type'];
extract($_POST);
if($type==6){
    
    
    $ds=$db1->sql("select * from sm_main_form_1401 where del is null and id='$led_id' ")->one();
    $agent=$ds['code'];
   
    // $agent=$led_id;
    
    $send=$db1->sql("select chit_no as gl_no,date as chit,sub_name,mobile,address,cd_date as cd,td_date as td from sm_main_form_1417 where agent=$agent and del is null order by date desc ")->many();
    foreach($send as &$row){
        
        $row['chit']=date('d-m-Y',strtotime($row['chit']));
         $row['cd']=date('d-m-Y',strtotime($row['cd']));
          $row['td']=date('d-m-Y',strtotime($row['td']));
        $a_name=$db1->sql("select * from sm_main_form_1401 where code=$agent and del is null ")->one();
        $row['agent_name']=$a_name['name'];
        
        if($row['mobile']==null){
            $row['mobile']='9080098093';
        }
        
        // $pay_t=$db1->sql("select * from sm_main_form_1408 where id='".$row['p_type']."' and del is null  ")->one();
        // $row['p_type']=$pay_t['name'];
        
        // $lat_date=$db1->sql("select max(date) as date from sm_main_form_140 where chit_id='".$row['gl_no']."'  ")->one();
        // $row['pay_date']=$lat_date['date'];
        
       
    }
    
    echo json_encode($send);
    // print_r($_POST);
    
/* Start Request SAVE */
$url="mcpl_agent_customer.php";
$new=fopen("log.txt",'a');
date_default_timezone_set("Asia/Kalkata");
$CURRENTDATE=date("Y-m-d H:i:s");

$write="[".$CURRENTDATE."-".$cid."-".$type."-".$url."-".$led_id;

fwrite($new,$write);
fwrite($new,"\r\n");
fclose($new);

/*End Request SAVE */

}






?>