<?php
// Log..

ini_set("display_errors",1);
$cid=$_POST['cid'];

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1=new Dbclass($cid);

$cdate=date('Y-m-d');
$type=$_POST['type'];
extract($_POST);

function n_formart($num){
	return number_format(round($num,2),2);
	}
function nn_formart($num){
	return number_format(round($num,3),3);
	}

if($type==5){
    
    $agent=array();
    
    $ds=$db1->sql("select * from sm_main_form_1401 where del is null and id='$led_id' ")->one();
    $aid=$ds['code'];
    
    
    // Zero Collection
    
    // $zero_c=$db1->sql("select * from ");
    $agent1['title']="Zero Collection";
    $agent1['value']='0';
    $agent1= array_push($agent,$agent1);
    $agent1=array();
    
    // Opening 
    
    // $demand=$db1->sql("select * from ");
    $agent1['title']="Opening Current Demand";
    $agent1['value']='0';
    $agent1= array_push($agent,$agent1);
    $agent1=array();
    
    // Target & Business
    
    // $targ=$db1->sql("select * from ");
    $agent1['title']="Target & Business";
    $agent1['value']='0';
    $agent1= array_push($agent,$agent1);
    $agent1=array();
    
    // No.Of Customer
    
    $noc=$db1->sql("select count(id) as cnt from sm_main_form_1417 where agent='".$aid."' and del is null ")->one();
    $agent1['title']="Number Of Customers";
    $agent1['value']=$noc['cnt'];
    $agent1= array_push($agent,$agent1);
    $agent1=array();
    
    // Pipeline
    
    $p_line=$db1->sql("select count(*) as pipeline from sm_main_form_1417 where agent='".$aid."' and del is null")->one();
    $agent1['title']="Pipe Line";
    $agent1['value']=$p_line['pipeline'];
    $agent1= array_push($agent,$agent1);
    $agent1=array();
    
    // Pipeline Value
    
    $p_value=$db1->sql("select sum(amount) as pipeline_val from sm_main_form_1419 where agent='".$aid."' and del is null ")->one();
    $agent1['title']="Pipe Line Value";
    $agent1['value']=n_formart($p_value['pipeline_val']);
    $agent1= array_push($agent,$agent1);
    $agent1=array();
    
    echo json_encode($agent);
    // print_r($_POST);
    
    
    
/* Start Request SAVE */


$url="mcpl_agent_dashboard.php";
date_default_timezone_set("Asia/Kolkata");
$new=fopen("log.txt",'a');
$CURRENTDATE=date("Y-m-d H:i:s");

$write="[".$CURRENTDATE ."-". $cid ."-".$type."-".$url."-".$aid;

fwrite($new,$write);
fwrite($new,"\r\n");
fclose($new);


/* end Request SAVE  */

    
}


?>