<?php

$cid = $_POST['cid'];
require_once("../index.php");
require_once(BASEPATH . 'config/autoloader.php');
require_once(BASEPATH . 'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
ini_set("display_errors",1);
extract($_REQUEST);
// $cid = 13051305;
// extract($_REQUEST);

$db1->sql("SET NAMES utf8")->execute();
$db->sql("SET NAMES utf8")->execute();
// print_r($_POST);
$t=time();
if ($type == 32) {
    
  if($status==1){
     $ins= $db1->sql("SELECT * FROM `sm_main_form_1052_1` WHERE `cat`= 1 and del is null order by id desc")->many();
  } 
  if($status==2){
     $ins= $db1->sql("SELECT * FROM `sm_main_form_1052_1` WHERE `cat` = 2 and del is null order by id desc")->many();
  } 
  if($status==3){
     $ins= $db1->sql("SELECT * FROM `sm_main_form_1052_1` WHERE `cat` = 3 and del is null order by id desc")->many();
  } 
  echo json_encode($ins);
    
}


?>