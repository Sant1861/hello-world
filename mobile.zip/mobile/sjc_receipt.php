<?php
ini_set("display_errors",1);

$cid=$_POST['cid'];
$con2 = mysqli_connect('localhost','softuser','Soft@2021',"s_".$cid); 

$type = $_POST['type'];
$data=$_POST;



if($type==2){
    
     $amt=$data['amount'];
     $chit=$data['chitid'];
     $paytype=$data['pay'];
     $date=$data['date'];
     $uid=$data['uid'];
     $d=date('Y-m-d',strtotime($date));

if($paytype=='Cash'){
    $paytype='C';
}else{
    $paytype='Q';
}

$response=array();
$view_receipt = "select max(receiptno) as rno from transact"; 
$res = mysqli_query($con2,$view_receipt);
$row1 = mysqli_fetch_array($res, MYSQLI_ASSOC);
$rno=$row1['rno']+1;


$receipt_save="INSERT INTO transact (collectdt,collectamt,acno,modepay,actype,receiptno,palmtec_id) VALUES ('$d','$amt','$chit','$paytype','COLL','$rno','$uid')";
//echo $receipt_save;
print_r($data);

if($con2->query($receipt_save) == TRUE){
          $response['error']=false;
          $response['error_msg']="Receipt Saved successfully";
            }
          else {
          $response['error']=true;
          $response['error_msg']="Something went wrong,try again later";
            }
            
            
    echo json_encode($response);
}



elseif($type==4){
    
    $name=$data['name'];
    $a=array();

$nameauto="select name as label,name,accountno as chitid,address1,Phone_no FROM master WHERE name LIKE '%".$name."%' limit 10 ";
// echo $nameauto;
$result = mysqli_query($con2,$nameauto);
while($row1 = mysqli_fetch_array($result, MYSQLI_ASSOC))

  {
      $a[]=$row1;

  }
    echo json_encode($a);
     
}

?>

