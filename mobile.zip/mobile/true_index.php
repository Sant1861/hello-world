
<?php 
// ini_set("display_errors",1);
date_default_timezone_set('Asia/Kolkata');
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/class/user.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);

$user = new USER();
$response = array();
// print_r($_POST);


$url="index.php";
$new=fopen("testmarket.txt",'a');
date_default_timezone_set("Asia/Kolkata");
$CURENTDATE=date("Y-m-d H:i:s");

$write="[".$CURENTDATE."-".$_POST['cid']."-".$_POST['type']." ] ";

fwrite($new,$write);
fwrite($new,"\r\n");
fclose($new);

if(isset($_POST['cid']))
{
$cid = $_POST['cid'];
    //   require_once('../../app/sys/config/dbconfig2.php');
       $db1->sql("SET NAMES utf8")->execute();	
    //   echo "10 prem";
}

if(isset($_POST['type']) && $_POST['type'] !=''){
// 	echo "8 prem";
	$type =$_POST['type'];
	$mo_type = $db->from('sm_main_form_23')->where('type',$type)->where('del #',null)->select('name')->one();
	$type_name =  $mo_type['name'];

    // include_once($type_name.".php");	
  
      $device_id = $_POST['device_id'];
     $strln=strlen($device_id);
      $lt = $_POST['lt'];
      $ln = $_POST['ln'];
      $uid = $_POST['uid'];
	
	  if($type==2 || $type==1 || $type==3){
	   //   echo "7 prem";
           if($strln >'0' && $ln >'0' && $lt >'0'){
            //   echo "6 prem";
           include_once($type_name.".php");	
          }else{
            //   echo "5 prem";
            $response["error"] = TRUE;
            $response["error_msg"] = "Invalid Device Id or lt ln missing";
            echo json_encode($response);
          }
	  }else{
	      
       if($strln >'0' && $ln >'0' && $lt >'0' && $uid>0){
        //   echo "4 prem";
         
       include_once($type_name.".php");	
      }else{
        //   echo "3 prem";
        $response["error"] = TRUE;
        $response["error_msg"] = "Invalid Device Id or lt ln missing ";
        echo json_encode($response);
      }
  
  }
}
else {
    // echo "2 prem";
    //required post params is missing
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters  missing!";
    echo json_encode($response);
}

$typee=$_POST['type'];

$mob_res=array('cid'=>$cid,'date'=>date('Y-m-d'), 'type'=>$typee, 'lt'=>$lt, 'ln'=>$ln, 'post_parameters'=>json_encode($_POST),'response'=>json_encode($response), 'device_id'=>$device_id);
 $in=$db->from('mobile_response')->insert($mob_res)->execute();
// echo "1 prem";
?>



