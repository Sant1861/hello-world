<?php
ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// print_r($_POST);
$db = new Dbclass();
$db1 = new Dbclass($cid);
$type = $_POST['type'];
// print_r($_POST);
$user = new USER();
    extract($_POST);
     $check = $db->from('otp')->where('led_id',$data['id'])->where('status',1)->one();
     //$check['otp']=242347;
     if($otp==$check['otp'])
     {
       
             	$data1["error"]= FALSE;
		 $data1["error_msg"] = "OTP IS CORRECT";
	$us_check = $db->from('sm_main_form_13_1')->where('userid',$id)->where('device_id',$device_id)->update(array('is_verified'=>1))->execute();	 
		 
     }
     else
     {
        $data1["error"] = TRUE;
    $data1["error_msg"] = "Your otp number is wrong"; 
     }
             echo json_encode($data1);
  
  ?>