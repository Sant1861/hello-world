<?php
// Log..

ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1=new Dbclass($cid);

$type=$_POST['type'];


//SELECT `id`, `aid`, `uid`, `bid`, `cid`, `fid`, `ef`, `temp_id`, `grp`, `grp_no`, `gname`, `gp_tno`, `t_no`, `t_qty`, `ttype`, `t_per`, `t_ext`, `name`, `chit_no`, `chit_sno`, `date`, `ch_type_id`, `ch_value`, `ch_type`, `tom`, `lname`, `sub_name`, `mobile`, `address`, `agent`, `agent_name`, `staff`, `staff_name`, `adate`, `cd_date`, `td_date`, `route`, `area`, `col_type`, `col_day`, `col_date`, `col_branch`, `col_amount`, `div_amount`, `grp_scm`, `del`, `is_d`, `act`, `dtime`, `paid`, `pay_type`, `status`, `p_type`, `pay_date` FROM `sm_main_form_1417` WHERE 1

//SELECT `id`, `aid`, `uid`, `bid`, `cid`, `fid`, `cat`, `lead_id`, `code`, `customer_sno`, `name_prefix`, `short_name`, `cus_type`, `name`, `fhname`, `dob`, `gender`, `email`, `address`, `area`, `narea`, `district`, `state`, `pin`, `paddress`, `pdistrict`, `pstate`, `ppin`, `caddress`, `cdistrict`, `cstate`, `cpin`, `refrby_sno`, `refrby_name`, `rating`, `sms_status`, `is_active`, `mobile`, `phone`, `pan`, `gstin`, `route`, `route_code`, `ag_name`, `agent`, `adate`, `aadhar`, `occup`, `ac_no`, `bank`, `branch`, `actype`, `qualification`, `mob_status`, `staff`, `del`, `is_d`, `act`, `dtime` FROM `sm_main_form_1401` WHERE 1


if($type==18){
    
    /* gl type 1 is new customer*/  
                                       /* gl type 2 is old customer*/
 if($_POST['cl_type']==='2'){
    //  print_r($_POST);
     
     $glsave=array('cid'=>$_POST['cid'],'ef'=>'1','cat'=>'1','uid'=>$_POST['uid'],'name'=>$_POST['sub_name'],'mobile'=>$_POST['mobile'],'phone'=>$_POST['phone'],'address'=>$_POST['address'],'agent'=>$_POST['agent'],'pan'=>$_POST['pan'],'aadhar'=>$_POST['aadhar']); 


    $res1 = $db1->from('sm_main_form_1401')
           ->insert($glsave)
           ->execute();
           	$lastid = $db1->insert_id;
           
     $register=array('cid'=>$_POST['cid'],'ef'=>'1','uid'=>$_POST['uid'],'t_qty'=>$_POST['t_qty'],'name'=>$lastid,'chit_no'=>$_POST['chit_no'],'date'=>date('Y-m-d',strtotime($_POST['date'])),'ch_type_id'=>$_POST['ch_type_id'],'ch_value'=>$_POST['ch_value'],'ch_type'=>$_POST['ch_type'],'sub_name'=>$_POST['sub_name'],'mobile'=>$_POST['mobile'],'address'=>$_POST['address'],'agent'=>$_POST['agent'],'agent_name'=>$_POST['agent_name'],'staff'=>$_POST['staff'],'route'=>$_POST['route']); 


     $res = $db1->from('sm_main_form_1417')
           ->insert($register)
           ->execute();
     
     
 }else if($_POST['cl_type']==='1'){
     
    //  print_r($_POST);
     
     $register=array('cid'=>$_POST['cid'],'ef'=>'1','uid'=>$_POST['uid'],'t_qty'=>$_POST['t_qty'],'name'=>$_POST['name'],'chit_no'=>$_POST['chit_no'],'date'=>date('Y-m-d',strtotime($_POST['date'])),'ch_type_id'=>$_POST['ch_type_id'],'ch_value'=>$_POST['ch_value'],'ch_type'=>$_POST['ch_type'],'sub_name'=>$_POST['sub_name'],'mobile'=>$_POST['mobile'],'address'=>$_POST['address'],'agent'=>$_POST['agent'],'agent_name'=>$_POST['agent_name'],'staff'=>$_POST['staff'],'route'=>$_POST['route']); 


     $res = $db1->from('sm_main_form_1417')
           ->insert($register)
           ->execute();
 }
 

             
                if($res==true){
          $response['error']="false";
          $response['error_msg']="Registration Completed successfully";
            }
            else {
          $response['error']="true";
          $response['error_msg']="Something Went Wrong pls try again later";
            }
            
            echo json_encode($response);
            
            
    date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE." CID : " .$_POST['cid']."  TYPE : " .$_POST['type']."  CL TYPE : " .$_POST['cl_type']." RESPONSE  : " .$response['error_msg']." DATA  :  [ uid "  .$_POST['uid']." QTY  : ".$_POST['t_qty']." NAME ID ".$_POST['name']." CL NO  : ".$_POST['chit_no']."DATE  : ".$_POST['date']."CH TYPE ID   : ".$_POST['ch_type_id']."CH VALUE   : ".$_POST['ch_value']."SUB NAME   : ".$_POST['sub_name']."MOBILE  : ".$_POST['mobile']."ADDRESS  : ".$_POST['address']."AGENT  : ".$_POST['agent']."AGENT NAME  : ".$_POST['agent_name']."STAFF  : ".$_POST['staff']."STAFF NAME  : ".$_POST['staff_name']."ROUTE  : ".$_POST['route']." ] ";
    
  
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);  
  
}




?>