<?php

ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1=new Dbclass($cid);

$type=$_POST['type'];

if($type==11){
    
    if($_POST['uid']!='' && $_POST['uid'] !='0'){
        
        
        $app_view=$db1->sql("select id, uid, date, s_id, sname, sur_name,source_enquiry, wcountry1 as country, wcourse1, dtime  from sm_main_form_101 where del is null and uid='".$_POST['uid']."' ")->many();
        // $app_view=$db1->sql("select id, uid, date, s_id, sname, sur_name,source_enquiry, wcountry1 as country, wcourse1, dtime  from sm_main_form_101 where del is null  ")->many();
        // echo json_encode($app_view);
        foreach($app_view as &$rs){
          
if($rs['country'] =='2'){
     $rs['country']="Un";
}else{
    $country=$db1->sql("select *  from sm_main_form_102 where del is null and id='".$rs['country']."' ")->one();
     $rs['country']=$country['name'];
}
  
 
    // $response['sdetails'] = $rs;
// $response['wcountry1']= $country['name'];
        }

		
	
// 	 echo json_encode($app_view);
    
    }else {
        
           $app_view=$db1->sql("select id, uid, date, s_id, sname, sur_name,source_enquiry, wcountry1 as country, wcourse1, dtime  from sm_main_form_101 where del is null  ")->many();
        // echo json_encode($app_view);
        foreach($app_view as &$rs){
          
             if($rs['country'] =='2'){
                  $rs['country']="Un";
             }else{
                  $country=$db1->sql("select *  from sm_main_form_102 where del is null and id='".$rs['country']."' ")->one();
                  $rs['country']=$country['name'];
             }
  
 
    // $response['sdetails'] = $rs;
// $response['wcountry1']= $country['name'];
        }

		
        
    // required post params is missing
    // $response["error"] = TRUE;
	
    // $response["error_msg"] ="Required parameters  missing!";
    
}
echo json_encode($response);
}


?>