<?php 
ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);

$type = $_POST['type'];
$data=$_POST;
//print_r($_POST);


if($type==1){
      
      
     /*start request save*/ 
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
      	$edata = json_encode($data['permissions']);
$data = array('cid'=>$data['cid'],'aid'=>111,'uid'=>$data['uid'],'os'=>$data['os'],'model'=>$data['model'],'manufacturer'=>$data['manufacturer'],'device_name'=>$data['device_name'],'internal_storage'=>$data['internal_storage'],'external_available'=>$data['external_available'],'external_total'=>$data['external_total'],'ram_available'=>$data['ram_available'],'ram_total'=>$data['ram_total'],'permissions'=>$edata,'device_id'=>$data['device_id'],'app_version'=>$data['app_version'],'url'=>$data['url']);


 
       $data1 =  $db->from('device_info')
             ->insert($data)
             ->execute();
             
            // echo $data1;
            if($data1==true){
          $response['error']=false;
          $response['error_msg']="Inserted successfully";
            }
            else {
                 $response['error']=true;
          $response['error_msg']="Data Not Insert";
            }
            echo json_encode($response);
       
}
?>