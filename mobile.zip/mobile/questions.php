<?php 

ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
require_once('form_fields_lw.php');



$db= new Dbclass();

$db1=new Dbclass($cid);

$f_field = new FORM_FIELD();


extract($_REQUEST);


$lwm_sub = $db1->sql("SELECT b.id as id,b.que_name,b.name,b.ans_type,b.values_from FROM sm_main_form_1011_1 a INNER JOIN sm_main_form_1003 b  ON a.que_id = b.id WHERE a.del Is NULL AND b.del Is NULL AND a.cat_id='".$cat_id."' AND b.main=2 AND a.sub_cat_id = '".$sub_cat_id."' AND a.pro_type_id = '$pro_type_id'")->many();


      
        $response = array();
        $data1 = array();
        
foreach($lwm_sub as &$sub){






        
       
          $data1[]= $f_field->fields($cid,$sub['id'],$sub['que_name'],$sub['name'],$sub['ans_type'],$sub['values_from']);   

        

       
 
}

        //  $response['field_type'] = array('1'=>'TextBox','2' => 'Text area','3'=>'Sys Drop down','4'=>'Drop down','5'=>'Auto Complete','6'=>'Image','7'=>'File','8'=>'date','9'=>'Time','10'=>'CheckBox','11'=>'Radio','12'=>'Heading','13'=>'Editor','14'=>'Multi Select');
        // $response['cat_id'] = $cat_id;
        // $response['sub_cat_id'] = $sub_cat_id;
        // $response['pro_type_id'] = $pro_type_id;
       
      $response['data'] = $data1;
     echo json_encode([$response]);   
    

// $lwm_sub = $db1->from('sm_main_form_1011_1')->where('del #',null)->where('cat_id',$cat_id)->where('sub_cat_id',$sub_cat_id)->where('pro_type_id',$pro_type_id)->select('que_id')->many();
//  $qs[] = $db1->from('sm_main_form_1003')->where('id',$sub['que_id'])->select(array('que_name','name','ans_type','values_from'))->one();

?>