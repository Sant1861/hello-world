<?php
// Log..

ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1=new Dbclass($cid);

$type=$_POST['type'];

if($type==3){
    // echo "hi";
    //  'uid'=>, 'bid'=>,'s_id'=>,, 'sign'=>,
    
    
 $q1=$_POST['q1'];
 $q2=$_POST['q2'];
 $q3=$_POST['q3'];
 $q4=$_POST['q5'];
 $q5=$_POST['q5'];
 $q6=$_POST['q6'];
 
 
//     if($q1==='Y1'){
//         $q1="Y";
//     }else if($q1==='N1'){
//       $q1="N";
//     }
    
//     if($q2==='Y2'){
//       $q2="Y";
//     }else if($q2==='N2'){
//       $q2="N";
//     }
    
//     if($q3==='Y3'){
//         $q3="Y";
//     }else if($q3==='N3'){
//         $q3="N";
//     }
    
//     if($q4==='Y4'){
//          $q4="Y";
//     }else if($q4==='N4'){
//       $q4="N";
//     }
    
//     if($q5==='Y5'){
//       $q5="Y";
//     }else if($q5==='N5'){
//         $q5="N";
//     }
    
//   if($q6==='Y6'){
//       $q6="Y";
//     }else if($q6==='N6') {
//       $q6="N";
//     }

//  `country_citizenship`, ``, `gender`, ``, ``, `country`, `state`, `city`, `pincode`, `type_of_exam`, `date_of_exam`, ``, `listening_score`, ``, ``, ``, `hslc_country_of_institution`, ``, `hslc_primary_level_of_language`, `hslc_certificate_number`, `hslc_attended_from`, ``, ``, ``, `hslc_school_address`, `hslc_school_state`, `hslc_school_city`, `hslc_school_postal_code`, `sslc_country_of_institution`, `sslc_name_of_institute`, `sslc_primary_level_of_language`, `sslc_certificate_number`, `sslc_attended_from`, `sslc_attended_to`, `sslc_core_subject_marks`, `sslc_percentage`, `sslc_school_address`, `sslc_school_state`, `sslc_school_city`, `sslc_school_postal_code`, `phd_course_name`, `phd_country_of_institution`, `phd_name_of_institute`, `phd_primary_level_of_language`, `phd_certificate_number`, `phd_attended_from`, `phd_attended_to`, `phd_core_subject_marks`, `phd_percentage`, `phd_institute_address`, `phd_institute_state`, `phd_institute_city`, `phd_institute_postal_code`, `pg_course_name`, `pg_country_of_institution`, ``, `pg_primary_level_of_language`, `pg_certificate_number`, `pg_attended_from`, ``, `pg_core_subject_marks`, ``, `pg_institute_address`, `pg_institute_state`, `pg_institute_city`, `pg_institute_postal_code`, `ug_course_name`, `ug_country_of_institution`, ``, `ug_primary_level_of_language`, `ug_certificate_number`, `ug_attended_from`, ``, `ug_core_subject_marks`, ``, `ug_institute_address`, `ug_institute_state`, `ug_institute_city`, `ug_institute_postal_code`, `dipl_course_name`, `dipl_country_of_institution`, ``, `dipl_primary_level_of_language`, `dipl_certificate_number`, `dipl_attended_from`, ``, ``, ``, `dipl_institute_address`, `dipl_institute_state`, `dipl_institute_city`, `dipl_institute_postal_code`, `sslc_doc`, `hslc_doc`, `dipl_doc`, `ug_doc`, `pg_doc`, `pp_doc`, `pte_doc`, `res_doc`, `lor_doc`, `we_doc`, `pf_doc`, `pbase_doc`, `odoc_doc`, `del`, `is_d`, `act`, `dtime`
 
 
 
    // , , , , ,   'wcountry1'=>$_POST['country1'], 'wcourse1'=>$_POST['course1'], 'wcountry2'=>$_POST['country2'], 'wcourse2'=>$_POST['course2'],

    // 'date'=>date('Y-m-d',strtotime($_POST['date']))
   
    $enquiry=array( 'cid'=>$_POST['cid'],  'first_name'=>$_POST['s_name'], 'last_name'=>$_POST['sur_name'], 'date_of_birth'=>date('Y-m-d',strtotime($_POST['dob'])), 'address'=>$_POST['address'], 'phone'=>$_POST['mobile'], 'email'=>$_POST['email'], 'maritial_status'=>$_POST['status'], 'passport_number'=>$_POST['passport'],'reading_score'=>$_POST['reading'],'writing_score'=>$_POST['writing'],'speaking_score'=>$_POST['speaking'],'overall_score'=>$_POST['overall'],'hslc_core_subject_marks'=>$_POST['eng_mark'],'hslc_percentage'=>$_POST['overall_mark'],'hslc_attended_to'=>date('Y-m-d',strtotime($_POST['c_date'])),'hslc_name_of_institute'=>$_POST['courseid'], 'dipl_core_subject_marks'=>$_POST['d_english_mark'], 'dipl_percentage'=>$_POST['d_overall_mark'], 'dipl_attended_to'=>date('Y-m-d',strtotime($_POST['d_date'])), 'dipl_name_of_institute'=>$_POST['d_course_studied'], 'ug_percentage'=>$_POST['ug_overall_mark'], 'ug_attended_to'=>date('Y-m-d',strtotime($_POST['ug_date'])), 'ug_name_of_institute'=>$_POST['ug_course_studied'], 'pg_percentage'=>$_POST['pg_overall_mark'], 'pg_attended_to'=>date('Y-m-d',strtotime($_POST['pg_date'])), 'pg_name_of_institute'=>$_POST['pg_course_studied'], 'source_enquiry'=>$_POST['source_enquiry'], 'refr'=>$_POST['refr'],'work_exp'=>$_POST['work_exp'], 'ielts'=>$_POST['ielts'], 'qus1'=>$q1, 'qus2'=>$q2, 'qus3'=>$q3, 'qus4'=>$q4, 'qus5'=>$q5, 'qus6'=>$q6);
    
    $res = $db1->from('sm_main_form_111')
           ->insert($enquiry)
           ->execute();
    	$lastid = $db1->insert_id;
    $countrysave=array($_POST['country1'],$_POST['country2']);
    $coursesave=array($_POST['course1'],$_POST['course2']);
    for($i=0;$i<count($countrysave);$i++)
{
    $enq_1=array('applying_country'=>$countrysave[$i],'applying_course'=>$coursesave[$i],'mid'=>$lastid);
     $res1 = $db1->from('sm_main_form_111_1')
           ->insert($enq_1)
           ->execute();
}
      if($res==true){
          $response['error']=false;
          $response['error_msg']="Enquiry Save successfully";
            }
            else {
          $response['error']=true;
          $response['error_msg']="Something Went Wrong pls try again later";
            }
            
            echo json_encode($response);
    
    date_default_timezone_set('Asia/Kolkata');
    $new=fopen("successpoint.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE.", 
    CID : " .$_POST['cid'].", 
    TYPE : " .$_POST['type'].", 
    DATE : " .$_POST['date'].", 
    STUDENT NAME : " .$_POST['s_name'].", 
    SUE NAME : " .$_POST['sur_name'].", 
    DOB : " .$_POST['dob'].", 
    ADDRESS : " .$_POST['address'].", 
    MOBILE : " .$_POST['mobile'].",
    EMAIL : " .$_POST['email'].",
    MARITAL STATUS : " .$_POST['status'].",
    PASSPORT : " .$_POST['passport'].",
    SOURCE : " .$_POST['source_enquiry'].",
    REF : " .$_POST['refr'].",
    12 ENGLISH MARK : " .$_POST['eng_mark'].",
    12 OVERALL MARK : " .$_POST['overall_mark'].",
    12 COURSE COMPLETE DATE : " .$_POST['c_date'].",
    12 COURSE STUDIED : " .$_POST['courseid'].",
    DIPLOMA ENGLISH MARK : " .$_POST['d_english_mark'].",
    DIPLOMA OVERALL MARK : " .$_POST['d_overall_mark'].",
    DIPLOMA COMPLETE DATE : " .$_POST['d_date'].",
    DIPLOMA COURSE STUDIED : " .$_POST['d_course_studied'].",
    UG OVERALL MARK : " .$_POST['ug_overall_mark'].",
    UG DATE : " .$_POST['ug_date'].",
    UG COURSE STUDIED : " .$_POST['ug_course_studied'].",
    PG OVERALL MARK : " .$_POST['pg_overall_mark'].",
    PG DATE : " .$_POST['pg_date'].",
    PG COURSE STUDIED : " .$_POST['pg_course_studied'].",
    WORK EXP : " .$_POST['work_exp'].",
    IELTS : " .$_POST['ielts'].",
    IELTS : " .$_POST['reading'].",
    IELTS : " .$_POST['writing'].",
    IELTS : " .$_POST['speaking'].",
    IELTS : " .$_POST['overall'].",
    COUNTRY1 : " .$_POST['country1'].",
    COURSE1: " .$_POST['course1'].",
    COUNTRY2 : " .$_POST['country2'].",
    COURSE2 : " .$_POST['course2'].",
    QUS1 : " .$q1.",
    QUS2 : " .$q2.",
    QUS3 : " .$q3.",
    QUS4 : " .$q4.",
    QUS5 : " .$q5.",
    QUS6 : " .$q6.",
    RESPONSE : " .$response['error_msg']." ] ";
    
  
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);  
  
    
}




?>