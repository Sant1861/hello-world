<?php
// LOG..

ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1=new Dbclass($cid);

$type=$_POST['type'];

if($type==21){
    
    
     $url="mcpl_scheme_list.php";
    $r_t="Scheme_list";
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." CID :  " . $_POST['cid'] ." TYPE  :  " . $_POST['type']." MENU :  " . $r_t."  URL  :  ".$url . "]" ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
    
 
$data = $db1->sql("SELECT id,ch_value,ch_type,id as label FROM `sm_main_form_1415` WHERE del is null and cid='$cid' ")->many();
foreach($data as &$d)
{
    $d['label'] = $d['ch_value']." - ".$d['ch_type'];
}
echo json_encode($data);
    
}



?>