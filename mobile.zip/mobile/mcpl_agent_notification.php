<?php
// Log..

ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1=new Dbclass($cid);

$type=$_POST['type'];

if($type==15){
    
    //   $ss=$db->sql("select def_acc,led_id,route_id,name from sm_main_form_20 where del is null and id='".$_POST['uid']."' and cid='".$_POST['cid']."' ")->one();
    //   $_POST['pay_acc']=$ss['def_acc'];
    //   $_POST['agent']=$ss['led_id'];
    //   $_POST['route']=$ss['route_id'];
    
$cd=date('Y-m-d');
  $agent=$_POST['led_id'];
    $send=$db1->sql("select count(id) as rec from sm_main_form_1419 where  agent='".$agent."' and date='$cd' and del is null order by id desc  ")->one();
      $send['rec']=$send['rec']+1;
  echo json_encode($send);
}

/*start request save*/ 
     $url="mcpl_agent_notification.php";
     $r_t="Receipt Count";
     date_default_timezone_set('Asia/Kolkata');
     $new=fopen("log.txt",'a');
     $CURRENTDATE=date("Y-m-d H:i:s"); 
     $date=date('Y-m-d',strtotime($date));
     $write=  $CURRENTDATE  ." CID : " . $cid ." type :  " . $type." menu : " . $r_t." Url :  ".$url." Agent :  ".$agent ;
    
    
     fwrite($new,$write);
     fwrite($new,"\r\n");
     fclose($new);
/* end request save*/



?>