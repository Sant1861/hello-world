<?php
/*SAVE QUERY*/
//  ini_set("display_errors",1);
// $cid=21472147;
// echo "ug";
// require_once('../index.php');
// require_once(BASEPATH.'config/autoloader.php');
// require_once(BASEPATH.'config/sysconfig.php');
// // require_once('../../app/sys/config/dbconfig2.php');
// $db = new Dbclass();
// $db1 = new Dbclass($cid);
// $user =new USER();
// $type = $_GET['type'];
// $data=$_GET;
// $data=$_SERVER['REQUEST_METHOD'];
extract($_POST);
$data=$_REQUEST;
// print_r($data);
if($data['type']==1){
  if($data['name']!=""){
       
      $qu['error']=FALSE;
      $qu['error_message'] = "Login Successfully ";
      $qu['name'] = "True Broker Dinesh";
       
  } 
   
  else{
      $qu['error']=TRUE;
      $qu['error_message'] = "Login Failed ";
      $qu['name'] = "True Broker Dinesh";
   
   
  }
  echo json_encode($qu);

}
?>