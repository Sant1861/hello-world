<?
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();

extract($_POST);
// print_r($_POST);

if($type=='16'){
    // print_r($_POST);
    if($uid!=''){
    
        $coin=$db1->sql("select coins,rupees from sm_main_form_1015 where del is null ")->many();
         foreach($coin as &$aa){
            
         }
         
}
else{
     $coin["error"]= TRUE;
	 $coin["error_msg"] = "Your User Id Is  missing!";
}
echo json_encode($coin);
}
?>