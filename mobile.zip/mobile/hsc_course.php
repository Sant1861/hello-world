<?php
// Log..

ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1=new Dbclass($cid);

$type=$_POST['type'];

if($type==9){
    
    $source=$db->sql("select name,value as id from sm_main_form_11 where del is null and list_id='46' order by value asc")->many();
    echo json_encode($source);
}


?>