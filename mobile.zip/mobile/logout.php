<?php
// Log..

ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1=new Dbclass($cid);

$type=$_POST['type'];

if($type==14){
    // $email=$_POST['user'];
    $password=$_POST['password'];
    $r_t=$data['request'];
    
    
    $lt=$_POST['lt'];
    $ln=$_POST['ln'];
    
    
    $c_date=date('Y-m-d');
    $c_time=date('H:i:sa');
    
    $uid=$_POST['uid'];
    $led_id=$_POST['led_id'];
    $led=$db->sql("select led_id,name,aid,uid,bid,user_id,password from sm_main_form_20 where id='".$uid."' and cid='".$cid."' and led_id='".$led_id."' and del is null ")->many();

$name=$led['name'];
$bid=$led['bid'];
$aid=$led['aid'];
$uid1=$led['uid'];
$user_id=$led['user_id'];
$password=$led['password'];

// $location=$_POST['location'];ss
// $lt=$_POST['latitude'];
// $ln=$_POST['longitude'];

$arr=array('bid'=>$bid,'aid'=>$aid,'uid'=>$uid,'cid'=>$_POST['cid'],'status'=>"LogOut",'date'=>$c_date,'time'=>$c_time,'user_name'=>$user_id,'password'=>$password,'led_id'=>$led_id,'name'=>$name,'latitude'=>$lt,'longitude'=>$ln);  

$information=$db1->from('sm_main_form_1464')->insert($arr)->execute();

if($information == true){
    $response['error']="false";
    $response['error_msg']="LogOut Succesfully";
}else{
    $response['error']="true";
    $response['error_msg']="Some thing went to wrong Try Again Latter";
}

    echo json_encode($response);
    
    
    
    $u="logout.php";
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $_POST['cid'] ." - " . $type." - " . $r_t ." - " .$lt." - " .$ln." - " .$uid." - ".$led_id." - ".$response["error_msg"];
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);    
    
    
}





?>