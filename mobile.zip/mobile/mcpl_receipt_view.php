<?php

// Log..

ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1= new Dbclass($cid);

$type=$_POST['type'];

if($type==13){
    $agent=$_POST['led_id'];
    $send=$db1->sql("select name,date,led_id,mobile,address,chit_id,grp_no,grp_name,balance,amount,agent,p_type from sm_main_form_1419 where ef='1' and agent='".$agent."'  and del is null order by id desc  ")->many();
    
    foreach($send as &$row){
        
        $gl=$db1->sql("select * from sm_main_form_1417 where del is null and id='".$row['chit_id']."' ")->one();
         $row['chit_id']=$gl['chit_no'];
         
        $pay_t=$db1->sql("select * from sm_main_form_1408 where id='".$row['p_type']."' and del is null  ")->one();
        $row['p_type']=$pay_t['name'];
        
        $cus_detai=$db1->sql("select name,address,mobile from sm_main_form_1401 where code='".$row['led_id']."' and del is null ")->one();
        // $row['']
        if(empty($row['name'])){
            if($row['name']==null){$row['name']="No Name";}
            $row['name']=$cus_detai['name'];
        }
        if(empty($row['mobile'])){
            if($cus_detai['mobile']==null){$cus_detai['mobile']="No Mobile Number";}
            $row['mobile']=$cus_detai['mobile'];
        }
        if(empty($row['address'])){
            if($cus_detai['address']==null){$cus_detai['address']="No Address";}
            $row['address']=$cus_detai['address'];
            
        }
        
    }
    
    echo json_encode($send);
    
    
/* Start Request SAVE */

$url="mcpl_receipt_view.php";
date_default_timezone_set("Asia/Kolkat");
$new=fopen("log.txt",'a');
$CURRENTDATE=date("Y-m-d H:i:s");

$write="[".$CURRENTDATE ."-". $cid ."-".$type."-".$url."-".$aid;

fwrite($new,$write);
fwrite($new,"\r\n");
fclose($new);


/* end Request SAVE  */
    
}





?>