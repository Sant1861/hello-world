<?php

ini_set("display_errors",1);
$cid=$_POST['cid'];

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1=new Dbclass($cid);

$type=$_POST['type'];
extract($_POST);
$c_date=date('Y-m-d');
if($type==7){
    
    $output=array();
    $agent=$led_id;
    
    // Collection Vs Demand
    
    //  $due_amt = $db1->sql("select due,sum(amount) as due_amt from sm_main_form_1425 where  chit_id='".$qr['id']."'   and date BETWEEN '".$fdate."' and '".$tdate."'  and cid=$cid and del is null")->one();
    $col=$db1->sql("select sum(amount) as cnt from sm_main_form_1419 where agent='$agent' and del is null ")->one();   
    // $char['bar1']=$col['cnt'];
    $char['bar1']='80';
    $char['value1']='1000000';
    $char=array_push($output,$char);
    $char=array();
    
    
    // Bussiness Target
    
    $char['bar2']='75';
    $char['value2']='10000';
    $char=array_push($output,$char);
    $char=array();
    
    
    // Bussiness In this Month
    $bussiness=$db1->sql("select sum(ch_value) as bussiness from sm_main_form_1417 where agent='".$agent."' and cid=$cid and del is null ")->one();
    $char['bar3']='60';
    $char['value3']=$bussiness['bussiness'];
    $char=array_push($output,$char);
    $char=array();
    
    
    // Opening Balance
    
    $O_bal=$db1->sql("select sum(amount) as cnt from sm_main_form_1419 where date<'$c_date' and agent='$agent' and del is null ")->one();
    // $char['bar4']=$O_bal['cnt'];
    $char['bar4']='25';
    $char['value4']='25000';
    $char=array_push($output,$char);
    $char=array();
    
    
    // CRM
    
    $char['bar5']='50';
    $char['value5']='100000';
    $char=array_push($output,$char);
    $char=array();
    
    
    echo json_encode($output);
    // print_r($_POST);
    
    
/* Start Request SAVE */

$url="mcpl_agent_chart.php";
date_default_timezone_set("Asia/Kolkat");
$new=fopen("log.txt",'a');
$CURRENTDATE=date("Y-m-d H:i:s");

$write="[".$CURRENTDATE ."-". $cid ."-".$type."-".$url."-".$aid;

fwrite($new,$write);
fwrite($new,"\r\n");
fclose($new);


/* end Request SAVE  */


}






?>