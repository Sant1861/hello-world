<?php
ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);

$type = $_POST['type'];
$data=$_POST;


/* Admin Balance report */

if($type==1){
    
    extract($_POST);
/*start request save*/ 
     $url="report_api.php";
     $r_t=$data['request'];
     date_default_timezone_set('Asia/Kolkata');
     $new=fopen("log.txt",'a');
     $CURRENTDATE=date("Y-m-d H:i:s"); 
     $date=date('Y-m-d',strtotime($date));
     $write=  $CURRENTDATE  ." - " . $data['cid'] ." type :  " . $data['type']." menu : " . $r_t." Url :  ".$url." Agent :  ".$agent_name." Route :  ".$route_name."  Date :  ".$date. "  paid :  ".$paid_type  ;
    
    
     fwrite($new,$write);
     fwrite($new,"\r\n");
     fclose($new);
/* end request save*/
      
    
    
    $response = array();
    
    $data6 = array('SNO','NAME','GROUPID','CD','TD','DUE','COLL','DIVID','TOTAL','BALANCE','LDR','AGENT','ROUTE','PHONE');

     
if(!empty($agent_name && $agent_name !='0')){
                $cond .=" and agent='".$agent_name."' ";
            }
            if(!empty($route_name && $route_name !='0')){
                $cond .=" and route='".$route_name."' ";
            }
            if($paid_type=="Y"){
                 $cond .=" and td_date >= '".$date."'";
                $cond .= "  AND paid LIKE '$paid_type' AND status IS NULL";
            }
            elseif($paid_type=="N"){
                $cond .=" and td_date >= '".$date."'";
            $cond .= "  AND (paid LIKE '$paid_type' OR paid IS NULL) AND status IS NULL ";
                
            }else { 
                
                $cond .=" and td_date >= '".$date."'";
                $cond .= "  AND status IS NULL";
                
            }
            
            //     $cond='';
            //     $cond .=" and td_date >= '".$ndate."'";
          
            // if(!empty($agent_name)){
            //     $cond .=" and agent='".$agent_name."' ";
            // }
            // if(!empty($route_name)){
            //     $cond .=" and route='".$route_name."' ";
            // }
            // if($paid_type=="Y"){
            //     $cond .= "  AND paid LIKE '$paid_type' AND pay_type NOT IN ('Final','Adjustment','Cancel After Group','Cancel Before Group')";
            // }
            // else if($paid_type=="N"){
            // $cond .= "  AND (paid LIKE '$paid_type' OR paid IS NULL) ";
                
            // }

         
     $tb = $db1->sql("SELECT date,name,agent,CONCAT(gname, ' | ' ,t_no ) as gp_tno,td_date,cd_date,ch_type,ch_value,id,temp_id,route FROM sm_main_form_1417 where cid='$cid' and td_date IS NOT NULL   $cond  ORDER BY ch_type ASC,`grp` ASC")->many();
                //  echo $tb;
                   $i=1;
                   $collection = 0;
                   $dividend1 = 0;
                   $total1 = 0;
                   $balance1 = 0;
                   
                   
                   foreach($tb as &$sa){
                       
                        $sa['date']=date('d-m-Y',strtotime($sa['date']));
                       $agent = $sa['agent'];
                  $agent = $db1->from('sm_main_form_1401')->where('id',$agent)->where('cat',2)->where('del #',null)->one();
                  $name = $db1->from('sm_main_form_1401')->where('id',$sa['name'])->where('del #',null)->one();
                  
 $route = $db1->sql("SELECT name as route FROM `sm_main_form_1410` WHERE id='".$sa['route']."' AND del is null")->one();
    $route= $route['route'];
                  
               $collect = $db1->sql("select sum(amount) as collectamt,MAX(date) AS date from sm_main_form_140 where chit_id='".$sa['id']."' AND chit_id='".$sa['id']."'  and trans_type not in (12,13,14,15,16,17,18,23)  and date <= '".$date."' and cid=$cid and del is null and status IS NULL")->one();
               $div_amt = $db1->sql("select sum(amount) as div_amt from sm_main_form_140 where led_id='".$sa['name']."' AND chit_id='".$sa['id']."' and trans_type = '15'   AND status is null   and date <= '".$date."' and cid=$cid and del is null")->one();
               $due_amt = $db1->sql("select sum(amount) as due_amt from sm_main_form_140 where led_id='".$sa['name']."' AND chit_id='".$sa['id']."' and trans_type = '13'  and date <= '".$date."' and cid=$cid and del is null")->one();
               
               $div_amt = $div_amt['div_amt'];
                $due_amt = $due_amt['due_amt'];
               $col_amount =  $collect['collectamt'];
               
               
                // print_r($arrers);
                //  $dividend = $db1->sql("select sum(amount) as collectamount from sm_main_form_1435 where name_id='".$sa['name']."' AND chit_id='".$sa['id']."' and cid=$cid and del is null")->one();

                  $total = abs($col_amount) + abs($div_amt);
                  $balance = $due_amt - $total;
                  
                     if($balance > 0){
                  $data4[]= array('SNO'=>$i,'NAME'=>$name['name'],'GROUPID'=>$sa['gp_tno'],'CD'=>date('d-m-Y',strtotime($sa['cd_date'])),'TD'=> date('d-m-Y',strtotime($sa['td_date'])),'DUE'=>abs($due_amt),'COLL'=>abs($col_amount),'DIVID'=>abs($div_amt),'TOTAL'=>abs($total),'BALANCE'=>$balance,'LDR'=>date('d-m-Y',strtotime($collect['date'])),'AGENT'=>$agent['name'],'ROUTE'=>$route,'PHONE'=>$name['mobile']." - ".$name['phone']);

                  
                  
                  
                   $collection += abs($collect['collectamt']);
                    $dividend1 += abs($dividend['collectamount']);
                   $total1 += abs($total);
                   $balance1 += abs($balance);
                    $i++;
                   }
                   }
                   $data4[]=array('SNO'=>"",'NAME'=>"",'GROUPID'=>"",'CD'=>"",'TD'=>"",'DUE'=>"",'COLL'=>"",'DIVID'=>"TOTAL",'TOTAL'=>$balance1,'BALANCE'=>"",'LDR'=>"",'AGENT'=>"",'ROUTE'=>"",'PHONE'=>"");
    
    
    $response['header'] = $data6;
    $response['cont'] = $data4;

  echo json_encode($response);

}

/*machine details*/

if($type==2){
    
/*start request save*/ 
     $url="report_api.php";
     $r_t=$data['request'];
     date_default_timezone_set('Asia/Kolkata');
     $new=fopen("log.txt",'a');
     $CURRENTDATE=date("Y-m-d H:i:s"); 
     $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url  ;
    
    
     fwrite($new,$write);
     fwrite($new,"\r\n");
     fclose($new);
/* end request save*/
      
$machine = $db1->from('sm_main_form_1411')->where('del #',NULL)->select(array('mac_id','name','agent','route'))->many();
foreach($machine as &$val){
     
      $agent =  $db1->from('sm_main_form_1401')->where('del #',null)->where('id',$val['agent'])->one();
     $val['agent_name'] = $agent['name'];  
    
     $route =  $db1->from('sm_main_form_1410')->where('del #',null)->where('id',$val['route'])->one();
     $val['route_name'] = $route['name'];
    
    
}
echo json_encode($machine);
    
}

/*group details*/
if($type==3){
    
/*start request save*/ 
     $url="report_api.php";
     $r_t=$data['request'];
     date_default_timezone_set('Asia/Kolkata');
     $new=fopen("log.txt",'a');
     $CURRENTDATE=date("Y-m-d H:i:s"); 
     $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url  ;
    
    
     fwrite($new,$write);
     fwrite($new,"\r\n");
     fclose($new);
/* end request save*/
      
// $grp_details=$db1->from('sm_main_form_1416')->where('cid',$cid)->where('del #',NULL)->select(array('name','ch_type','amount','nos'))->many();
$grp_details=$db1->sql("select name,ch_type,amount,nos from sm_main_form_1416 where del is NULL order by amount DESC ")->many();

echo json_encode($grp_details);
}




/* agent wise report  
       REPORT contain the information about agent collection in particular date wise */
if($type==4){
     
    $sdate = $data['sdate'];
    $edate = date('Y-m-d',strtotime($edate));
    $agent=$data['agent'];

/*start request save*/ 
    $url="report_api.php";
    date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $c_date." - ".$url."-".$agent  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
/* end request save*/

     
    extract($_POST);
    
    $response = array();
    
    $data6 = array('SNO','COLLECTION_DATE','RECEIPTS','AMOUNT');

    $sdate = date('Y-m-d',strtotime($sdate));
    $edate = date('Y-m-d',strtotime($edate));
    $agent=$data['agent'];
     
     /* COUNT(id) ->no of receipts (agent) in particular date  , sum(amount)->agent collection amount in particular date */       
    $active_agent=$db1->sql("SELECT agent,date,COUNT(id) as receipt,sum(amount) as amount FROM sm_main_form_1419 WHERE date BETWEEN '".date('Y-m-d',strtotime($sdate))."' and '".date('Y-m-d',strtotime($edate))."' AND agent=$agent AND del is null group by date")->many();
    //  echo $active_agent;
    
            $i=1;
               foreach($active_agent as &$sa){
                 $date = date('d-m-Y',strtotime($sa['date']));
                 $data4[]=array('SNO'=>$i,'COLLECTION_DATE'=>$date,'RECEIPTS'=>$sa['receipt'],'AMOUNT'=>$sa['amount']);
                    $rcount += $sa['receipt'];
                    $tcount += $sa['amount'];
            $i++;
                    }

    $data4[]=array('SNO'=>"",'COLLECTION_DATE'=>"",'RECEIPTS'=>"",'AMOUNT'=>"",'TOTAL_RECEIPTS'=>$rcount,'TOTAL_AMOUNT'=>$tcount);
 
    
    $response['header'] = $data6;
    $response['cont'] = $data4;

  echo json_encode($response);

}





/* Macine wise report  for Agent
 REPORT contain the information about agent Machine wise collection in particular date wise*/
if($type==5){
     
/*start request save*/
      $url="report_api.php";
      $r_t=$data['request'];
      date_default_timezone_set('Asia/Kolkata');
      $new=fopen("log.txt",'a');
      $CURRENTDATE=date("Y-m-d H:i:s"); 
      $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url  ;
    
    
      fwrite($new,$write);
      fwrite($new,"\r\n");
      fclose($new);
/* end request save*/
      
    extract($_POST);
    
    $response = array();
    
    $data6 = array('SNO','COLLECTION_DATE','NO_OF_MACHINE','AMOUNT');

    // $sdate = date('Y-m-d',strtotime($sdate));
    // $edate = date('Y-m-d',strtotime($edate));
    $cdate=date('Y-m-d');
    $machine=$data['machine_id'];
    // $agent=$data['agent'];
   
    /* COUNT(machine_id) ->no of machine (agent) in particular date  , sum(amount)->agent collection amount in particular date for machine */       
    $active_machine=$db1->sql("SELECT date, machine_id,COUNT(machine_id) as nom,sum(amount) as amt  FROM sm_main_form_1419 WHERE machine_id='$machine'  AND date=$cdate AND r_type = 2 AND del is null group by date")->many();
    //  echo $active_machine;
    
            $i=1;
               foreach($active_machine as &$sa){
                 $date = date('d-m-Y',strtotime($sa['date']));
                 $data4[]=array('SNO'=>$i,'COLLECTION_DATE'=>$date,'NO_OF_MACHINE'=>$sa['nom'],'AMOUNT'=>$sa['amt']);
                    $rcount += $sa['nom'];
                    $tcount += $sa['amt'];
            $i++;
                    }

    $data4[]=array('SNO'=>"",'COLLECTION_DATE'=>"",'NO_OF_MACHINE'=>"",'AMOUNT'=>"",'TOTAL_MACHINES'=>$rcount,'TOTAL_AMOUNT'=>$tcount);
 
    
    $response['header'] = $data6;
    $response['cont'] = $data4;

  echo json_encode($response);

}

/*  statement menu view : member name*/
if($type==6){
    
    
/*start request save*/ 

     $url="report_api.php";
     $r_t=$data['request'];
     date_default_timezone_set('Asia/Kolkata');
     $new=fopen("log.txt",'a');
     $CURRENTDATE=date("Y-m-d H:i:s"); 
     $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url  ;
    
    
     fwrite($new,$write);
     fwrite($new,"\r\n");
     fclose($new);
     
/* end request save*/
      
    $ch_value=$data['amount'];
    $gname=$data['group_name'];
    $memdetials=$db1->sql("select sub_name,mobile,address from sm_main_form_1417 WHERE ch_value=$ch_value and gname='$gname' order by t_no ")->many();
     echo json_encode($memdetials);
}

/*  statement menu view : member details*/
if($type==7){
    // print_r($data);
    
/*start request save*/
     
     $ch_value=$data['amount'];
     $gname=$data['group_name'];
     $sub_name=$data['name'];
    
    
     $url="report_api.php";
     $r_t=$data['request'];
     date_default_timezone_set('Asia/Kolkata');
     $new=fopen("log.txt",'a');
     $CURRENTDATE=date("Y-m-d H:i:s"); 
     $write= $CURRENTDATE." - " .$data['cid']." - " .$data['type']." - " .$r_t." - ".$url." - ".$ch_value." - " .$gname." - " .$sub_name ;
    
    
     fwrite($new,$write);
     fwrite($new,"\r\n");
     fclose($new);
     
/* end request save*/
    
    
    
   $member_view=$db1->sql("select t_no,sub_name,a.mobile as mobile,ch_value,col_amount,div_amount,paid,pay_type,b.name as agent, date_format(cd_date, '%d-%m-%Y') as cd_date,date_format(td_date, '%d-%m-%Y') as td_date ,c.name as route
 from sm_main_form_1417 as a
 inner join sm_main_form_1401 as b on a.agent = b.id 
 inner join sm_main_form_1410 as c on c.id = a.route 
where a.del is null and grp > 0 and cat =2 and  gname='$gname' and ch_value='$ch_value' and sub_name='$sub_name' order by grp,t_no")->one();
// echo $member_view;
 echo json_encode($member_view);
}



/* ledger_view_report */
if($type==8){
    
      $led_id=$data['led_id'];
   $chit_id=$data['chitid'];
   $date=$data['date'];
    
/*start request save*/  
     $url="report_api.php";
     $r_t="memberdetails report";
     date_default_timezone_set('Asia/Kolkata');
     $new=fopen("log.txt",'a');
     $CURRENTDATE=date("Y-m-d H:i:s"); 
     $write= $CURRENTDATE." - " .$data['cid']." - " .$data['type']." - " .$r_t." - ".$url." - ".$led_id." - ".$date." - ".$chit_id;
    
    
     fwrite($new,$write);
     fwrite($new,"\r\n");
     fclose($new);
/* end request save*/
    
   extract($_POST);
    
    $response = array();
    
    $data6 = array('SNO','DATE','RECEIPT_NO','MODE','AMOUNT','TOTAL');

   
 
     
        
          $chit = $db1->sql("select cd_date,td_date,sub_name,temp_id,grp_no,gname from sm_main_form_1417 where del is null and id='".$chit_id."' ")->one();
        //   $data1[]=
            
        
        $qry = $db1->sql("SELECT date_format(date, '%d-%m-%Y') as date,amount,trans_no,trans_type,trans_name FROM sm_main_form_140  WHERE trans_type not in (12,13,14,15,16,17,18,23) and  del IS NULL and  chit_id='".$chit_id."' and date <='".date('Y-m-d',strtotime($date))."'  order by date,id")->many();
        // print_r($qry);
    
            $i=1;
               foreach($qry as &$qr){
                
                     $amt=abs($qr['amount']);
                       $tot +=$amt;
                       
                         
                       
                $data4[]= array('SNO'=>"$i",'DATE'=>$qr['date'],'RECEIPT_NO'=>$qr['trans_no'],'MODE'=>$qr['trans_name'],'AMOUNT'=>"$amt",'TOTAL'=>"$tot");
                       
                       if($qr['status'] ==='3'){
                          $qr['amount']="0"; 
                          $tamt +=$qr['amount'];
                          }else{
                              $tamt +=$qr['amount'];
                          }
            $i++;
                    }

       $data4[]= array('SNO'=>"",'DATE'=>"",'RECEIPT_NO'=>"",'MODE'=>"TOTAL",'AMOUNT'=>abs($tamt),'TOTAL'=>"");
 

    $response['header'] = $data6;
    $response['cont'] = $data4;
   
    
echo json_encode(array_merge($chit,$response));
//   echo json_encode($response);
}




/* ledger_Extract_report */
if($type==9){
    
     $chit_id=$data['chit_id'];
    $date=$data['date'];
    $lid=$data['ledId'];
    
    // print_r($data);
    
/*start request save*/  
     $url="report_api.php";
     $r_t=$data['request'];
     date_default_timezone_set('Asia/Kolkata');
     $new=fopen("log.txt",'a');
     $CURRENTDATE=date("Y-m-d H:i:s"); 
     $write= $CURRENTDATE." - " .$data['cid']." - " .$data['type']." - " .$r_t." - ".$url." - ".$chit_id." - ".$lid;
    
    
     fwrite($new,$write);
     fwrite($new,"\r\n");
     fclose($new);
/* end request save*/

     extract($_POST);
    
    $response = array();
    
    $data6 = array('SNO','DATE','DUE_AMOUNT','COLLECTION','DIVIDENT','TOTAL','NET_TOTAL');


   

        $select = $db1->sql("select b.id as led_id,b.name as name,a.temp_id,CONCAT(a.id,'|' ,a.temp_id)  as chit_id ,CONCAT(a.gname, '|',a.t_no ) as group_id,a.agent as agent,b.address as address,b.mobile as mobile,b.phone as phone,a.cd_date as cd_date,a.td_date as td_date from sm_main_form_1417 AS a INNER JOIN  sm_main_form_1401 AS b ON a.name=b.id where a.del is null and a.cid=$cid and a.id='$chit_id'" )->one();
                    // print_r($select);
                    // echo $select;
                    
                    $agent = $db1->sql("select name as agentname from sm_main_form_1401 where id='".$select['agent']."' and cid=$cid and del is null")->one();
    
     $f_date = $db1->sql("select max(v_date) as f_date from sm_main_form_1444 where chit_id='".$chit_id."' and cid=$cid and del is null ")->one();
    
  $p = $db1->sql("select date as paid_date,p_type as type,sum(amount) as paid_amt from sm_main_form_1420 where chit_id='".$chit_id."' and led_id='".$select['led_id']."' and del is null")->one();
   
  $pay_type = $db1->sql("select name as pay_type from sm_main_form_1408 where  id='".$p['type']."' and del is null")->one();
   
  $running = $db1->sql("select sum(amount) as running_bal from sm_main_form_140 where  chit_id='".$chit_id."' and trans_type not in (12,14,16,17,18)  and date <= '".date('Y-m-d',strtotime($date)) ."' and  del is null and status is null ")->one();
            
        
        
        
        $qry = $db1->sql("select amount,date,led_id,chit_id from sm_main_form_140 where  chit_id='".$chit_id."' and trans_type='13' and  date<='".date('Y-m-d',strtotime($date))."'  and cid=$cid and del is null")->many();
        // print_r($qry);
    // echo $qry;
    
             $i=1;
                $dividend=0;
                $due=0;
                $tot=0;
                $tota=0;
                $netot=0;
                $balanceamt=0;
                
                    $st_date = $db1->sql("select min(date) as sn_date,max(date) as ldr_date from sm_main_form_140 where chit_id='".$chit_id."' and trans_type not in (12,13,14,15,16,17,18,23) and del is null and status IS NULL")->one();
                    
                    
       $s_date = date('Y-m-d',strtotime($st_date['sn_date']));                
       $last_month_col=0;
        $last_month_div=0; 
        
               foreach($qry as &$qr){
                   
                   
       $col = $db1->sql("select sum(amount) as ctotal  from sm_main_form_140 where chit_id='$chit_id' and trans_type not in (12,13,14,15,16,17,18,23) and date <= '".$qr['date']."' and del is null and status IS NULL")->one();
       
       $div = $db1->sql("select sum(amount) as div_amount from sm_main_form_140  where chit_id='".$chit_id."' and trans_type='15' and date <= '".$qr['date']."' and status IS NULL and del is null")->one();
       
       
   
       $t_col = $col['ctotal'] - $last_month_col;
       $last_month_col = $col['ctotal'];
  
       $t_div = $div['div_amount'] - $last_month_div;
       $last_month_div = $div['div_amount'] ;
  
       $total = $t_col + $t_div;
       $ntotal += $total;
       $dtotal +=$qr['amount'];
    // $netot = $netot+$total;
       $balance = $qr['amount']-$total;
       $nbalance = $dtotal+$ntotal;
       
                    //   $ntotal += $qr['total'];
                       
$data4[]  = array('SNO'=>"$i",'DATE'=>date('d-m-Y',strtotime($qr['date'])),'DUE_AMOUNT'=>$qr['amount'],'COLLECTION'=>abs($t_col),'DIVIDENT'=>abs($t_div),'TOTAL'=>abs($total),'NET_TOTAL'=>abs($ntotal));
                          
                        $due +=$qr['amount'];
                     $tot +=$t_col;
                    $dividend +=$t_div;
                    $tota +=$total;
                 
                    $balanceamt+=$balance;
                    
                 
                    $s_date  =   date('Y-m-d',strtotime($qr['date'] . ' +1 days')); 
                  
                     $ss_date = $qr['date'];
            $i++;
                    }
                      if(strtotime($ss_date) < strtotime($st_date['ldr_date']) ) {
                        $ldr_date = $st_date['ldr_date'];
                        
                        $qr['date'] =  $ldr_date;
                        $qr['amount'] = 0;
                        //  echo   $last_month_col."-".$last_month_div."-".$qr['date']."-".$s_date."<br>";
                         
                         
  $col = $db1->sql("select sum(amount) as ctotal  from sm_main_form_140 where chit_id='$chit_id' and trans_type not in (12,13,14,15,16,17,18,23) and date <= '".date('Y-m-d',strtotime($date))."' and del is null and status IS NULL")->one();
     $div = $db1->sql("select sum(amount) as div_amount from sm_main_form_140  where chit_id='".$chit_id."' and trans_type='15' and date <= '".date('Y-m-d',strtotime($date))."' and status IS NULL and del is null")->one();
            
            
              $t_col = $col['ctotal'] - $last_month_col;
  //$last_month_col = $col['ctotal'];
  
  $t_div = $div['div_amount'] - $last_month_div;
 $last_month_div = $div['div_amount'];
  
    $total = $t_col + $t_div;
    $ntotal += $total;
    $dtotal +=$qr['amount'];
    // $netot = $netot+$total;
    $balance = $qr['amount']-$total;
      $nbalance = $dtotal+$ntotal;
       
      $data4[]  = array('SNO'=>"$i",'DATE'=>date('d-m-Y',strtotime($qr['date'])),'DUE_AMOUNT'=>$qr['amount'],'COLLECTION'=>abs($t_col),'DIVIDENT'=>abs($t_div),'TOTAL'=>abs($total),'NET_TOTAL'=>abs($ntotal));
       
                    $due +=$qr['amount'];
                    $tot +=$t_col;
                    $dividend +=$t_div;
                    $tota +=$total;
                    // $nettot = $netot+$total;
                    $balanceamt+=$balance;
                    
                        
                    }
       $data4[] = array('SNO'=>"",'DATE'=>"",'DUE_AMOUNT'=>abs($due),'COLLECTION'=>abs($tot),'DIVIDENT'=>abs($dividend),'TOTAL'=>abs($tota),'NET_TOTAL'=>"");
 
 
 if(!empty($st_date['ldr_date']) &&  $st_date['ldr_date'] !='') {  $ld=date('d-m-Y',strtotime($st_date['ldr_date']));  }
 if(!empty($f_date['f_date']) &&  $f_date['f_date'] !='') {   $fd= date('d-m-Y',strtotime($f_date['f_date'])); }
 
    $data4[]=array('SNO'=>"LDR",'DATE'=>"$ld",'DUE_AMOUNT'=>"PASSBOOK_VERIFY",'COLLECTION'=>"$fd",'DIVIDENT'=>"",'TOTAL'=>"",'NET_TOTAL'=>"");


    $response['header'] = $data6;
    $response['cont'] = $data4;

  echo json_encode(array_merge_recursive($select,$agent,$running,$p,$pay_type,$response));
  
  
}

if($type==10){
    
    $dbs=$db1->sql("select CONCAT(id,'|',sub_name,'|',gname,'|',t_no) as name,id as chitid from sm_main_form_1417 where del is null and name='".$data['led_id']."'  ")->many();
    echo json_encode($dbs);
}


if($type==11){
     $group_name=$data['grp_id'];



     
    extract($_POST);
    
    $response = array();
    
    //  $data6 = array('DUE','DISCOUNT','FCOM','TBAL','DUE_AMT','DIVI','AUC_DATE','CHIT_ID','NAME','CHIT_VAL','AUC_AMT');
     
     $data6 = array('DUE','AUC_DATE','DISCOUNT','FCOM','TBAL','DUE_AMT','DIVI','CHIT_ID','NAME','CHIT_VAL','AUC_AMT');
   
 $cond='';
           if(!empty($group_name)){
               $cond .=" and grp='".$group_name."' ";
           }
   
   $gp = $db1->sql("select * from sm_main_form_1416 where cid = ".$cid."  and id='$group_name' and  del is null ")->one();  
// if($cid == '34569999' )  { 
//               $aid =$gp['aid'];
//               $bid = $gp['bid'];
                      
//                       $tb = $db1->sql("SELECT *  FROM sm_main_form_1427 where cid='$cid' and aid='$aid' and bid='$bid'  order by date ASC ")->many(); 
//               }else{
                   
$tb = $db1->sql("SELECT *  FROM sm_main_form_1427 where del is null and cid='$cid'    $cond  group by due_no order by date ASC ")->many(); 
               
            //   }
               
          $i=1;
                   $collection = 0;
                   $dividend1 = 0;
                   $total1 = 0;
                   $balance1 = 0;
                   $tbal=0;
              foreach($tb as &$sa){
            //       if($cid == '34569999' )  {
            //       if($sa['date'] < '2022-03-31'){
            //           $chit=$db1->sql("SELECT * FROM `sm_main_form_1417` WHERE `grp` = '".$sa['grp']."' AND `p_type` = '".$sa['due_no']."' ")  ->one();      
            //   $sa['chit_id']=$chit['id'];
            //   $sa['name']=$chit['sub_name'];
            //       }
              
                 
            //  $sa['dis_amount']= $sa['chit_value'] - $sa['auc_amount'];
            //   $bal=$sa['dis_amount'] - $sa['fcom_amount'];
            //     $due=($sa['chit_value'] / $gp['no_ins'] )- $sa['div_amount'];
            //   if($due == '0'){
            //       $tbal += $bal -$sa['chit_value'] ; 
            //   }
               
            //   else{
            //       $tbal +=$bal;
            //   }
            //  }
                //   $due=($sa['chit_value'] / $gp['no_ins'] )- $sa['div_amount'];
                      if($cid == '34569999' )  {
                 if($sa['date'] < '2022-03-31'){
                 $chit=$db1->sql("SELECT * FROM `sm_main_form_1417` WHERE del is null and `grp` = '".$sa['grp']."' AND `p_type` = '".$sa['due_no']."' ")  ->one();      
              $sa['chit_id']=$chit['id'];
              $sa['name']=$chit['sub_name'];
                 
                 }
                  }
                //  $sa['amount']=$sa['dis_amount'] ;
                 $due = $db1->sql("SELECT actual_due,due,amount,div_amount  FROM sm_main_form_1425  where  del is null and cid='$cid'   and due='".$sa['due_no']."'  and grp_id='".$group_name."' group by due order by date ASC ")->one(); 
                 
                 
             $sa['dis_amount']= $sa['chit_value'] - $sa['auc_amount'];
              $bal = $sa['dis_amount'] - $sa['fcom_amount'];
              
                //  if($sa['date'] <= '2022-03-31'){
                // $due=($sa['chit_value'] / $gp['no_ins'] )- $sa['div_amount'];
                //  }else{
                //      $due=$sa['actual_due'];
                //  }
                
              if($due['actual_due'] <= '0'){
                  $tbal += $bal -$sa['chit_value'] ; 
              }
              else{
                  $tbal +=$bal;
              }
              
               if($due['actual_due'] > '0') {$dt= $due['actual_due'];}else{ $dt= '0';}

                 $data4[]=array('DUE'=>$sa['due_no'],'AUC_DATE'=>date('d-m-Y',strtotime($sa['date'])),'DISCOUNT'=>$sa['dis_amount'],'FCOM'=>$sa['fcom_amount'],'TBAL'=>$tbal,'DUE_AMT'=>$dt,'DIVI'=>$due['div_amount'],'CHIT_ID'=>$sa['chit_id'],'NAME'=>$sa['name'],'CHIT_VAL'=>$sa['chit_value'],'AUC_AMT'=>$sa['auc_amount']);
           
            $i++;
                    }

    
    $response['header'] = $data6;
    $response['cont'] = $data4;

  echo json_encode($response);
  
  
  
  /*start request save*/ 
    $url="report_api.php";
    $rl="Auction Report";
    date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  .", CID : " . $data['cid'] .", TYPE  : " . $data['type'].",  URL  :" . $url.",  MENU : ".$rl.", Grp  :".$group_name ." - ".$gp['name'] ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
/* end request save*/

}





 

