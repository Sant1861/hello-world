<?php
// ini_set("display_errors",1);
// error_reporting(0);


$cid=$_POST['cid'];

// $cid='21472147';


$url="index.php";
$new=fopen("mobile.txt",a);
date_default_timezone_set("Asia/Kolkata");
$CURENTDATE=date("Y-m-d H:i:s");

$write="[".$CURENTDATE."-".$_POST['cid']."-".$_POST['type']." ]OTP ";

fwrite($new,$write);
fwrite($new,"\r\n");
fclose($new);


require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
// print_r($_POST);
// $type = $_POST['type'];
// $data=$_POST;
// print_r("$_POST");
// echo $_POST['mobile']."prem";

 if(isset($_POST['mobile']))
  {
    //   print_r($_POST);
    // extract($_POST);
    // echo"premmmm";
     $item = $db->from('sm_main_form_20')->where('mobile',$_POST['mobile'])->where('role_id',$_POST['role_id'])->where('del #',null)->one();
   $count = count($item);
    
// echo $count."kumarrr";
    if($item['role_id'] === $_POST['role_id']){
         if($count!=0)
     {
         
        //  echo"dinesh";
          if($_POST['mobile']==9876543210){
              $otp=123456;
              $in = array('date'=>date('Y-m-d'),'led_id'=>$item['led_id'],'cid'=>$_POST['cid'],'mobile'=>9876543210,'otp'=>$otp,'device_id'=>$device_id,'test'=>$thu);
 	$ins = $db->from('otp')->insert($in)->execute();
 	
         $data = array('mobile'=>9876543210);
         $data['cid'] = $_POST['cid'];
          
            $data['role_id'] = $item['role_id'];
         $data['uid'] =$item['id'];
         $data['led_id'] =$item['led_id'];
         $data['comp_name'] = $pna['name'];
         //$data = array('id'=>5);
         	
          }
        else{
            // echo"sk";
            
            $del = $db->from('otp')->where('led_id',$item['led_id'])->update(array('status'=>2))->execute();
         $otp = $user->generateotp(6);

         $name1 = $db1->from('sm_main_form_104')->where('id',$item['led_id'])->where('del #',null)->one();
         $mobile=$name1['mobile'];
        //  $name = $name1['name'];
        $name="Customer";
         $phone = $mobile;
//   $phone = $mobile;
  
	$msg = "<#> SMART: Dear $name ,Your OTP number for login is $otp Don't share this code with others By SMART $tok";
  
  $sid ="";
$thu= $user->sendsms_api($phone,$msg,$_POST['cid'],17);
 $pna = $db->from('sm_main_form_7')->where('cid',$_POST['cid'])->one();
 	$in = array('date'=>date('Y-m-d'),'led_id'=>$item['led_id'],'cid'=>$_POST['cid'],'mobile'=>$phone,'otp'=>$otp,'device_id'=>$device_id,'test'=>$thu);
 	$ins = $db->from('otp')->insert($in)->execute();
 	
         $data = array('mobile'=>$phone);
         $data['cid'] = $_POST['cid'];
          
            $data['role_id'] = $item['role_id'];
         $data['uid'] =$item['id'];
         $data['led_id'] =$item['led_id'];
         $data['comp_name'] = $pna['name'];
         //$data = array('id'=>5);
         	$data["error"]= FALSE;
		 $data["error_msg"] = "Allow to next page";
		  //echo json_encode($data);
        }
     }
     else
     {
    $data["error"] = TRUE;
    $data["error_msg"] = "Your phone number is wrong Or You Don't Have an Account"; 
     }
    }else{
        $data["error"] = TRUE;
    $data["error_msg"] = "Your Login is  wrong"; 
    }
     
             echo json_encode($data);
  }

  ?>                                      