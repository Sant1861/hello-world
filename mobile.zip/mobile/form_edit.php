<?php 

ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
require_once('form_fields_lw.php');



$db= new Dbclass();

$db1=new Dbclass($cid);

extract($_POST);

if($type==40){
    
    if($sub_type==1){
//     $response=array();
//     if($prod_id!=""){
        
//         // if($category!="" && $sub_cat!="" &&   $pro_type!="" &&   $client_name!="" &&   $client_whatsapp!="" &&   $client_whatsapp!="" &&  $client_mobile!="" &&   $client_address!="" &&   $client_whatsapp!="" &&  $listing_for!="" &&
//         // $product_title!="" &&  $size_type!="" &&  $product_size!="" &&  $price_in_number!="" &&  $price_in_alphabet!="" &&  $address!="" &&  $postal_code!="" &&  $area!="" &&  $city!="" &&  $type_of_customer!="" &&
//         // $latitude!="" &&  $logitute!="" &&  $description!="" &&  $near_by!=""){
        
//  echo $data=$db1->sql("update add_property set category='$category' , sub_cat='$sub_cat' , pro_type='$pro_type' , client_name='$client_name' , client_whatsapp='$client_whatsapp' , client_mobile='$client_mobile' , client_address='$client_address' , 
//                         listing_for='$listing_for' ,product_title='$product_title' ,size_type='$size_type' ,product_size='$product_size' ,price_in_number='$price_in_number' , price_in_alphabet='$price_in_alphabet' , address='$address',  postal_code='$postal_code', 
//                         area='$area' , city='$city' , type_of_customer='$type_of_customer' , latitude='$latitude' , logitute='$logitute' , description='$description' , near_by='$near_by' where del is null and id='$prod_id' ")->sql(); 
                        
//                         if($data==true){
//                              $response['error']=false;
//                 $response['error_msg']="Update Success";
//                         }
//         // }
//         // else{
//         //         $response['error']=true;
//         //         $response['error_msg']="fill all fields";
//         //     }
//     }else{
//                 $response['error']=true;
//                 $response['error_msg']="Prod_id is missing";
//             }
            
//             echo json_encode($response);







    $data1=$_POST;

 $ip = json_decode($data1['data'][0], true);
$ipp=$ip[0];
     $db1->sql("SET NAMES utf8")->execute();	
	$selectdata = $db1->from("sm_main_form_1003")->where("main","1")->where("form_id",'add_property')->select("name")->many();

foreach($selectdata as &$val ){
	$vall = $val['name'];
	if (array_key_exists($vall, $ipp)){
		$data[$vall] = $ipp[$vall];
	}
}	
$form = "add_property";
$result =$db1->from($form)
        ->where('id',$prod_id)
    ->update($ipp)
    ->sql();
    
//  $db1->sql($result)->execute();
// 	$lastid = $db1->insert_id;
	

	
	
	
    $data2 = array('category'=>$data1['cat_id'],'sub_cat'=>$data1['sub_cat_id'],'pro_type'=>$data1['pro_type_id'],'uid'=>$data1['uid'],'cid'=>$data1['cid'],'latitude'=>$data1['lt'],'logitute'=>$data1['ln'],'type'=>'2','paid'=>1,'date'=>date("y-m-d") );
  $result=$db1->from('add_property')->where('id',$prod_id)->update($data2) ->sql();
  
//   $response["error"] = FALSE;
//     $response["error_msg"] = "Save Sucessfully";
//     $response["last_id"] = $lastid;
  echo json_encode($result);
    }
  
}

if($sub_type==2){
    
   $data=$db1->sql("select pro_type,sub_cat from add_property where id='$pro_id'")->one();
   
   echo json_encode($data);
}


   ?>