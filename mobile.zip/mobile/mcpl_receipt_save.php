<?php
// Log..

ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1=new Dbclass($cid);

$type=$_POST['type'];

if($type==12){
    
if($_POST['p_type']=='2'){
    
    $sst=$_POST['cq_no'];
    $chd=date('Y-m-d',strtotime($_POST['cq_date']));
}
     
 if($_POST['p_type']=='3'){
   $sst=  $_POST['refr'];
 }
     
    
    
       $chit_id=$_POST['chit_id'];
    

      $ss=$db->sql("select def_acc,led_id,route_id,name from sm_main_form_20 where del is null and id='".$_POST['uid']."' and cid='".$_POST['cid']."' ")->one();
      $_POST['pay_acc']=$ss['def_acc'];
      $_POST['agent']=$ss['led_id'];
      $_POST['route']=$ss['route_id'];

      $_data1 = array('date'=>date('Y-m-d',strtotime($_POST['date'])),'cid'=>$_POST['cid'],'ef'=>1,'aid'=>$_POST['aid'],'uid'=>$_POST['uid'],'led_id'=>$_POST['led_id'],'name'=>$_POST['name'],'mobile'=>$_POST['mobile'],'address'=>$_POST['address'],'chit_id'=>$chit_id,'balance'=>$_POST['balance'],'amount'=>$_POST['amount'],'p_type'=>$_POST['p_type'],'pay_acc'=>$_POST['pay_acc'],'route'=>$_POST['route'],'col_type'=>$_POST['col_type'],'agent'=>$_POST['agent'],'refr'=>$sst,'chq_date'=>$chd);
      $result =  $db1->from('sm_main_form_1419')
             ->insert($_data1)
             ->execute();
             
	  $lastid = $db1->insert_id;
           
           	//save query for 140
     $re = array('cid'=>$_POST['cid'],'uid'=>$_POST['uid'],'trans_type'=>11,'trans_name'=>'Chit Receipt','trans_no'=>$lastid,'date'=>date('Y-m-d',strtotime($_POST['date'])),'led_id'=>$_POST['led_id'],'amount'=>'-'.$_POST['amount'],'chit_id'=>$chit_id,'descr'=>$_POST['name'],'remark'=>$_POST['mobile'].",".$_POST['address']);
                         
     $name = $db1->from('sm_main_form_140')->insert($re)->sql();
      $db1->sql($name)->execute();
                        
                        //  print_r($name);
                        
    if($_POST['p_type'] !='2'){
     $re1 = array('cid'=>$_POST['cid'],'uid'=>$_POST['uid'],'trans_type'=>11,'trans_name'=>'Chit Receipt','trans_no'=>$lastid,'date'=>date('Y-m-d',strtotime($_POST['date'])),'led_id'=>$_POST['pay_acc'],'amount'=>$_POST['amount'],'descr'=>$_POST['name'],'remark'=>$_POST['mobile'].", ".$_POST['address']);
                         
    $name1 = $db1->from('sm_main_form_140')->insert($re1)->sql();
                       
    $db1->sql($name1)->execute();
                        //  print_r($name1);
                        }

$loc=array('aid'=>$_POST['aid'],'uid'=>$_POST['uid'],'cid'=>$_POST['cid'],'receipt_no'=>$lastid,'latitude'=>$_POST['latitude'],'longitude'=>$_POST['longitude'],'location'=>$_POST['location'],'route_id'=>$_POST['route'],'col_ac'=>$_POST['pay_acc'],'agent'=>$ss['name']);


$loc_sav=$db1->from('sm_main_form_1463')->insert($loc)->execute();

        
         if($result==true){
          $response['error']="false";
          $response['error_msg']="Receipt Saved successfully";
            }
            else {
                 $response['error']="true";
          $response['error_msg']="Receipt Not Saved";
            }
            
            echo json_encode($response);
            
            
            
            
    date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE." CID : " .$_POST['cid']."  TYPE : " .$_POST['type']." RDATA : " .$_data1 ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);  
  
}




?>