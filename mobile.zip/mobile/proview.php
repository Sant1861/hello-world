<?php
/*SAVE QUERY*/
//  ini_set("display_errors",1);
$cid=21472147;

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
$type = $_POST['type'];
$data=$_POST;


  
if($type==16){
    



$qu = $db1->sql("SELECT b.id,b.pro_name,b.pro_price,b.area,b.bed_room,b.city,b.lt,b.pro_result,b.ln,b.sts_name,a.pro_img,a.pro_id FROM sm_main_form_102 as b INNER JOIN sm_main_form_103 as a ON a.pro_id = b.id WHERE (a.del is null) and (b.del is null)and (b.status=1) group by pro_id")->many();
			

  
   
 echo json_encode($qu);  
}
if($type==166){
    
$no_of_products_per_page=10;
$offset=$_POST['offset'];
$start_limit= $offset * $no_of_products_per_page;
$qu = $db1->sql("SELECT b.id,b.pro_name,b.pro_price,b.area,b.bed_room,b.city,b.lt,b.pro_result,b.ln,b.sts_name,a.pro_img,a.pro_id FROM sm_main_form_102 as b INNER JOIN sm_main_form_103 as a ON a.pro_id = b.id WHERE (a.del is null) and (b.del is null)and (b.status=1) group by pro_id limit $no_of_products_per_page offset $start_limit  ")->many();

  
   
 echo json_encode($qu);  
}
 
  

  
  
if($type==17){

			
$qu2=$db1->sql("SELECT * FROM sm_main_form_103 WHERE del is null  ")->many();
   foreach($qu2 as $res){
       $ak=$res['pro_id'];
       
      $qu1 = $db1->sql("SELECT  id,pro_price,pro_name,cat_name,pro_size,room,bathroom,garage,bed_room,year_build,land_mark,pro_sts,address,city,state,post_code,pro_occ,pro_stories,pro_building,park_space,pro_feature FROM sm_main_form_102 WHERE id=$ak and del is null GROUP BY pro_name")->one();
       $pro_name=$res['pro_img'];
    //   print_r($pro_name);
       
       
       
    //   $data1["pro_name"]=$res['pro_name'];
    //  $data1["cat_name"]=$res['cat_name'];
    //  $data1["pro_price"]=$res['pro_price'];
    //   $data1["pro_size"]=$res['pro_size'];
    //   $data1["room"]=$res['room'];
    //   $data1["bathroom"]=$res['bathroom'];
    //   $data1["garage"]=$res['garage'];
    //   $data1["garage_size"]=$res['garage_size'];
    //   $data1["bed_room"]=$res['bed_room'];
    //   $data1["year_build"]=$res['year_build'];
    //   $data1["land_mark"]=$res['land_mark'];
    //   $data1["pro_sts"]=$res['pro_sts'];
    //   $data1["address"]=$res['address'];
    //   $data1["city"]=$res['city'];
    //     $data1["state"]=$res['state'];
    //      $data1["post_code"]=$res['post_code'];
          
    //       $data1["pro_occ"]=$res['pro_occ'];
    //         $data1["pro_stories"]=$res['pro_stories'];
    //          $data1["pro_building"]=$res['pro_building'];
    //           $data1["park_space"]=$res['park_space']; 
    //           $data1["pro_feature"]=$res['pro_feature']; $data1["upcoming"]=$res['upcoming']; $data1["pro_img"]=$qu2['pro_img'];
      
    //   echo json_encode($data1);

   }

}
//   carsole api
  if($type==18){


$qu2=$db1->sql("SELECT pro_name ,id  FROM sm_main_form_102 WHERE del is null  ")->many();


// $data=array();
// $data1=array();
// $data2=array();
  foreach($qu2 as &$res){
     // $ak=$res['pro_id'];
      //echo $ak."<br>";
      
      
      $qu3=$db1->sql("SELECT pro_img FROM sm_main_form_103 WHERE del is null and pro_id='".$res['id']."'")->many();
  
    $res['img']=$qu3;

    //  array_push($data2,$qu3);

  }
   
   
//   array_push($data,array("value"=>$data1));
   
   echo json_encode($qu2);


}


 if($type==19){


$qu2=$db1->sql("SELECT * FROM sm_main_form_103 WHERE del is null  GROUP BY pro_id ")->many();


$data=array();
$data1=array();
$data2=array();
   foreach($qu2 as $res){
       $ak=$res['pro_id'];
       //echo $ak."<br>";
     
       $qu1 = $db1->sql("SELECT  id,pro_name, cat_name,pro_price,pro_size,room,bathroom,garage,garage_size,bed_room,year_build,land_mark,pro_sts,pro_name,sts_name,address,city,state,post_code,pro_occ,pro_stories,pro_building,park_space FROM sm_main_form_102 WHERE id=$ak  and del is null GROUP BY pro_name")->many();
      
       $qu3=$db1->sql("SELECT pro_img FROM sm_main_form_103 WHERE del is null and pro_id=$ak")->many();
   
     array_push($data1,array("title"=>$qu1),array("img"=>$qu3));
    //  array_push($data2,$qu3);

   }
   
   
   array_push($data,array("value"=>$data1));
   
   echo json_encode($data);


}

if($type==20){


$qu2=$db1->sql("SELECT * FROM sm_main_form_103 WHERE del is null  GROUP BY pro_id ")->many();


$data=array();
$data1=array();
$data2=array();
   foreach($qu2 as $res){
       $ak=$res['pro_id'];
       //echo $ak."<br>";
     
       $qu1 = $db1->sql("SELECT  id,pro_name, cat_name,pro_price,pro_size,room,bathroom,garage,garage_size,bed_room,year_build,land_mark,pro_sts,pro_name,address,city,state,post_code,pro_occ,pro_stories,pro_building,park_space FROM sm_main_form_102 WHERE id=$ak  and del is null and upcoming=1 GROUP BY pro_name")->many();
      
       $qu3=$db1->sql("SELECT pro_img FROM sm_main_form_103 WHERE del is null and pro_id=$ak and upcoming=1 LIMIT 5")->many();
   
     array_push($data1,array("title"=>$qu1),array("img"=>$qu3));
    //  array_push($data2,$qu3);

   }
   
   
   array_push($data,array("value"=>$data1));
   
   echo json_encode($data);


}

if($type==21){

						 $qu = $db1->sql("SELECT b.id,b.pro_name,b.city,a.pro_img,a.pro_id FROM sm_main_form_102 as b INNER JOIN sm_main_form_103 as a ON a.pro_id = b.id WHERE (a.del is null) and (b.del is null) ")->many();
			

//   muti images api
   
 echo json_encode($qu);  
}


//New Code End

  if($type==22){

						 $upcoming = $db->sql("SELECT value,name FROM sm_main_form_11  WHERE list_id=195")->many();
			

//   muti images api
   
 echo json_encode($upcoming);  
}
   
  if($type==23){

						 $prosts = $db->sql("SELECT value,name FROM sm_main_form_11  WHERE list_id=193")->many();
			
                        // $prosts['name']=$prosts1['name'];
//   muti images api
   
 echo json_encode($prosts);  
}
  
if($type==29){
// 	print_r($_POST);
$id=$data['id'];

 $result=$db1->sql("SELECT * FROM sm_main_form_102 WHERE id=$id and del IS NULL ORDER BY id DESC")->many();
                            
                         
                            foreach($result as $res)
                            {
					$idd=$res['id'];

              $pro_img3=$db1->sql("SELECT pro_img FROM sm_main_form_103 WHERE pro_id=$idd and  del IS NULL")->many();
       
        
        // $pro_img1=$pro_img3['pro_img'];
        

        
        
        
                    
      $data1["pro_name"]=$res['pro_name'];
     $data1["cat_name"]=$res['cat_name'];
     $data1["pro_price"]=$res['pro_price'];
      $data1["pro_size"]=$res['pro_size'];
      $data1["room"]=$res['room'];
      $data1["bathroom"]=$res['bathroom'];
      $data1["garage"]=$res['garage'];
      $data1["garage_size"]=$res['garage_size'];
      $data1["bed_room"]=$res['bed_room'];
      $data1["year_build"]=$res['year_build'];
      $data1["land_mark"]=$res['land_mark'];
      $data1["pro_sts"]=$res['pro_sts'];
      $data1["address"]=$res['address'];
      $data1["city"]=$res['city'];
      $data1["state"]=$res['state'];
      $data1["post_code"]=$res['post_code'];
          $data1["sts_name"]=$res['sts_name'];
          $data1["pro_occ"]=$res['pro_occ'];
            $data1["pro_stories"]=$res['pro_stories'];
             $data1["pro_building"]=$res['pro_building'];
              $data1["park_space"]=$res['park_space']; 
              $data1["pro_feature"]=$res['pro_feature'];
              $data1["upcoming"]=$res['upcoming'];
              $data1["category_name"]=$res['category_name'];
              $data1["seller"]=$res['seller'];
              $data1["seller_name"]=$res['seller_name'];
              $data1["sel_name"]=$res['sel_name'];
              $data1["pro_desc"]=$res['pro_desc'];
                $data1["pro_feature"]=$res['pro_feature'];
              $data1["lt"]=$res['lt'];
              $data1["ln"]=$res['ln'];
              
              $data1["pro_img"]=$pro_img3;
      
      

                            }
echo json_encode($data1);
}



  if($type==25){
                        // $qu = $db1->sql("SELECT b.id,b.pro_name,b.pro_price,b.city,b.area,b.lt,b.ln,b.sts_name,a.pro_img,a.pro_id FROM sm_main_form_102 as b INNER JOIN sm_main_form_103 as a ON a.pro_id = b.id WHERE (a.del is null) and (b.del is null) and (b.area='$area')and (b.city='$city')and(b.sts_name='$stsname') group by pro_id ")->many();
						 $prosts = $db1->sql("SELECT name,id FROM sm_main_form_99 where del is null")->many();
			
                        // $prosts['name']=$prosts1['name'];
//   area name
   
 echo json_encode($prosts);  
}
   
   
     if($type==26){
        //  city name api
         
          $prosts = $db1->sql("SELECT code,name,id FROM sm_main_form_112  WHERE (del is null) ")->many();
          
          
        //   $prosts = $db1->sql("SELECT a.name,a.id FROM sm_main_form_112 as a INNER JOIN sm_main_form_102 as b ON b.city=a.name WHERE (a.del is null) and (b.del is null) GROUP BY b.city")->many(); old api

				// 		 $prosts = $db1->sql("SELECT name,id FROM sm_main_form_112  WHERE del is null")->many();
			
                        // $prosts['name']=$prosts1['name'];
//   muti images api
   
 echo json_encode($prosts);  
}

     if($type==27){

						 $prosts = $db1->sql("SELECT cat_name,id FROM sm_main_form_101  WHERE del is null")->many();
			
                        // $prosts['name']=$prosts1['name'];
//   muti images api
   
 echo json_encode($prosts);  
}


     if($type==28){

						 $prosts = $db1->sql("SELECT cat_name,id FROM sm_main_form_101  WHERE del is null")->many();
			
                        // $prosts['name']=$prosts1['name'];
//   muti images api
   
 echo json_encode($prosts);  
}


     if($type==30){

						 $prosts1 = $db1->sql("SELECT name,id FROM sm_main_form_100  WHERE del is null")->many();
			
                        // $prosts['name']=$prosts1['name'];
//   muti images api
   
 echo json_encode($prosts1);  
}

if($type==31){
$city=$data['city'];
$area=$data['area'];
$stsname=$data['sts_name'];

// choose area api

					 $qu = $db1->sql("SELECT b.id,b.pro_name,b.pro_price,b.city,b.area,b.lt,b.ln,b.sts_name,a.pro_img,a.pro_id FROM sm_main_form_102 as b INNER JOIN sm_main_form_103 as a ON a.pro_id = b.id WHERE (a.del is null) and (b.del is null) and (b.area='$area')and (b.city='$city')and(b.sts_name='$stsname') group by pro_id ")->many();
			

  
   
 echo json_encode($qu);
}

if($type==32){
    
    
$mob=$data['c_mobile'];

					 $qu = $db1->sql("SELECT b.id,b.pay_done,b.pro_name,b.pro_price,b.city,b.lt,b.ln,b.pay_done,b.sts_name,b.c_mobile,a.pro_img,a.pro_id FROM sm_main_form_102 as b INNER JOIN sm_main_form_103 as a ON a.pro_id = b.id WHERE (a.del is null) and (b.del is null) and (b.c_mobile='$mob')  group by pro_id ")->many();
			

  
   
 echo json_encode($qu);  
}
 if($type==33){

				// 		 $prosts = $db1->sql("SELECT cat_name,id FROM sm_main_form_121  WHERE del is null")->many();
			
    

 $name=$_POST['name'];
 $cost=$_POST['cost'];
 $duration=$_POST['duration'];
 
 
 
$data1 = array('cid' => $data['cid'],'bid' => $data['bid'],'uid' => $data['uid'],'aid' => $data['aid'],'name'=>$data['name'],'cost'=>$data['cost'],'duration'=>$data['duration'],'c_mobile'=>$data['c_mobile']);
 
   
  $qury1=$db1->from('sm_main_form_121')->insert($data1)->execute(); 
//  echo ($insert);
 
 echo "insert successfull";
 
}

if($type==34){


// print_r($_POST);


$id=$data['id'];

 $result=$db1->sql("SELECT * FROM sm_main_form_102 WHERE id='$id' and del IS NULL")->many();
                            
                         
                            foreach($result as $res)
                            {
					$idd=$res['id'];

               $pro_img=$db1->sql("SELECT pro_img FROM sm_main_form_103 WHERE pro_id=$idd and   del IS NULL")->many();
       
        
        
        
	
        
        
        
                    
      $data1["pro_name"]=$res['pro_name'];
      $data1["cat_name"]=$res['cat_name'];
      $data1["pro_price"]=$res['pro_price'];
      $data1["pro_size"]=$res['pro_size'];
      $data1["room"]=$res['room'];
      $data1["bathroom"]=$res['bathroom'];
      $data1["garage"]=$res['garage'];
      $data1["garage_size"]=$res['garage_size'];
      $data1["bed_room"]=$res['bed_room'];
      $data1["year_build"]=$res['year_build'];
      $data1["land_mark"]=$res['land_mark'];
      $data1["pro_sts"]=$res['pro_sts'];
      $data1["address"]=$res['address'];
      $data1["city"]=$res['city'];
      $data1["state"]=$res['state'];
      $data1["post_code"]=$res['post_code'];
      $data1["pro_occ"]=$res['pro_occ'];
      $data1["pro_stories"]=$res['pro_stories'];
      $data1["pro_building"]=$res['pro_building'];
      $data1["park_space"]=$res['park_space']; 
      $data1["pro_feature"]=$res['pro_feature'];
      $data1["upcoming"]=$res['upcoming'];
      $data1["category_name"]=$res['category_name'];
      $data1["seller"]=$res['seller'];
      $data1["seller_name"]=$res['seller_name'];
      $data1["sel_name"]=$res['sel_name'];
      $data1["pro_desc"]=$res['pro_desc'];
      $data1["pro_feature"]=$res['pro_feature'];
      $data1["url"]='https://truebroker.in/'.$res['pro_alfa_code'];
      $data1["lt"]=$res['lt'];
      $data1["ln"]=$res['ln'];
      $data1["sts_name"]=$res['sts_name'];
       $data1["c_mobile"]=$res['c_mobile'];
      $data1["pro_img"]=$pro_img;
      
      echo json_encode($data1);

                            }

}


if($type==35){
$city=$data['city'];
$area=$data['area'];
$stsname=$data['sts_name'];
$prtype=$data['price_type'];

// $stsname=$data['checklist'];

// print_r($_POST);
//   echo $stsname[0];

// $stsname1=$data['checklist'][1];
// $stsname2=$data['checklist'][2];
// $stsname2=$data['checklist'][3];
// foreach($stsname as $res1){
    
// }
//  print_r($_POST);
// $ase=$data['price_type'];
// choose area api
// echo"$stsname0"."prem";
// echo"$stsname1"."prem1";
// echo"$stsname2"."prem2";
// echo"$stsname3"."prem3";

// if($prtype=="lowest"){
    // echo "sel";
          $qu = $db1->sql("SELECT b.id,b.pro_name,b.pro_price,b.city,b.area,b.lt,b.ln,b.sts_name,a.pro_img,a.pro_id FROM sm_main_form_102 as b INNER JOIN sm_main_form_103 as a ON a.pro_id = b.id WHERE (a.del is null) and (b.del is null) and (b.area='$area')and (b.city='$city') group by pro_id ")->sql();
echo json_encode($qu);
// }


}



if($type==36){
//   print_r($_POST);
$h0=$_POST['checklist'];
// echo "check".$h0;
$ex=explode(',',$h0);
$check0 = str_replace( array(']', '"', ';','['), '', $ex[0]);
$check1 = str_replace( array(']', '"', ';','['), '', $ex[1]);
$check2 = str_replace( array(']', '"', ';','['), '', $ex[2]);
$check3 = str_replace( array(']', '"', ';','['), '', $ex[3]);
// echo "check0".$check0."<br>";
// echo "check1".$check1."<br>";
// echo "check2".$check2."<br>";
// echo "check3".$check3."<br>";
$h1=$_POST['checklist'][1];
$h2=$_POST['checklist'][2];
    
$city=$data['city'];
$area=$data['area'];
$stsname=$data['sts_name'];
$price_type=$data['pro_pricelist'];
$checklist="('$check0','$check1','$check3','$check2')";
$catname=$data['cat_name'];


$qu = $db1->sql("SELECT b.id,b.pro_name,b.price_no,b.pro_price,b.city,b.area,b.lt,b.ln,b.sts_name,a.pro_img,a.pro_id FROM sm_main_form_102 as b INNER JOIN sm_main_form_103 as a ON a.pro_id = b.id WHERE (a.del is null) and (b.del is null) and (b.area='$area')and (b.city='$city') and (category_name='$catname') and sts_name IN $checklist group by pro_id order by price_no desc  ")->many();



echo json_encode($qu);

//  [checklist] => ["sale","rent"]
// $ase=$data['price_type'];
// choose area api
// echo"$stsname0"."prem";
// echo"$stsname1"."prem1";
// echo"$stsname2"."prem2";
// echo"$stsname3"."prem3";

// if($price_type=="Lowest"){
//     // echo "Lowest";
//          $qu = $db1->sql("SELECT b.id,b.pro_name,b.price_no,b.pro_price,b.city,b.area,b.lt,b.ln,b.sts_name,a.pro_img,a.pro_id FROM sm_main_form_102 as b INNER JOIN sm_main_form_103 as a ON a.pro_id = b.id WHERE (a.del is null) and (b.del is null) and (b.area='$area')and (b.city='$city') and sts_name IN $checklist group by pro_id order by price_no desc  ")->many();
        
// echo json_encode($qu);

// }


// if($price_type=="Highest"){
//     // echo "highest";
//          $qu = $db1->sql("SELECT b.id,b.pro_name,b.price_no,b.pro_price,b.city,b.area,b.lt,b.ln,b.sts_name,a.pro_img,a.pro_id FROM sm_main_form_102 as b INNER JOIN sm_main_form_103 as a ON a.pro_id = b.id WHERE (a.del is null) and (b.del is null) and (b.area='$area')and (b.city='$city')  and sts_name IN $checklist group by pro_id order by price_no  ")->many();
// echo json_encode($qu);

// }


}

if($type==38){

				
 
  $prosts = $db1->sql("SELECT a.cat_name FROM sm_main_form_101 as a INNER JOIN sm_main_form_102 as b ON b.category_name=a.cat_name WHERE (a.del is null) and (b.del is null) GROUP BY b.category_name")->many(); 
 
 
 echo json_encode($prosts);  
}  

    
   
    
 if($type==39){
//  print_r($_POST);
$h0=$_POST['checklist'];
// echo "check".$h0;
$ex=explode(',',$h0);
$check0 = str_replace( array(']', '"', ';','['), '', $ex[0]);
$check1 = str_replace( array(']', '"', ';','['), '', $ex[1]);
$check2 = str_replace( array(']', '"', ';','['), '', $ex[2]);
$check3 = str_replace( array(']', '"', ';','['), '', $ex[3]);
// echo "check0".$check0."<br>";
// echo "check1".$check1."<br>";
// echo "check2".$check2."<br>";
// echo "check3".$check3."<br>";
$h1=$_POST['checklist'][1];
$h2=$_POST['checklist'][2];
    
$city=$data['city'];
$area=$data['area'];
$stsname=$data['sts_name'];
$price_type=$data['pro_pricelist'];
$checklist="('$check0','$check1','$check3','$check2')";
$catname=$data['cat_name'];


 $qu = $db1->sql("SELECT b.id,b.pro_name,b.price_no,b.pro_price,b.city,b.area,b.lt,b.ln,b.sts_name,a.pro_img,a.pro_id FROM sm_main_form_102 as b INNER JOIN sm_main_form_103 as a ON a.pro_id = b.id WHERE (a.del is null) and (b.del is null) and (b.area='$area') or (b.city='$city') or (category_name='$catname') and sts_name IN $checklist group by pro_id order by price_no desc  ")->many();



echo json_encode($qu);

//  [checklist] => ["sale","rent"]
// $ase=$data['price_type'];
// choose area api
// echo"$stsname0"."prem";
// echo"$stsname1"."prem1";
// echo"$stsname2"."prem2";
// echo"$stsname3"."prem3";

// if($price_type=="Lowest"){
//     // echo "Lowest";
//          $qu = $db1->sql("SELECT b.id,b.pro_name,b.price_no,b.pro_price,b.city,b.area,b.lt,b.ln,b.sts_name,a.pro_img,a.pro_id FROM sm_main_form_102 as b INNER JOIN sm_main_form_103 as a ON a.pro_id = b.id WHERE (a.del is null) and (b.del is null) and (b.area='$area')and (b.city='$city') and sts_name IN $checklist group by pro_id order by price_no desc  ")->many();
        
// echo json_encode($qu);

// }


// if($price_type=="Highest"){
//     // echo "highest";
//          $qu = $db1->sql("SELECT b.id,b.pro_name,b.price_no,b.pro_price,b.city,b.area,b.lt,b.ln,b.sts_name,a.pro_img,a.pro_id FROM sm_main_form_102 as b INNER JOIN sm_main_form_103 as a ON a.pro_id = b.id WHERE (a.del is null) and (b.del is null) and (b.area='$area')and (b.city='$city')  and sts_name IN $checklist group by pro_id order by price_no  ")->many();
// echo json_encode($qu);

// }


}
  
    

 if($type==40){

						 $prosts = $db1->sql("SELECT * FROM sm_main_form_126  WHERE del is null")->many();
			
                        // $prosts['name']=$prosts1['name'];
//  payment tabel
   
 echo json_encode($prosts);  
}

if($type==41){
    
    
     $id=$data['id'];
    
    		 $qu=$db1->sql("SELECT b.id,b.cat_name,b.pro_name,b.pro_price,b.city,b.lt,b.ln,b.sts_name,a.pro_img,a.pro_id FROM sm_main_form_102 as b INNER JOIN sm_main_form_103 as a ON a.pro_id = b.id WHERE (b.cat_name=3) and (a.del is null)  and (b.del is null) group by pro_id")->many();
			

  
   
 echo json_encode($qu);  

					
                            }
                            
                            
if($type==42){
    
    
$qu=$db1->from('sm_main_form_129')->many();
 echo json_encode($qu);  

// 			notification api	
       
                            }
                            
if($type==43){
    
    
$qu=$db->sql("SELECT value,name FROM sm_main_form_11  WHERE list_id=198 and del is null")->many();
 echo json_encode($qu);  

// 	booked or notapi			
       
  }
                        
if($type==44){
    
    
$id=$data["id"];
$value=$data['value'];
 $qu=$db->sql("SELECT value,name FROM sm_main_form_11  WHERE list_id=198 and value=$value and del is null")->one();
$name=$qu['name'];


// echo $name."prem";
 
 $data1 = array('pro_result'=>$name);
  $result=$db1->from('sm_main_form_102')->where('id',$id)->update($data1) ->execute();


// booked status api


 }


if($type==45){
    
    
$qu=$db->sql("SELECT value,name FROM sm_main_form_11  WHERE list_id=196 and del is null")->many();
 
//  $qu['error']=FALSE;
//  $qu['error_mgs']="image upload sucessfull";
 
 echo json_encode($qu);  

// 	agent promotor  or channel partner api			
       
  }




 if($type==46){

						 $prosts = $db1->sql("SELECT * FROM sm_main_form_134  WHERE del is null")->many();
						 
						  //$prosts['error']=FALSE;
        //                           $prosts['error_mgs']="image upload sucessfull";

 echo json_encode($prosts);  
}
 if($type==47){
    //  print_r($_POST);
     
$id=$data['id'];
$pay_id=$data['pay_id'];
						 $data1 = array('pay_id'=>$pay_id);
 $result=$db1->from('sm_main_form_102')->where('pro_code',$id)->update($data1) ->execute();
						 
						             $prosts['error']=FALSE;
                                  $prosts['error_mgs']="image upload sucessfull";

  echo json_encode($prosts);
}
if($type==48){
    // print_r($_POST);
   $mobile=$data['mobile'];


if($mobile==0){
    $dataw['error']=FALSE;
    $dataw['error_mgs']="send valid mobile number";
    echo json_encode($dataw);  
}
else{
    
    
    
					 $prosts = $db1->sql("SELECT * FROM sm_main_form_127 WHERE phone_num=$mobile and del is null")->one();
						 
						  //agent page
        //                           $prosts['error_mgs']="image upload sucessfull";
        // foreach($prosts as $prot){
           
        // $dataw['id']=$prot['id'];   
        // $dataw['cid']=$prot['cid'];   
        // $dataw['c_name']=$prot['c_name'];   
        // $dataw['c_add']=$prot['c_add'];   
        // $dataw['refer_by']=$prot['refer_by'];   
        // $dataw['name']=$prot['name'];   
        // $dataw['city']=$prot['city'];   
        // $dataw['email']=$prot['email'];   
        // $dataw['phone_num']=$prot['phone_num'];   
        // $dataw['pin_code']=$prot['pin_code'];   
        // $dataw['r_add']=$prot['r_add'];   
        // $dataw['w_num']=$prot['w_num'];   
        // $dataw['role_type']=$prot['role_type'];   
        // $dataw['imageapi']=$prot['imageapi'];   
        // $dataw['pro_code']=$prot['pro_code'];   
        // $dataw['specialties']=$prot['specialties']; 
        // $dataw['descr']=$prot['descr'];
        // $dataw['error']=FALSE;
        // $dataw['error_mgs']="upload sucessfull";
        
        // echo json_encode($dataw);
        // }

   echo json_encode($prosts);
}



}


if($type==49){
    //print_r($_POST);


$id=$_POST['id']; 
$data1 = array('phone_num' => $data['mobile'],'descr' => $data['desc'],'specialties' => $data['spec']);
$where = array('id' => $id);  
 $qury1=$db1->from('sm_main_form_127')->where($where)->update($data1)->execute(); 	

 echo json_encode($qury1);  


}

if($type==50){
    //print_r($_POST);


$check=$db1->sql("select id,state_name,code from sm_main_form_98 where del is null ")->many();	

 echo json_encode($check);  


}
  
     

  











 ?>