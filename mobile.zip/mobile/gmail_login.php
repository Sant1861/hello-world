<?php  
/*SAVE QUERY*/
// ini_set("display_errors",1);
$cid=$_POST['cid'];

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
$type = $_POST['type'];
$data=$_POST;

if($data['sub_type']==1){
   
// print_r($data);

    /* Role id check */
    if($data['role_id'] != '' && $data['role_id'] !='0' && $data['mobile'] ){
        
        $check=$db->sql("SELECT count(id)as cc FROM `sm_main_form_20` where mobile='".$data['mobile']."'  ")->one();
         $cc=$check['cc'];
        
        
        if($cc==0){
            $ldata=array('cid'=>$data["cid"],'f_name'=>$data["f_name"],'email'=>$data["email"],'mobile'=>$data['mobile'],'role_id'=>1,'token_email'=>$token);
        $ledinsert=$db1->from('sm_main_form_104')->insert($ldata)->execute();
         $last_id=$db1->insert_id;
     
      $ldata1=array('cid'=>$data["cid"],'f_name'=>$data["f_name"],'email'=>$data["email"],'mobile'=>$data['mobile'],'role_id'=>1,'led_id'=>$last_id,'token_email'=>$token);
      $ledinsert1=$db->from('sm_main_form_20')->insert($ldata)->execute();
           $last_id1=$db1->insert_id;  
      
        
   $check1=$db->sql("select * from sm_main_form_20 where del is null and mobile=$mobile and id=$last_id1")->one();
       $coins=$db1->sql("select * from sm_main_form_1012 where del is null and reward_type=1")->one();
       
      $ldata2=array('cid'=>$check1["cid"],'mobile'=>$check1['mobile'],'email'=>$data["email"],'coin'=>$coins['coins'],'description'=>"Welcome Bonus",'user_id'=>$last_id1,'date'=>date("Y-m-d"));
    $ledinsert1=$db->from('sm_main_form_20_1')->insert($ldata2)->execute();
      
      
      
      $sms = "அன்புள்ள $f_name,
பதிவு செய்ததற்கு நன்றி. TrueBroker குடும்பத்திற்கு வரவேற்கிறோம்! உங்கள் ப்ராடக்ட்  அல்லது ப்ரொபேர்ட்டி-யை  விளம்பரப்படுத்த உங்களுக்கு உதவ நாங்கள்  இருக்கிறோம். தயவுசெய்து தொடர்பில் இருங்கள்.URL:https://truebroker.in/ Youtube:https://www.youtube.com/channel/UCAHB84nlT-1D_mmbEMpWAqw Instagram:https://www.instagram.com/truebroker_india/ Facebook:https://www.facebook.com/profile.php?id=100088318544015";
	$wsms = array('cid' => $cid, 'mobile' => $mobile, 'message' => $sms);
	$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();
	
	$scall=$db1->sql("select * from sm_main_form_1024 where del is null")->many();

	foreach ($scall as $call) {

// 		$numw = $call['w_num'];


		$sms1 = "Dear Team One New Person Login On Trubroker App Name=$f_name,Mobile=$mobile Kindly Follow Him.,";

		$wsms = array('cid' => $cid, 'mobile' => $call['mobile'], 'message' => $sms1);
		$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();
	}

	
    
    $response["error"] = false;
    // $response['role_id']=$data['role_id'];
     $response['f_name']=$f_name;
      $response['email']=$email;
      $response['coin']=$ldata2['coin'];
      $response['uid']=$check1['id'];
  $response["error_msg"] = " Register successfully";
  
        }
       
        
        else{
            
            
             $check=$db->sql("select * from sm_main_form_20 WHERE del is null and mobile= mobile='".$data['mobile']."' ")->one();
            
            
             $ldata1=array('cid'=>$data["cid"],'email'=>$data["email"],'token_email'=>$token,'f_name'=>$data["f_name"]);
      $ledinsert1=$db->from('sm_main_form_20')->where('id',$check['id'])->update($ldata)->execute();
      
      
            $response['f_name']=$check['f_name'];
            $response['uid']=$check['id'];
            $response["error"] = true;
             $response["error_msg"] = "Already User";
  
        }
        
        echo json_encode($response);
    }
}
    


?>