<?php 

ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
require_once('form_fields_lw.php');



$db= new Dbclass();

$db1=new Dbclass($cid);

$f_field = new FORM_FIELD();


extract($_REQUEST);


$lwm_sub = $db1->sql("SELECT * FROM sm_main_form_1003  WHERE del Is NULL AND category='".$cat_id."' and filter=1")->many();


      
        $response = array();
        $data1 = array();
        
foreach($lwm_sub as &$sub){






        
       
          $data1[]= $f_field->fields($cid,$sub['que_name'],$sub['name'],$sub['ans_type'],$sub['values_from']);   

        

       
 
}

        //  $response['field_type'] = array('1'=>'TextBox','2' => 'Text area','3'=>'Sys Drop down','4'=>'Drop down','5'=>'Auto Complete','6'=>'Image','7'=>'File','8'=>'date','9'=>'Time','10'=>'CheckBox','11'=>'Radio','12'=>'Heading','13'=>'Editor','14'=>'Multi Select');
        // $response['cat_id'] = $cat_id;
        // $response['sub_cat_id'] = $sub_cat_id;
        // $response['pro_type_id'] = $pro_type_id;
       
      $response['data'] = $data1;
     echo json_encode([$response]);   
    

// $lwm_sub = $db1->from('sm_main_form_1011_1')->where('del #',null)->where('cat_id',$cat_id)->where('sub_cat_id',$sub_cat_id)->where('pro_type_id',$pro_type_id)->select('que_id')->many();
//  $qs[] = $db1->from('sm_main_form_1003')->where('id',$sub['que_id'])->select(array('que_name','name','ans_type','values_from'))->one();

?>