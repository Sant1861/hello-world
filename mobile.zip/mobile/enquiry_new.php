<?php
// Log..

ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db= new Dbclass();
$db1=new Dbclass($cid);

extract($_POST);




if($type==12){

    $response=array();
                                     
                                    $data1 = array(
                                                        
                                     'cid' => $cid,
                                     'date' => date('Y-m-d',strtotime($date)),
                                     's_name' => $s_name,                    
                                     'last_name' => $sur_name,                    
                                     'dob' =>  date('Y-m-d',strtotime($dob)),                    
                                     'address' => $address,
                                     'mobile' => $mobile,
                                     'email' => $email,
                                     'm_status' => $status,
                                     'passport' => $passport,
                                     'source_enquiry' => $source_enquiry,
                                     'refr' => $refr,
                                     
                                     'hsc_mark' => $eng_mark,
                                     'hsc_omark' => $overall_mark,
                                     'hsc_date' => date('Y-m-d',strtotime($c_date)),
                                     'hsc_course' => $courseid,

                                     'other_course' => $other_course,


                                     'd_english_mark' => $d_english_mark,
                                     'd_overall_mark' => $d_overall_mark,
                                     'd_course_studied' => $d_course_studied,
                                     'd_date' => date('Y-m-d',strtotime($d_date)),  

                                     'ug_overall_mark' => $ug_overall_mark,
                                     'ug_date' => date('Y-m-d',strtotime($ug_date)),
                                     'ug_course_studied' => $ug_course_studied,

                                     'pg_overall_mark' => $pg_overall_mark,
                                     'pg_date' => date('Y-m-d',strtotime($pg_date)),
                                     'pg_course_studied' => $pg_course_studied,

                                     'work_exp' => $work_exp,

                                     'ielts' => $ielts,
                                     'reading' => $reading,
                                     'writing' => $writing,
                                     'speaking' => $speaking,
                                     'overall' => $overall,
                                     
                                     'q1' => $q1,
                                     'q2' => $q2,
                                     'q3' => $q3,
                                     'q4' => $q4,
                                     'q5' => $q5,
                                     'q6' => $q6,    

                                     'q1_ans' => $q1_ans,
                                     'q2_ans' => $q2_ans,
                                     'q3_ans' => $q3_ans,
                                     'q4_ans' => $q4_ans,
                                     'q5_ans' => $q5_ans,
                                     'q6_ans' => $q6_ans,                          
                                      
                                  'country1' => $country1,
                                  'course1' => $course1,  
                                  'country2' => $country2,
                                  'course2' => $course2,  
                                 );                    
                                                     
                    $qury12=$db1->from('sm_main_form_101')->insert($data1)->sql();                    

                    // echo $qury1;
                    $result21=$db1->sql($qury12)->execute();
                    $lastid_2 = $db1->insert_id;    

   
    

      if($result21==true){
          $response['error']=false;
          $response['id']=$lastid_2;
          $response['error_msg']="Enquiry Save successfully";
            }
            else {
          $response['error']=true;
          $response['error_msg']="Something Went Wrong pls try again later";
            }
            
            echo json_encode($response);
    

  
    
}




?>