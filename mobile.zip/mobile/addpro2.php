 <?php
/*SAVE QUERY*/
//  ini_set("display_errors",1);
$cid=21472147;

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
$type = $_POST['type'];
$data=($_POST);

//  $data1=$_FILES;


if ($type==14) {
    
  extract($_POST);
  $data=($_POST);
    
    
    
//   print_r($_FILES);
// if($_FILES["imageapi$i"]["name"]!=" "){
   print_r($_POST);
   
 $z= $data["pro_sts"];
     $y=$data["cat_name"];    
$x=$data["pro_type"];
$w=$data["seller"];
$v=$data["area"];
$u=$data["seller_name"];

echo $x."prem";
   print_r($x);

 $catn1=$db1->sql("SELECT * FROM sm_main_form_100 WHERE cat_code=$x and del IS NULL")->one();
                       echo    $prosk= $catn1['name'];
    
    $check=$db->sql("select name from sm_main_form_11 where del is null and value=$z ")->one();
      $a=$check['name'];
      $catn=$db1->sql("SELECT * FROM sm_main_form_101 WHERE cat_code=$y and del IS NULL")->one();
                           $cat_name1= $catn['cat_name'];
     $check2=$db->sql("select name from sm_main_form_11 where del is null and value=$w ")->one();
      $d=$check2['name'];
    //  echo $a.'prem'.$cat_name1;
    
    $area1=$db1->sql("SELECT * FROM sm_main_form_99 WHERE id=$v and del IS NULL")->one();
                           $area2= $area1['name'];
    $selname=$db1->sql("SELECT * FROM sm_main_form_120 WHERE id=$u and del IS NULL")->one();
    
                           $selname2= $selname['ag_name'];
                           
                         echo $cat_name1."prem";
    
 $data1 = array('cid' => $data['cid'],'bid' => $data['bid'],'uid' => $data['uid'],'aid' => $data['aid'],'pro_name'=>$data['pro_name'],'cat_name' => $y,'category_name'=>$cat_name1,'pro_type' => $x,'property_type'=>$prosk,'pro_price' => $data['pro_price'],'pro_size' => $data['pro_size'],'room' => $data['room'],'bathroom' => $data['bathroom'],'garage' => $data['garage'],'garage_size' => $data['garage_size'],'bed_room' => $data['bed_room'],'year_build' => $data['year_build'],'land_mark' => $data['land_mark'],'pro_sts' => $data['pro_sts'],'sts_name' => $a,'address' => $data['address'],'city' => $data['city'],'area' => $area2,'state' => $data['state'],'post_code' => $data['post_code'],'pro_desc' => $data['pro_desc'],'pro_occ' => $data['pro_occ'],'pro_stories' => $data['pro_stories'],'pro_building' => $data['pro_building'],'park_space' => $data['park_space'],'seller_name'=>$u,'sel_name'=>$selname2,'pro_feature' => $data['pro_feature'],'lt' => $data['lt'],'ln' => $data['ln'],'upcoming'=>$data['upcoming'],'seller'=>$d );
 
   
  $qury1=$db1->from('sm_main_form_102')->insert($data1)->execute(); 
  
  
  
    $check=$db1->sql('select * from sm_main_form_102 order by dtime desc LIMIT 1 ')->one(); 
                                  $pid=$check['id'];
   
                                //   echo $pid.'prem';
   
    
    for ($i = 0;$i < array(count($_FILES["imageapi$i"])); $i++) { //loop to get individual element from the array
    
//   echo 'prem';
    
$target_dir = "../uploads/proimg1/";
                             
                             $target_file1 = $target_dir . basename($_FILES["imageapi$i"]["name"]);
                             
                            $imageFileType1 = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));

                            $mat_pic1 =$lastid1.'imageapi'.time().''.$i.'.'.$imageFileType1;

                            $target_file = $target_dir . $mat_pic1;

                            if (move_uploaded_file($_FILES["imageapi$i"]["tmp_name"], $target_file)) {
                                  echo "The file ". htmlspecialchars( basename( $_FILES["imageapi$i"]["name"])). " has been uploaded.";
                                 print_r($_FILES);
                                  $wmgs1="../uploads/proimg1/$mat_pic1"; 
                                  $data2=array('cid'=>$cid,'pro_id'=>$pid,'pro_img'=>$wmgs1);
                                  $qury2=$db1->from('sm_main_form_103')->insert($data2)->execute(); 
                                  echo "image upload sucessfull";
                              } else {
                                echo "Sorry, there was an error uploading your file.";
                              }
                             
                             
                             
                       
}

$dataw['error']=FALSE;
    $dataw['error_mgs']="allow to next page";

   echo json_encode($dataw);
}
   
?>