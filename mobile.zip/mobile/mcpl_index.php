
<?php 
ini_set("display_errors",1);
date_default_timezone_set('Asia/Kolkata');
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/class/user.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);

$user = new USER();
$response = array();
if(isset($_POST['cid']))
{
$cid = $_POST['cid'];
    //   require_once('../../app/sys/config/dbconfig2.php');
       $db1->sql("SET NAMES utf8")->execute();	
}

if(isset($_POST['type']) && $_POST['type'] !=''){
	
	$type =$_POST['type'];
	$mo_type = $db->from('sm_main_form_11')->where('list_id',141)->where('value',$type)->where('del #',null)->select('name')->one();
// 	$mo_type = $db->from('sm_main_form_23')->where('type',$type)->one();
	$type_name =  $mo_type['name'];
   
       include_once($type_name.".php");	
  
 
	
}
else {
    // required post params is missing
    $response["error"] = TRUE;
	
    $response["error_msg"] = $code."Required parameters  missing!";
    echo json_encode($response);
}

/* Start Request SAVE */

$url="mcpl_index.php";
$new=fopen("mcpl.txt",'a');
date_default_timezone_set("Asia/Kolkata");
$CURENTDATE=date("Y-m-d H:i:s");

$write="[".$CURENTDATE."-".$_POST['cid']."-".$_POST['type']."-".$_POST['category']."-".$_POST['request'];

fwrite($new,$write);
fwrite($new,"\r\n");
fclose($new);

/* End Request SAVE */


?>