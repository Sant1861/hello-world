<?PHP
ini_set('display_errors',0);
$cid=13051305;

 $ss="";
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');

$db = new Dbclass();
$db1 = new Dbclass($cid);
$db1->sql("SET NAMES utf8")->execute();
extract($_POST);






// if($type==39){
$ss="";
$limit=" limit 9";
$res="";
 $sear =""; 
 
 







 $data = $_POST;
//  print_r($data);
foreach ($data as $key => $value) {
    if (is_array($value)) {
       
        foreach ($value as $nestedValue) {
             "$nestedValue".",";
        }
       
    } else {
      
    }
    if($key!="offset"){
     $qry=$db1->sql("select * from sm_main_form_1057 where name='$key' and del is null and cat=1")->one();
    // print_r($qry);
    // echo json_encode($qry);
    switch ($qry['type']) {
        case 1:
            if($value != " " && !empty($value)){
            $sslike.="and $key like like '%$value%'";
            }
            else{
               $sslike.="";  
            }
           
            break;
        case 5:
             if($value != " " && !empty($value)){
            // $ss.="and $key like '%$value%'";
            $sslike.="and (  LOWER($key) LIKE LOWER('%$value%') OR
      LOWER(REPLACE($key, ' ', '')) LIKE LOWER('%$value%'))";
             }
             else{
                $sslike.="";    
             }
    break;

        case 2:
             if($value != " " && !empty($value)){
            $sslike.="and $key like like '%$value%'";
            }
            else{
               $sslike.="";  
            }
           
            
            break;
        case 0:
             if($value != " " && !empty($value)){
                 if($key!="pincode"){
            $ss.=" and ". $key ." = ". $value;
                 }
             }
             else{
                 $ss.="";   
             }
            break;
        case 4:
             if($value != " " && !empty($value)){
                $ss.=" and ". $key ." = ". $value;
            }
            else{
                $ss.="";    
            }
            break;
       case 14:
            if($value != " " && !empty($value)){
                
                
                    $array = explode(",", $value);
                                        if(strpos($value, ',') !== false) {
                                            // If $value contains commas
                                            $array1 = explode(",", $value);
                                            $conditions = [];
                                            foreach($array1 as $a){
                                                // Add conditions for each element in the exploded array
                                                $conditions[] = "".$a; // Assuming 'id' is the field name
                                            }
                                            // Combine conditions with OR
                                            $ss = "AND $key in (" . implode(" , ", $conditions) . ")";
                                        } else {
                                            // If there is no comma in the string, consider it as a single element array
                                            // Add condition for the single value
                                            $ss = "AND $key in  (" . $value.")"; // Assuming 'id' is the field name
                                        }
                        
                        
    //       $count1= count($value);
    //       $res="";
    //       for($i=0;$i<$count1;$i++){
    //           if($i==$count1-1){
    //           $res.= $value[$i];
    //           }
    //           else{
    //                   $res.= $value[$i].",";
    //           }
    //       }
    //      $res1= rtrim($res, ',');
    // $ss.=" and ". $key ." in ". "(".$res.")";
    
            }
            else{
                 $ss.="";    
            }
    break;

    }
   
}
else{
   if (!empty($offset)) {
        if ($offset != '') {
            $offset = $offset * 9;
            // $offsetval = " OFFSET " . $offset . "";
            $limit=" limit ".$offset;
        }
    }  
    
    
}
}


if($pincode!=""){
    $current=$db1->sql("select * from postal where pincode='$pincode'")->one();
    $currentlat=$current['latitude'];
    $currentlon=$current['longitude'];

   $near = $db1->sql("SELECT b.id as pro_id,b.product_code as product_code, a.city, a.pincode, b.product_title, b.area, b.city, b.address, b.latitude, b.logitute,b.pro_view,b.del,b.category, (6371000 * acos( cos(radians('$currentlat')) * 
cos(radians(a.latitude)) * cos(radians(a.longitude) - radians('$currentlon')) + sin(radians('$currentlat')) * 
sin(radians(a.latitude)) )) AS distance FROM postal AS a INNER JOIN add_property AS b ON a.pincode = b.postal_code  group by b.id HAVING distance < 10000 ORDER BY distance DESC, a.id DESC")->many();



$near_ids = array_column($near, 'pro_id'); // Extracting the 'id' column from $near array
$in_condition = implode(',', $near_ids); // Creating comma-separated string of IDs

if (!empty($in_condition)) {
    $ss .= " AND id IN ($in_condition)";
}else{
    $ss.="";
}

}



 function formatIndianNumber($number) {
                if ($number >= 10000000) {
                    return number_format(($number / 10000000), 2, '.', '') . ' Crore';
                } elseif ($number >= 100000) {
                    return number_format(($number / 100000), 2, '.', '') . ' Lac';
                } elseif ($number >= 1000) {
                    return number_format(($number / 1000), 2, '.', '') . ' K';
                } else {
                    return $number;
                }
            }
            
            
            
      $recent=$db1->sql("select id,date,product_code, category,product_size, sub_cat,size_type, pro_type, propriter_name, listing_for, product_title,price_in_number, price_in_alphabet, area, city,(SELECT name FROM truebroker_new_1.sm_main_form_11 WHERE del IS NULL AND list_id = 193 AND value = add_property.listing_for LIMIT 1) AS list,(select category from sm_main_form_1000 where id=add_property.category limit 1) as cat,(select sub_category from sm_main_form_1001 where id=add_property.sub_cat limit 1) as sub,(select pro_type from sm_main_form_1002 where id=add_property.pro_type limit 1) as protype,(select img_3 from sm_main_form_1009 where pro_id=add_property.id and img_3 !='' limit 1) as img,(select count(id) from sm_main_form_1017 where pro_id=add_property.id) as count,(select GROUP_CONCAT(ques_id) from add_property_1 where del is null and mid=add_property.id and ans != '' limit 1) as ques_id from add_property where del is null and category=1 and pro_view=1 and del is null $ss $sslike $sear   order by id desc $limit  ")->many();
   $bus1= $db1->  sql("select count(id) as count1 from add_property where del is null and pro_view=1 $ss")->one(); 
   
   foreach ($recent as &$item) {
    
     if($item['product_size']!=""){
                                     $pro_size_type = $db->sql("SELECT name FROM sm_main_form_11 WHERE value= '".$item["size_type"]."'  and list_id=216 and del IS NULL")->one();                    
                                                      if(preg_match('/[a-zA-Z]/', $item['product_size'])){
                                                        $prod=$item['product_size'];
                                                      }else{
                                                        $prod=$item['product_size'] . " " . $pro_size_type['name']; 
                                                      }
                                                  }else{
                                                      $prod="Size unspecified"; 
                                                  }
    $item['price_in_alphabet'] = formatIndianNumber($item['price_in_number']);
    $item['final_size'] = $prod;
}
   
   
   
   echo json_encode($recent);
// } 