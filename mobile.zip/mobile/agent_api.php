<?php 
ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);

$type = $_POST['type'];
$data=$_POST;


function n_formart($num){
	return number_format(round($num,2),2);
	}
function nn_formart($num){
	return number_format(round($num,3),3);
	}

if($type==31){
    
    
     /*start request save*/ 
     $url="agent_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url ."/".$data['agent'] ;
    

    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
      
      $resm = array();
      $member=$db1->from('sm_main_form_1417')
     ->where('del #',null)
     ->where('agent',$data['agent'])
     ->select(array('count(name) as member'))
     ->one();
    //  echo $member;
     
      $res['title']="member";
      $res['value']= $member['member'];
      $res = array_push($resm,$res);
      $res = array();
//    echo json_encode(array($res));


$ex="10 days";
// echo $ex;
$date = date('Y-m-d', strtotime("-$ex"));
$cd=date('Y-m-d');
            
$totalcollection=$db1->sql("select sum(amount) as totalcollection from sm_main_form_1419 where agent='".$data['agent']."'  and `date` BETWEEN '".$date."' and '".$cd."' and del is null  ")->one();
// echo $totalcollection;
   

      $res['title']="totalcollection";
      $res['value']=n_formart($totalcollection['totalcollection']);
      $res = array_push($resm,$res);
      $res = array();

  echo json_encode($resm);
}



//agent chit
if($type==15){
    
    
     /*start request save*/
     
     $url="agent_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
        $cond='';
        $grp ='';
       
        if(!empty($data['agent'])){
           $cond .=" and a.agent='".$data['agent']."' ";
           }
            
        if(!empty($data['date'])){
           $cond .= " AND a.date between '".date('Y-m-d',strtotime($data['sdate']))."' and '".date('Y-m-d',strtotime($data['edate']))."' ";
           // $cond .= " AND a.date<='".date('Y-m-d',strtotime($data['date']))."' ";
           }
    
        $grp .= " GROUP BY a.agent,a.p_type,a.pay_acc ";
            
            
        //   $qry = $db1->sql("SELECT sum(amount) as amount,agent FROM sm_main_form_1419 WHERE del is null $cond $grp")->many();
        
        
        $qry = $db1->sql("SELECT sum(a.amount) as amount,b.name as agent,a.p_type as p_type,a.date as date,a.pay_acc as pay_acc 
            FROM sm_main_form_1419 a
            INNER JOIN sm_main_form_1401 b
            ON a.agent=b.id
            WHERE a.del is null $cond $grp")->many();
            // print_r($qry);
            // echo $qry;
            
       foreach($qry as &$val){
        $val['date']=date('d-m-Y',strtotime($val['date']));
    
     $payacc =  $db1->from('sm_main_form_1401')->where('del #',null)->where('id',$val['pay_acc'])->one();
     $val['pay_acc'] = $payacc['name'];
      $p_type = $db1->from('sm_main_form_1408')->where('del #',null)->where('id',$val['p_type'])->select('name')->one();
      if(empty($val['p_type'])  ){
           $val['p_type']=0;
      }
      else{
     $val['p_type']=$p_type['name'];
      }
    
}
            
             echo json_encode($qry);
            
}


//commision (agent report)
if($type==16){
    
    
     /*start request save*/ 
     $url="agent_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url." - ".$data['agent']  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
      
    // $commission=$db1->from('sm_main_form_1419')->where('del #',null)->select(array('grp_name','balance','agent','name','chit_id','mobile','amount',''))->many();
    // print_r($_POST);
    
    $response = array();
    
    $data6 = array('SNO','DATE','AGENT','NAME','MOBILE','CHIT_ID','GROUP','CHIT_VALUE','COMMISSION');

    
    
    $cond ="";
    if(!empty($data['agent'])){
    $cond .= " AND a.agent='".$data['agent']."' ";
    }
    if(!empty($data['date'])){
    $cond .= " AND a.date <='".date('Y-m-d',strtotime($data['date']))."' ";
    }
    $commission = $db1->sql("SELECT b.name as agent,a.date as date,a.name as name,a.led_id as led_id,a.mobile as mobile,a.chit_id as chit_no,a.grp_name as grp_name,a.grp_no as grp_no 
                            FROM sm_main_form_1419 a 
                            INNER JOIN sm_main_form_1401 b
                            ON a.agent=b.id 
                            WHERE a.del IS NULL $cond and a.grp_no is not null or a.grp_no!=0 LIMIT 10 ")->many();
    // echo $commission;
    $i=1;
    foreach($commission as &$val){
        
        if(empty($val['grp_no'])){$val['grp_no']='0';}
        if(empty($val['grp_name'])){$val['grp_name']="0";}
        if(empty($val['name'])){$val['name']="0";}
         $ch_value = $db1->from('sm_main_form_1417')->where('del #',null)->where('name',$val['led_id'])->where('grp_no',$val['grp_no'])->select('ch_value')->one();
         $val['ch_value'] = $ch_value['ch_value'];
         if(empty($val['ch_value'])){$val['ch_value']='0';}
        //  echo $ch_value;
        
        $comsn = $db1->from('sm_main_form_1416')->where('del #',null)->where('id',$val['grp_no'])->select('comsn')->one();
        
        $val['commission'] = $comsn['comsn'];
         if(empty($val['commission'])){$val['commission']='0';}
         
        $name=$db1->from('sm_main_form_1401')
                    ->where('del #',null)
                    ->where('id',$val['name'])
                    ->select('name')->one();
        $val['name'] = $val['name'];     
        $val['date'] = date('d-m-Y',strtotime($val['date']));
        
        
        $data4[]= array('SNO'=>"$i",'DATE'=>$val['date'],'AGENT'=>$val['agent'],'NAME'=>$val['name'],'MOBILE'=>$val['mobile'],'CHIT_ID'=>$val['chit_no'],'GROUP'=>$val['grp_name'],'CHIT_VALUE'=>$val['ch_value'],'COMMISSION'=>$val['commission']."%");
        $tcom +=$val['commission'];
$i++;
                    
    }
     $data4[]=array('SNO'=>"",'DATE'=>"",'AGENT'=>"",'NAME'=>"",'MOBILE'=>"",'CHIT_ID'=>"",'GROUP'=>"",'CHIT_VALUE'=>"TOTAL",'COMMISSION'=>"$tcom");
    
    
    $response['header'] = $data6;
    $response['cont'] = $data4;
      echo json_encode($response);

    // echo json_encode($commission);
}

//chitgrop wise
// if($type==20){
//     // echo json_encode($_POST);
// $chitgrp= $db1->from('sm_main_form_1417')->where('del #', null)->where('cid',$data['cid'])->where('grp',$data['group'])->select(array('gname','id','name','col_amount','div_amount','temp_id','agent','mobile','address'))->many();
// // echo $chitgroup;
// foreach($chitgrp as &$val){
    
//      $name =  $db1->from('sm_main_form_1401')->where('del #',null)->where('id',$val['name'])->select(array('name','address','mobile'))->one();
//      $val['name'] = $name['name'];
     
//      if(empty($val['mobile'])){
//           $val['mobile']=$name['mobile'];
//      }
   
//   if(empty($val['address'])){
       
//       $val['address']=$name['address'];
//   }
    
//   if(empty($val['gname'])) {
//       $val['gname']="0";
//       }
      
//         $agent =  $db1->from('sm_main_form_1401')->where('del #',null)->where('id',$val['agent'])->one();
//      $val['agent'] = $agent['name'];
    
// }

// echo json_encode($chitgrp);
// }


/* Chit Group wise report for agent */
if($type==20){
     
     $cds=date('Y-m-d');
     /*start request save*/ 
     $url="agent_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t." - ".$url ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
      
    extract($_POST);
    
    $response = array();
    
    $data6 = array('SNO','GROUP_NAME','CHIT_ID','NAME','COLL','DIVID','TEMP_ID','AGENT','MOBILE','ADDRESS');
    
    $chitgroup=$data['group'];
     
     /*  */ 
    $chitgrp= $db1->from('sm_main_form_1417')
                  ->where('del #', null)
                  ->where('cid',$data['cid'])
                  ->where('grp',$chitgroup)
                   ->sortAsc('t_no')
                  ->select(array('gname','id','name','col_amount','div_amount','temp_id','agent','mobile','address','t_no'))
                 
                  ->many();
   
    //  echo $chitgrp;
     
    
           $i=1;
             foreach($chitgrp as &$sa){
                $date = date('d-m-Y',strtotime($sa['date']));
                
                  $col = $db1->sql("select sum(amount) as ctotal  from sm_main_form_140 where led_id='".$sa['name']."' and chit_id='".$sa['id']."' and trans_type not in (12,13,14,15,16,17,18,23) and date <= '".$cds."' and del is null and status IS NULL")->one();
    $sa['col_amount']=abs($col['ctotal']);
     $div = $db1->sql("select sum(amount) as div_amount from sm_main_form_140  where chit_id='".$sa['id']."' and trans_type='15' and date <= '".$cds."' and status IS NULL and del is null")->one();
   $sa['div_amount']=abs($div['div_amount']);
                $name =  $db1->from('sm_main_form_1401')->where('del #',null)->where('id',$sa['name'])->select(array('name','address','mobile'))->one();
                $sa['name'] = $name['name'];
                     
                if(empty($sa['mobile'])){
                $sa['mobile']=$name['mobile'];
                }
                   
                if(empty($sa['address'])){
                       
                $sa['address']=$name['address'];
                }
                    
                if(empty($sa['gname'])) {
                $sa['gname']="0";
                }
                      
                $agent =  $db1->from('sm_main_form_1401')->where('del #',null)->where('id',$sa['agent'])->one();
                $sa['agent'] = $agent['name'];
    
                $data4[]=array('SNO'=>$i,'GROUP_NAME'=>$sa['gname']." / ".$sa['t_no'],'CHIT_ID'=>$sa['id'],'NAME'=>$sa['name'],'COLL'=>$sa['col_amount'],'DIVID'=>$sa['div_amount'],'TEMP_ID'=>$sa['temp_id'],'AGENT'=>$sa['agent'],'MOBILE'=>$sa['mobile'],'ADDRESS'=>$sa['address']);
                
                    // $rcount += $sa['receipt'];
                    // $tcount += $sa['amount'];
            $i++;
                    }

    // $data4[]=array('SNO','GROUP_NAME','CHIT_ID','NAME','COLL','DIVID','TEMP_ID','AGENT','MOBILE','ADDRESS');
 
    
    $response['header'] = $data6;
    $response['cont'] = $data4;

  echo json_encode($response);

}

if($type==1){
    
    $name=$data['name'];
    $auto=$db1->sql("select sub_name as label,name as led_id,id as chitid,sub_name,gname from sm_main_form_1417 where del is null and agent='".$data['agent']."' and cid=$cid and (sub_name like '%".$name."%' or id like '%".$name."%')")->many();
    foreach($auto as &$d ){
        $d['label']=$d['sub_name']." - ".$d['chitid'];
    }
    
    echo json_encode($auto);
    
}


if($type==13){
    
      
      
    //   $response=array();
      $ag=$db->sql("select del from sm_main_form_20 where  led_id='".$data['agent']."' and cid='".$data['cid']."' ")->one();
      
      if($ag==true){
          if($ag['del'] != null){
           
            $response['error']=true;
          $response['error_msg']="In Active";
      }else{
           $response['error']= false;
          $response['error_msg']="Active";
      } 
      }
     
      echo json_encode($response);
      
      
      /*start request save*/ 
     $url="agent_api.php";
     $r_t='AgentActivestatus';
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." CID : " . $data['cid'] ." TYPE  : " . $data['type']." MENU : " . $r_t." URL  :  ".$url."  AGENT ID  : ".$data['agent']."  Active Status  : ". $response['error_msg'] ." ]"  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
}

if($type==14){
    
      
      
    //   $response=array();
      $ag=$db1->sql("select route,route as route_id from sm_main_form_1411 where  agent='".$data['agent']."' and cid='".$data['cid']."' ")->one();
      
    $route=$db1->sql("select id,name from sm_main_form_1410 where del is null and id='".$ag['route']."'  ")->one();
    $ag['route']=$route['name'];
     
      echo json_encode(array($ag));
      
      
      /*start request save*/ 
     $url="agent_api.php";
     $r_t='Route';
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." CID : " . $data['cid'] ." TYPE  : " . $data['type']." MENU : " . $r_t." URL  :  ".$url."  AGENT ID  : ".$data['agent']." ROUTE  : ".$ag['route']." / ".$ag['route_id']." ] "  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
}      
if($type==18){
    
      
      
    //   $response=array();
      $ag=$db1->sql("select name,id as agentid from sm_main_form_1401 where  id='".$data['led_id']."' and cid='".$data['cid']."' ")->one();
      
     
      echo json_encode(array($ag));
      
      
      /*start request save*/ 
     $url="agent_api.php";
     $r_t='Agent Name';
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." CID : " . $data['cid'] ." TYPE  : " . $data['type']." MENU : " . $r_t." URL  :  ".$url."  AGENT ID  : ".$data['led_id']." Name  : ".$ag['name']." / ".$ag['agentid']." ] "  ;
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
      /* end request save*/
} 
?>