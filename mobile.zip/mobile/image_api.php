<?php
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$cid=11223344;
$db = new Dbclass();
$db1 = new Dbclass($cid);



$banner = $db1->sql("SELECT * FROM sm_main_form_101")->many();
foreach($banner as $res)
{
    echo $res['banner_img'].",";
}








?>