<?php
$cid = $_POST['cid'];
require_once("../index.php");
require_once(BASEPATH . 'config/autoloader.php');
require_once(BASEPATH . 'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
// ini_set("display_errors",1);
extract($_REQUEST);
$cid = 13051305;
extract($_REQUEST);

$db1->sql("SET NAMES utf8")->execute();
$db->sql("SET NAMES utf8")->execute();



$serverKey = 'AAAAQgizI8U:APA91bGFM8wmdRUWzPNJM0ITocgdIKeWD_gzxZaDOoUNCmwt7EFgS4RAg96WAubTVq4cuEaGcTEjEz-EIGtzznuhBA-F1ZjYhcEsKDMU9QwmyyCZzb86I_H9Z5O_ViyVv-tn-VH-FU0f
';

$deviceToken = 'RECIPIENT_DEVICE_TOKEN';

$data = [
    'title' => 'Notification Title',
    'body' => 'Notification Body',
];

$message = [
    'to' => $deviceToken,
    'data' => $data,
];

$headers = [
    'Authorization: key=' . $serverKey,
    'Content-Type: application/json',
];

$ch = curl_init('https://fcm.googleapis.com/fcm/send');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($message));

$response = curl_exec($ch);
curl_close($ch);

// Handle the response (e.g., check for success or errors)


?>