<?
ini_set("display_errors",0);
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
extract($_REQUEST);
$db = new Dbclass();
$db1 = new Dbclass($cid);

$db->sql("SET NAMES utf8")->execute();
$db1->sql("SET NAMES utf8")->execute();

if($type==25){
    
    $lan_field=$db1->sql("select * from sm_main_form_1041 where del is null and id=$lan_id")->one();
    $field=  $lan_field['field_name'];
    
    $field_val=$db1->sql("select $field as field from sm_main_form_1040 where del is null and list_id=$field_id")->one();
    
    echo json_encode($field_val);
}
?>
