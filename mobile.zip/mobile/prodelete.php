 <?php
/*SAVE QUERY*/
ini_set("display_errors",1);
$cid=21472147;

require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// require_once('../../app/sys/config/dbconfig2.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user =new USER();
$type = $_POST['type'];
$data=($_POST);         

     
     extract($_POST);
    //  print_r($_POST);
 if ($type==1) {    
    $id= $data['id'];
    $data1 = array('del'=>'1');
  $result=$db1->from('sm_main_form_102')->where('id',$id)->update($data1) ->execute();
   $data2 = array('del'=>'1');
  $result=$db1->from('sm_main_form_103')->where('pro_id',$id)->update($data2) ->execute();
}
 ?>