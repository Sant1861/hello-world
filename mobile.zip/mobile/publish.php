<?php 


// ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
$response=array();
// print_r($_POST);
if($_POST['sub_type']==1){
    // echo "hiiiiiiiiiiiiiiiiii";
    extract($_POST);
    
    $select=$db1->sql("select * from add_property where del is null and uid=$uid and paid=1")->many();
    
    foreach($select as $sel){
       $img=$db1->sql("select img_1 from sm_main_form_1009 where pro_id='".$sel['id']."' and del is null")->one();
        
        
        // $response["pro_details"] = $sel;
         $response["img"] = $img;
         
         $response["id"]= $sel["id"];
      
        $response["uid"]= $sel["uid"];
        
        $response["cid"]=$sel["cid"];
        $response["category"]= $sel["category"];
        $response["sub_cat"]=$sel["sub_cat"];
        $response["pro_type"]=$sel["pro_type"];
        $response["client_name"]=$sel["client_name"];
        $response["client_whatsapp"]= $sel["client_whatsapp"];
        $response["client_mobile"]=$sel["client_mobile"];
        $response["client_address"]=$sel["client_address"];
        $response["listing_for"]=$sel["listing_for"];
        $response["product_title"]=$sel["product_title"];
        $response["product_code"]=$sel["product_code"];
        $response["size_type"]=$sel["size_type"];
        $response["product_size"]= $sel["product_size"];
        $response["price_in_number"]=$sel["price_in_number"];
        $response["price_in_alphabet"]=$sel["price_in_alphabet"];
        $response["address"]= $sel["address"];
        $response["post_id"]=$sel["post_id"];
        $response["postal_code"]= $sel["postal_code"];
        $response["area"]=$sel["area"];
        $response["city"]=$sel["city"];
        $response["type_of_customer"]=$sel["type_of_customer"];
        $response["latitude"]=$sel["latitude"];
        $response["logitute"]=$sel["logitute"];
        $response["description"]=$sel["description"];
        // $response["img"]=$sel["description"];
  
    }
    
   echo json_encode($response);  
}
    
if($_POST['sub_type']==2){
    //   print_r($_POST);
       extract($_POST);
     $currentDate = date('Y-m-d'); // Get the current date

$startDate = date('Y-m-01', strtotime($currentDate)); // Get the start date of the current month
$endDate = date('Y-m-t', strtotime($currentDate)); // Get the end date of the current month
    
    $id=$pro_id;
 $val = $db->sql("SELECT sum(coin) as bal FROM sm_main_form_20_1 WHERE user_id=$uid and del IS NULL")->one();
    $lis=$db1->sql("select count(id) as countuid from add_property where uid=$uid and paid is null")->one();
//   echo $lis['countuid'];
if($lis['countuid']>2){
   $listing=$db1->sql("select * from add_property where del is null and paid=1 and id='".$id."' ")->one();
   

    $coin=$listing['listing_for'];
   
    
    
    if($coin=='1'){
        
         $sel=$db1->sql("select * from sm_main_form_1012 where reward_type=4 and del is null")->one();
        // print_r($sel);
      $coinss= $sel['coins'];
        
    if($val['bal'] >= $coinss){
        
        $upp=array('paid'=>NULL); //status 1 - > Conform
        $followup = $db1->from('add_property')->where('del #',null)->where('id',$id)->update($upp)->execute();
        $upp1=array('date'=>date("Y-m-d"),'user_id'=>$uid,'coin'=>-$coinss,'description'=>'Debited for Publish Listing','pro_id'=>$id); //status 1 - > Conform
        $followup = $db->from('sm_main_form_20_1')->insert($upp1)->execute();
        // $upp1=array('date'=>date("Y-m-d"),'user_id'=>$uid,'coin'=>-$coinss,'description'=>'Debited for Publish Listing','pro_id'=>$id); //status 1 - > Conform
        // $followup = $db->from('sm_main_form_20_1')->insert($upp1)->execute();
        // $ref12=$db->sql("select * from sm_main_form_20 where id=$uid")->one();
        
      	$sel = $db1->sql("select * from add_property where id=$id")->one();
	if ($sel['category'] == 1) {
		$name = $sel['client_name'];
		$phone = $sel['client_whatsapp'];
	} elseif ($sel['category'] == 2) {

		$name = $sel['customer_name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 3) {

		$name = $sel['name'];
		$phone = $sel['contact_no'];
	} elseif ($sel['category'] == 4) {

		$name = $sel['name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 5) {

		$name = $sel['company_name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 7) {

		$name = $sel['seller_name'];
		$phone = $sel['mobile_number'];
	} else {
		$uid = $sel['uid'];
		$sel = $db->sql("select * from sm_main_form_20 where id=$uid")->one();
		$name = $sel['f_name'];
		$phone = $sel['mobile'];
	}
	$code = $sel['product_code'];
	$yearr = 2023;

	$sms = "Dear," . " " . $name . " Thankyou For Published Your Listing., Our Team Verified And Approved It soon., Thanking You.,";
	$wsms = array('cid' => $cid, 'mobile' => $phone, 'message' => $sms);
	$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();

$scall=$db1->sql("select * from sm_main_form_1024 where del is null")->many();

	foreach ($scall as $call) {

// 		$numw = $call['w_num'];


		$sms1 = "Dear team one property publish it now  the pro_code is," . " " . $code. " and url is  https://truebroker.in/listing_detail?id=$code please check and approval it";

		$wsms = array('cid' => $cid, 'mobile' => $call['mobile'], 'message' => $sms1);
		$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();
	}

  
        
        
        
        
        
        
        
        $val['error']=FALSE;
        $val['error_msg']="Allowed To Property Upload";
       
    }else{
      $val['error']=TRUE;
      $val['error_msg']="Coin Balance is low Please Recharge"; 
    } 
    
    }
    
    
    if($coin=='2'){
        
      $sel=$db1->sql("select * from sm_main_form_1012 where reward_type=5 and del is null")->one();
      $coinss= $sel['coins'];
      if($val['bal'] >=$coinss){ 
        
        
        if($val['bal'] >='2000'){
            
        $upp=array('paid'=>NULL); //status 1 - > Conform
        $followup = $db1->from('add_property')->where('del #',null)->where('id',$id)->update($upp)->execute();
        $upp1=array('date'=>date("Y-m-d"),'user_id'=>$uid,'coin'=>-$coinss,'description'=>'Debited for Publish Listing','pro_id'=>$id); //status 1 - > Conform
        $followup = $db->from('sm_main_form_20_1')->insert($upp1)->execute();
        
        $sel = $db1->sql("select * from add_property where id=$id")->one();
	if ($sel['category'] == 1) {
		$name = $sel['client_name'];
		$phone = $sel['client_whatsapp'];
	} elseif ($sel['category'] == 2) {

		$name = $sel['customer_name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 3) {

		$name = $sel['name'];
		$phone = $sel['contact_no'];
	} elseif ($sel['category'] == 4) {

		$name = $sel['name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 5) {

		$name = $sel['company_name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 7) {

		$name = $sel['seller_name'];
		$phone = $sel['mobile_number'];
	} else {
		$uid = $sel['uid'];
		$sel = $db->sql("select * from sm_main_form_20 where id=$uid")->one();
		$name = $sel['f_name'];
		$phone = $sel['mobile'];
	}
	$code = $sel['product_code'];
	$yearr = 2023;

	$sms = "Dear," . " " . $name . " Thankyou For Published Your Listing., Our Team Verified And Approved It soon., Thanking You.,";
	$wsms = array('cid' => $cid, 'mobile' => $phone, 'message' => $sms);
	$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();

$scall=$db1->sql("select * from sm_main_form_1024 where del is null")->many();

	foreach ($scall as $call) {

// 		$numw = $call['w_num'];


		$sms1 = "Dear team one property publish it now  the pro_code is," . " " . $code. " and url is  https://truebroker.in/listing_detail?id=$code please check and approval it";

		$wsms = array('cid' => $cid, 'mobile' => $call['mobile'], 'message' => $sms1);
		$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();
	}

        
        
        $val['error']=FALSE;
        $val['error_msg']="Allowed To Property Upload";
    }else{
        $val['error']=TRUE;
        $val['error_msg']="Coin Balance is low Please Recharge"; 
    } 
    
    }
    
    }
    
    if($coin=='3'){
        
        $sel=$db1->sql("select * from sm_main_form_1012 where reward_type=6 and del is null")->one();
        $coinss= $sel['coins'];
        if( $val['bal'] >=$coinss){  
            
        $upp=array('paid'=>NULL); //status 1 - > Conform
        $followup = $db1->from('add_property')->where('del #',null)->where('id',$id)->update($upp)->execute();
        $upp1=array('date'=>date("Y-m-d"),'user_id'=>$uid,'coin'=>-$coinss,'description'=>'Debited for Publish Listing','pro_id'=>$id); //status 1 - > Conform
        $followup = $db->from('sm_main_form_20_1')->insert($upp1)->execute();
        
        $sel = $db1->sql("select * from add_property where id=$id")->one();
	if ($sel['category'] == 1) {
		$name = $sel['client_name'];
		$phone = $sel['client_whatsapp'];
	} elseif ($sel['category'] == 2) {

		$name = $sel['customer_name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 3) {

		$name = $sel['name'];
		$phone = $sel['contact_no'];
	} elseif ($sel['category'] == 4) {

		$name = $sel['name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 5) {

		$name = $sel['company_name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 7) {

		$name = $sel['seller_name'];
		$phone = $sel['mobile_number'];
	} else {
		$uid = $sel['uid'];
		$sel = $db->sql("select * from sm_main_form_20 where id=$uid")->one();
		$name = $sel['f_name'];
		$phone = $sel['mobile'];
	}
	$code = $sel['product_code'];
	$yearr = 2023;

	$sms = "Dear," . " " . $name . " Thankyou For Published Your Listing., Our Team Verified And Approved It soon., Thanking You.,";
	$wsms = array('cid' => $cid, 'mobile' => $phone, 'message' => $sms);
	$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();

$scall=$db1->sql("select * from sm_main_form_1024 where del is null")->many();

	foreach ($scall as $call) {

// 		$numw = $call['w_num'];


		$sms1 = "Dear team one property publish it now  the pro_code is," . " " . $code. " and url is  https://truebroker.in/listing_detail?id=$code please check and approval it";

		$wsms = array('cid' => $cid, 'mobile' => $call['mobile'], 'message' => $sms1);
		$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();
	}

        
        
        $val['error']=FALSE;
        $val['error_msg']="Allowed To Property Upload";
    }else{
        $val['error']=TRUE;
        $val['error_msg']="Coin Balance is low Please Recharge"; 
    } 
    }
    
    if($coin=='4'){
    
        $upp=array('paid'=>NULL); //status 1 - > Conform
        $followup = $db1->from('add_property')->where('del #',null)->where('id',$id)->update($upp)->execute();
        // $upp1=array('date'=>date("Y-m-d"),'user_id'=>$uid,'description'=>'Credited for Listing','pro_id'=>$id); //status 1 - > Conform
        // $followup = $db->from('sm_main_form_20_1')->insert($upp1)->execute();
        $val['error']=FALSE;
        $val['error_msg']="Allowed To Property Upload";
    
    }
    
    if($coin==''){
         $sel=$db1->sql("select * from sm_main_form_1012 where reward_type=8 and del is null")->one();
        $coinss= $sel['coins'];
        if( $val['bal'] >=$coinss){  
            
        $upp=array('paid'=>NULL); //status 1 - > Conform
        $followup = $db1->from('add_property')->where('del #',null)->where('id',$id)->update($upp)->execute();
        $upp1=array('date'=>date("Y-m-d"),'user_id'=>$uid,'coin'=>-$coinss,'description'=>'Debited for Publish Listing','pro_id'=>$id); //status 1 - > Conform
        $followup = $db->from('sm_main_form_20_1')->insert($upp1)->execute();
        
        
        $sel = $db1->sql("select * from add_property where id=$id")->one();
	if ($sel['category'] == 1) {
		$name = $sel['client_name'];
		$phone = $sel['client_whatsapp'];
	} elseif ($sel['category'] == 2) {

		$name = $sel['customer_name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 3) {

		$name = $sel['name'];
		$phone = $sel['contact_no'];
	} elseif ($sel['category'] == 4) {

		$name = $sel['name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 5) {

		$name = $sel['company_name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 7) {

		$name = $sel['seller_name'];
		$phone = $sel['mobile_number'];
	} else {
		$uid = $sel['uid'];
		$sel = $db->sql("select * from sm_main_form_20 where id=$uid")->one();
		$name = $sel['f_name'];
		$phone = $sel['mobile'];
	}
	$code = $sel['product_code'];
	$yearr = 2023;

	$sms = "Dear," . " " . $name . " Thankyou For Published Your Listing., Our Team Verified And Approved It soon., Thanking You.,";
	$wsms = array('cid' => $cid, 'mobile' => $phone, 'message' => $sms);
	$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();

$scall=$db1->sql("select * from sm_main_form_1024 where del is null")->many();

	foreach ($scall as $call) {

// 		$numw = $call['w_num'];


		$sms1 = "Dear team one property publish it now  the pro_code is," . " " . $code. " and url is  https://truebroker.in/listing_detail?id=$code please check and approval it";

		$wsms = array('cid' => $cid, 'mobile' => $call['mobile'], 'message' => $sms1);
		$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();
	}

        
        
        $val['error']=FALSE;
        $val['error_msg']="Allowed To Property Upload";
    }else{
        $val['error']=TRUE;
        $val['error_msg']="Coin Balance is low Please Recharge"; 
    } 
    }
    
    echo json_encode($val);
}


else{
      $sel=$db1->sql("select * from sm_main_form_1012 where reward_type=11 and del is null")->one();
    $coinss= $sel['coins'];
        if($val['bal'] >= $coinss){
           $upp=array('paid'=>NULL); //status 1 - > Conform
        $followup = $db1->from('add_property')->where('del #',null)->where('id',$id)->update($upp)->execute();
        $upp1=array('date'=>date("Y-m-d"),'user_id'=>$uid,'coin'=>-$coinss,'description'=>'Debited for Publish Listing','pro_id'=>$id); //status 1 - > Conform
        $followup = $db->from('sm_main_form_20_1')->insert($upp1)->execute();
        // $upp1=array('date'=>date("Y-m-d"),'user_id'=>$uid,'coin'=>-$coinss,'description'=>'Debited for Publish Listing','pro_id'=>$id); //status 1 - > Conform
        // $followup = $db->from('sm_main_form_20_1')->insert($upp1)->execute();
        // $ref12=$db->sql("select * from sm_main_form_20 where id=$uid")->one();
        
      	$sel = $db1->sql("select * from add_property where id=$id")->one();
	if ($sel['category'] == 1) {
		$name = $sel['client_name'];
		$phone = $sel['client_whatsapp'];
	} elseif ($sel['category'] == 2) {

		$name = $sel['customer_name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 3) {

		$name = $sel['name'];
		$phone = $sel['contact_no'];
	} elseif ($sel['category'] == 4) {

		$name = $sel['name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 5) {

		$name = $sel['company_name'];
		$phone = $sel['contact_number'];
	} elseif ($sel['category'] == 7) {

		$name = $sel['seller_name'];
		$phone = $sel['mobile_number'];
	} else {
		$uid = $sel['uid'];
		$sel = $db->sql("select * from sm_main_form_20 where id=$uid")->one();
		$name = $sel['f_name'];
		$phone = $sel['mobile'];
	}
	$code = $sel['product_code'];
	$yearr = 2023;

	$sms = "Dear," . " " . $name . " Thankyou For Published Your Listing., Our Team Verified And Approved It soon., Thanking You.,";
	$wsms = array('cid' => $cid, 'mobile' => $phone, 'message' => $sms);
	$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();

$scall=$db1->sql("select * from sm_main_form_1024 where del is null")->many();

	foreach ($scall as $call) {

// 		$numw = $call['w_num'];


		$sms1 = "Dear team one property publish it now  the pro_code is," . " " . $code. " and url is  https://truebroker.in/listing_detail?id=$code please check and approval it";

		$wsms = array('cid' => $cid, 'mobile' => $call['mobile'], 'message' => $sms1);
		$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();
	}

  
        
        
        
        
        
        
        
        $val['error']=FALSE;
        $val['error_msg']="Allowed To Property Upload";
       
    }else{
      $val['error']=TRUE;
      $val['error_msg']="Coin Balance is low Please Recharge"; 
    } 
  
    echo json_encode($val);         
        
}

}     
    ?>

       