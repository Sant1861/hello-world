<?php 

ini_set("display_errors",0);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
require_once('form_fields_lw.php');



$db= new Dbclass();

$db1=new Dbclass($cid);

$f_field = new FORM_FIELD();


extract($_REQUEST);


$lwm_sub = $db1->sql("SELECT * FROM sm_main_form_1003  WHERE del Is NULL AND category='".$cat_id."' and main=1")->many();


      
        $response = array();
        $data1 = array();
        
foreach($lwm_sub as &$sub){







if($sub['ans_type'] != 5){
        
       
          $data1[]= $f_field->fields($cid,$sub['id'],$sub['que_name'],$sub['name'],$sub['ans_type'],$sub['values_from']);   
         $count=count($data1);
         for($i=0;$i<$count;$i++){
             
             $col=$data1[$i]['field_name'];
             
             $selecteddata=$db1->sql("select $col from add_property where id='$id'")->one();
             
          $data1[$i]['old']=$selecteddata[$col];
         }
        
}
       
 
}


       
      $response['data'] = $data1;
    //   $response1['data'] = "fd";
     
        $res[]=$response;
     
     echo json_encode($res);   

?>