<?php

$cid = $_POST['cid'];
// $cid = '23012301';
// ini_set('display_errors', 1);
// require_once('../basepath.php');
// require_once(BASEPATH.'config/autoloader.php');
// require_once('../index.php');
// date_default_timezone_set("Asia/Kolkata");


ini_set("display_errors",1);

$cid=$_POST['cid'];

require_once("../index.php");
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
require_once(BASEPATH.'../../class/USER.class.php');

// print_r($_POST);
$db = new Dbclass();
$db1 = new Dbclass($cid);
$user = new USER();


$data = $_POST;
// -------------------------------- Templete ---------------------------
//   $query = $db1->from()->where('del #',null)->where('',$data['name'])->-select(array())>many();


if(!empty($data['fid']) && $data['type']  == 1){
// print_r($data);
    
 $form = 'sm_main_form_'.$data['fid'];

    $id = $data['id'];
    $value = $data['data'];
    $name = $data['name'];
    $where ="and `$name` like '%$value%' ";
   
 
   
  if($data['type'] == 1 and $data['fid']  > 50){
        //   $query = $db1->from($form)->where('del #',null) ->where('name %', '%'.$data['name'].'%')->select(array('name as label','id as value'))->many();
          $query = $db1->sql("SELECT *,$name as label,$id as value FROM $form WHERE del is null $where")->many();
                    
                }
                else{
                     $query = $db->sql("SELECT $name as label,$id as value FROM $form WHERE del is null $where")->many();
                }



    
    
    echo json_encode($query);

}



if(!empty($data['fid']) && $data['type']  == 2){
//   print_r($data);
    unset($data['type']);
    
 $form = 'sm_main_form_'.$data['fid'];
//  print_r($form);
    unset($data['fid']);
    $query = $db1->from($form)->where('del #',null) ->where('name %', '%'.$data['name'].'%')->select(array('name as label','id as value'))->many();
    
    echo json_encode($query);
}








?>