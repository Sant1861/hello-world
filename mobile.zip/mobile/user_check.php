<?php 


ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);

$response=array();
 if(isset($_POST['user']) && isset($_POST['password']) && isset($_POST['cid'])) {
     
     extract($_POST);
     
      $backs=$db->sql("SELECT * FROM sm_main_form_20  WHERE del IS NULL and list_id=$f4")->many();
 }
 
 ?>