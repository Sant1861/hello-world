<?php 
// print_r($_POST);
// ini_set("display_errors",1);
$cid=$_POST['cid'];
require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
// print_r($_POST);
$db = new Dbclass();
$db1 = new Dbclass($cid);

$type = $_POST['type'];


/* request save start*/ 

// $u=$_POST['user'];
// $p=$_POST['password'];
// $r_t=$data['request'];
     
 date_default_timezone_set('Asia/Kolkata');


/* request save end*/ 




$log = new LOGIN();
// print_r($_POST);
// $log = new LOGIN();
    if (isset($_POST['user']) && isset($_POST['password']) && isset($_POST['cid'])) {
print_r($_POST);

    // receiving the post params
    $email = $_POST['user']; 
    $password = $_POST['password'];
    $companyid = $_POST['cid'];
   $device_id = $_POST['device_id'];
   $lt = $_POST['lt'];
   $ln = $_POST['ln'];
   $tok = $_POST['tok'];
   $token = $_POST['token'];
    // get the user by email and password
    $user_data = $log->getMobileLogin($email, $password,$companyid,$device_id,$lt,$ln,$tok,$token);
// 	echo json_encode($user_data);

	//print_r($_GET);

 // $menudata = $menu->mobileMenu();
	
    if ($user_data["error"] == FALSE) {
		$response = $user_data;
		$response["error"]= FALSE;
		 $response["error_msg"] = "Login Successfull";
		
		
		$new=fopen("successpoint.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $_POST['cid'] ." - " . $type." - " . $r_t ." - " .$lt." - " .$ln." - " .$_POST['user']." - " .$_POST['password']."-".$response["error_msg"];
 
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
    
       
    
	
	 echo json_encode($response);
    } else {
        // user is not found with the credentials
        $response["error"] = TRUE;
        $response["error_msg"] = "Login credentials are wrong. Please try again!";
        
        $new=fopen("successpoint.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $_POST['cid'] ." - " . $type." - " . $r_t ." - " .$lt." - " .$ln." - " .$_POST['user']." - " .$_POST['password']."-".$response["error_msg"];
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
    
        echo json_encode($response);
		exit();
    }
} else {
    // required post params is missing
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters email or password is missing!";
    echo json_encode($response);
}





  ?>
  
  
  
  