<?php
$cid = $_POST['cid'];
require_once("../index.php");
require_once(BASEPATH . 'config/autoloader.php');
require_once(BASEPATH . 'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);
// ini_set("display_errors",1);
$offset = '';
$offsetval = "";
$search = "";
$word = "";
$offset = "";
$city = "";
$area = "";
$pincode = "";
$saletype = "";
$subcatlist = "";
$minprice = "";
$maxprice = "";
$led_id = "";
$newold = "";
$order = "";
$areas = "";
$citys = "";
// $list_fors="";
extract($_REQUEST);
$cid = 13051305;
extract($_REQUEST);

$db1->sql("SET NAMES utf8")->execute();
$db->sql("SET NAMES utf8")->execute();

if ($type == 8) {
// 	print_r($_REQUEST);
	if (!empty($offset)) {

		if ($offset != '') {
			$offset = $offset * 10;
			$offsetval = " OFFSET " . $offset . "";
		}
	}
	if (!empty($city)) {
		$ex = explode(" ", $city);


		foreach ($ex as $ex1) {
			$citys .= "'" . $ex1 . "',";
		}

		$citys = rtrim($citys, ',');
		$search .= " AND city in ($citys)";

		$word .= "$city";
	}
	if (!empty($area)) {
		$areaaa = $area;
		$ex = explode(" ,", $area);
		// print_r($ex);
		foreach ($ex as $ex1) {
			$areas .= "'" . $ex1 . "',";
		}

		$areas = rtrim($areas, ',');
		$search .= " AND area in ($areas)";

		$word .= "-$areaaa ";
	}
	if (!empty($pincode)) {
		$search .= " AND postal_code=$pincode ";

		$word .= "-$pincode ";
	}
	if (!empty($category)) {
		$search .= " AND category=$category ";
	}
	if (!empty($sub_cat)) {
		$search .= " AND sub_cat=$sub_cat ";
	}
	if (!empty($saletype)) {
		$search .= " AND listing_for=$saletype ";
	}
	if (!empty($subcatlist)) {
		$subcatlist = rtrim($subcatlist, ",");
		$search .= " AND pro_type in($subcatlist) ";
	}
	if (!empty($minprice)) {
		$search .= " AND (price_in_number >= $minprice) ";
	}
	if (!empty($maxprice)) {
		$search .= " AND (price_in_number <= $maxprice)  ";
	}
	if ($newold == 'new') {
		$order = " order by id desc ";
	}
	if (!empty($led_id)) {
		$search .= " AND uid=$led_id";
	}







	//   echo  $ip=$db1->sql(" SELECT `id`, `aid`, `uid`, `bid`, `cid`, `sub_cat`, `client_name`, `client_whatsapp`, `client_mobile`, 
	//                             `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, 
	//                             `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`,
	//                             `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`,
	//                             `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`,
	//                             `user_upload_by`, `paid`, `date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `del`, `is_d`, `act`, `dtime`,
	//                             (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
	//                             (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
	//                             (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
	//                             FROM add_property as a WHERE pro_view=1 and del is null and listing_for!='' and  size_type!=''   $search   order by id desc")->sql();


	$ip = $db1->sql(" CREATE OR REPLACE VIEW listing_mobile AS SELECT `id`, `aid`, `uid`, `bid`, `cid`, `sub_cat`, `client_name`, `client_whatsapp`, `client_mobile`, 
                            `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, 
                            `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`,
                            `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`,
                            `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`,
                            `user_upload_by`, `paid`, `date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `del`, `is_d`, `act`, `dtime`,
                            (SELECT img_3 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL order by id asc limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null and listing_for!='' and  size_type!=''   $search   order by id desc ")->execute();

	$skk = array();
	if ($sub_type == 1) {

		// echo $result = $db1->sql("select * from listing_mobile where del is null ")->sql();
		$result = $db1->sql("select * from listing_mobile where del is null  limit 100")->many();
		foreach ($result as $val) {
	$viewcount=$db1->sql("select count(id) as count from sm_main_form_1017 where pro_id='".$val['id']."' ")->one();
			$sk['view_count'] = $viewcount['count'];

			$sk['price_in_number'] =  $val['price_in_alphabet'];
			$sk['listing_for'] = $val['listing_for'];
			$sk['product_title'] =  $val['product_title'];
			$sk['area'] =  $val['area'];
			$sk['pro_type'] =  $val['pro_type'];
			$sk['city'] =  $val['city'];
			$sk['id'] =  $val['id'];
			$sk['client_mobile'] =  $val['client_mobile'];
			$sk['img1'] =  $val['img1'];
			$sk['pro_size'] = $val['product_size'];
			$sk['size_type'] = $val['size_type'];
			$skk[] = $sk;
		}
		echo json_encode($skk);
	}


	if ($sub_type == 2) {

		// print_r($_POST);
	$result = $db1->sql("SELECT *,
                            (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null and id='$pro_id' $search   order by id desc   ")->one();
                            
                             $led = $db->sql("select * from sm_main_form_20 WHERE del is null and id='" . $result['uid'] . "' ")->one();
                            
                            
                            // 	echo	$result = $db1->sql("SELECT `id`, `aid`, `uid`, `bid`, `cid`, `sub_cat`, `client_name`, `client_whatsapp`, `client_mobile`, 
                            // `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, 
                            // `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`,
                            // `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`,
                            // `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`,
                            // `user_upload_by`, `paid`, `date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `del`, `is_d`, `act`, `dtime`,
                            // (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            // (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            // (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            // FROM add_property as a WHERE pro_view=1 and del is null and id='$pro_id' $search   order by id desc   ")->sql();
                            
                            
                            
                            
                            
		$img = $db1->sql("SELECT img_3 as img_1  FROM sm_main_form_1009 WHERE pro_id='$pro_id' and del IS NULL and img_2 is not null ")->many();
		
		

		$datacount = $db1->sql("select * from sm_main_form_1022 where del is null and pro_id='$pro_id' and customerid=$uid")->many();
		$datacount = count($datacount);

		if ($datacount == 0) {
			$result['like'] = 0;
		} else {
			$result['like'] = 1;
		}

		$qa = $db1->sql("SELECT ans,ques,ques_id FROM add_property_1 WHERE mid=$pro_id and del IS NULL and ans IS NOT NULL")->many();
		foreach ($qa as $ans) {
			$qaw = $db1->sql("SELECT que_name FROM sm_main_form_1003 WHERE id='" . $ans['ques_id'] . "' and del IS NULL")->one();

			$qas['question'] = $qaw['que_name'];
			$qas['answer'] = $ans['ans'];
			$qans[] = $qas;
		}
		$result['qa'] = $qans;
		$result['pro_pic'] = $img;
		$result['profile'] = $led['photo'];
		$result['owner_name'] = $led['f_name'];
		
		
		
		
		
		echo json_encode($result);
		
		
		$pkk=$db1->sql("select * from add_property where id=$pro_id and del is null")->one();
		
		  $view=$db1->sql("select count(id) as ccount from sm_main_form_1025 where pro_id=$pro_id and user_id=$uid")->one();
    // print_r($view);
// echo $view['ccount']."prem";
    if($view['ccount']==0){
     $us_detail=$db->sql("select* from sm_main_form_20 where id=$uid")->one();
 
 if ($pkk['category'] == 1) {
		$name = $pkk['client_name'];
		$phone = $pkk['client_whatsapp'];
	} 
	elseif ($pkk['category'] == 2) {

		$name = $pkk['customer_name'];
		$phone = $pkk['contact_number'];
	}
	elseif ($pkk['category'] == 3) {

		$name = $pkk['name'];
		$phone = $pkk['contact_no'];
	}
	elseif ($pkk['category'] == 4) {

		$name = $pkk['name'];
		$phone = $pkk['contact_number'];
	}
	elseif ($pkk['category'] == 5) {

		$name = $pkk['company_name'];
		$phone = $pkk['contact_number'];
	}
	elseif ($pkk['category'] == 7) {

		$name = $pkk['seller_name'];
		$phone = $pkk['mobile_number'];
	} 
	else {
		$uid55 = $pkk['uid'];
		$sel1 = $db->sql("select * from sm_main_form_20 where id=$uid55")->one();
		$name = $sel1['f_name'];
		$phone = $sel1['mobile'];
	}
 
 
  $sk=array('cid'=>$cid,'pro_id'=>$pro_id,'pro_code'=>$pkk['product_code'],'user_id'=>$uid,'user_name'=>$us_detail['f_name'],'mobile'=>$us_detail['mobile'], 'pro_user'=>$pkk['uid'],'pro_mobile'=>$phone);
  	$wsms_sav = $db1->from('sm_main_form_1025')->insert($sk)->execute();
  	
  	
  	$name1=$us_detail['f_name'];
  	$phone1=$us_detail['mobile'];
  	$code=$pkk['product_code'];
  		$sms = "அன்புள்ள வாடிக்கையாளர்,

உங்கள் லிஸ்டிங்-யை ஒருவர் பார்த்துள்ளார். அவர்களின் பெயர் $name1, மற்றும் அவர்களின் மொபைல் எண் $phone1, TrueBroker  வாடிக்கையாளர் இந்தப் பட்டியலைப் பார்வையிட்டார்: https://truebroker.in/listing_detail?id=$code. நீங்கள் TrueBroker இணையதளத்தையும் இங்கே அணுகலாம்: https://truebroker.in மற்றும அப்ளிகேஷனுக்கு  : http://surl.li/ljovf";
	$wsms = array('cid' => $cid, 'mobile' => $phone, 'message' => $sms);
	$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();

    }

	}


	if ($sub_type == 3) {
		// print_r($_POST);









		$result = $db1->sql("select * from listing_mobile where img1!='' ")->many();
		foreach ($result as &$res) {
			$img = $db1->sql("SELECT img_1  FROM sm_main_form_1009 WHERE pro_id=" . $res['id'] . " and del IS NULL and img_1 is not null ")->many();
			$res['pro_pic_all'] = $img;
		}

		echo json_encode($result);
	}


	if ($sub_type == 4) {

		$result = $db1->sql("select * from listing_mobile where id='$pro_id' ")->one();
		$img = $db1->sql("SELECT img_1  FROM sm_main_form_1009 WHERE pro_id='$pro_id' and del IS NULL and img_1 is not null ")->many();

		$result['pro_pic'] = $img;
		echo json_encode($result);
	}





	if ($sub_type == 5) {
		if ($uid != '' && $product_code != '') {

			$dataw['msg'] = "I Like To Share The Property From TrueBroker Please Visit This page https://truebroker.in/listing_detail?id=$product_code";
			echo json_encode($dataw);
		}
	}


	if ($sub_type == 6) {


		//  print_r($_POST);

		if (!empty($cat_id)) {
			$search .= " AND category=$cat_id ";
		}
		if (!empty($sub_cat_id)) {
			$search .= " AND sub_cat=$sub_cat_id ";
		}
		if ($cat_id == 1) {
			if (!empty($saletype)) {
				$search .= " AND listing_for=$saletype ";
			}
			if (!empty($sale_type)) {
				$search .= " AND listing_for=$sale_type ";
			}
		}
		if (!empty($subcatlist)) {
			$subcatlist = rtrim($subcatlist, ",");
			$search .= " AND pro_type in($subcatlist) ";
		}

		if (!empty($minprice)) {
			$search .= " AND (price_in_number >= $minprice) ";
		}
		if (!empty($maxprice)) {
			$search .= " AND (price_in_number <= $maxprice)  ";
		}
		if (!empty($city)) {

			$search .= " AND city like ('%$city%')";

			$word .= "$city";
		}
			if (!empty($list_for)) {
		$search .= " AND listing_for=$list_for";
	}
	if (!empty($area)) {

			$search .= " AND area like ('%$area%')";

			$word .= "$area";
		}
		if (!empty($pincode)) {
			$search .= " AND postal_code=$pincode ";

			$word .= "-$pincode ";
		}
		$ip = array();
		if ($cat_id == 1) {


			if ($sale_type == 0) {
			    if($sub_cat_id!=33){
			     //   echo "1 prem";
				$ip = $db1->sql("SELECT `id`, `aid`, `uid`, `bid`, `cid`, `sub_cat`, `client_name`, `client_whatsapp`, `client_mobile`, 
                            `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, 
                            `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`,
                            `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`,
                            `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`,
                            `user_upload_by`, `paid`, `date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `del`, `is_d`, `act`, `dtime`,
                            (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null    AND category=$cat_id    order by id ASC ")->many();
			    }
			  
			    
			    
			    else{
			         //echo "2 prem";
			        	$ip = $db1->sql("SELECT `id`, `aid`, `uid`, `bid`, `cid`, `sub_cat`, `client_name`, `client_whatsapp`, `client_mobile`, 
                            `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, 
                            `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`,
                            `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`,
                            `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`,
                            `user_upload_by`, `paid`, `date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `del`, `is_d`, `act`, `dtime`,
                            (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null and listing_for!=''   $search  and sub_cat= 33 order by id desc ")->many();
			    }
				// print_r($ip);
				foreach ($ip as &$val) {
				    	$viewcount=$db1->sql("select count(id) as count from sm_main_form_1017 where pro_id='".$val['id']."' ")->one();
			$sk['view_count'] = $viewcount['count'];
					$sk['price_in_number'] =  $val['price_in_alphabet'];
					$sk['listing_for'] = $val['listing_for'];
					$sk['product_title'] =  $val['product_title'];
					$sk['area'] =  $val['area'];
					$sk['pro_type'] =  $val['pro_type'];
					$sk['city'] =  $val['city'];
					$sk['id'] =  $val['id'];
					$sk['client_mobile'] =  $val['client_mobile'];
					$sk['img1'] =  $val['img1'];
					$sk['pro_size'] = $val['product_size'];
					$sk['size_type'] = $val['size_type'];
					$sk['pro_code'] = $val['product_code'];
					// $sk['pro_code']=$val['product_code'];
					$skk[] = $sk;
				}
			} else {


if($sub_cat_id!=33){
    //  echo "3 prem";
				$ip = $db1->sql("SELECT `id`, `aid`, `uid`, `bid`, `cid`, `sub_cat`, `client_name`, `client_whatsapp`, `client_mobile`, 
                            `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, 
                            `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`,
                            `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`,
                            `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`,
                            `user_upload_by`, `paid`, `date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `del`, `is_d`, `act`, `dtime`,
                            (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null and listing_for!=''   $search  and sub_cat != 33 order by id desc ")->many();
}

else{
    //  echo "4 prem";
    $ip = $db1->sql("SELECT `id`, `aid`, `uid`, `bid`, `cid`, `sub_cat`, `client_name`, `client_whatsapp`, `client_mobile`, 
                            `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, 
                            `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`,
                            `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`,
                            `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`,
                            `user_upload_by`, `paid`, `date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `del`, `is_d`, `act`, `dtime`,
                            (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null and listing_for!=''   $search  and sub_cat = 33 order by id desc ")->many();
}
				// print_r($ip);
				foreach ($ip as &$val) {
				    	$viewcount=$db1->sql("select count(id) as count from sm_main_form_1017 where pro_id='".$val['id']."' ")->one();
			$sk['view_count'] = $viewcount['count'];
					$sk['price_in_number'] =  $val['price_in_alphabet'];
					$sk['listing_for'] = $val['listing_for'];
					$sk['product_title'] =  $val['product_title'];
					$sk['area'] =  $val['area'];
					$sk['pro_type'] =  $val['pro_type'];
					$sk['city'] =  $val['city'];
					$sk['id'] =  $val['id'];
					$sk['client_mobile'] =  $val['client_mobile'];
					$sk['img1'] =  $val['img1'];
					$sk['pro_size'] = $val['product_size'];
					$sk['size_type'] = $val['size_type'];
					$sk['pro_code'] = $val['product_code'];
					// $sk['pro_code']=$val['product_code'];
					$skk[] = $sk;
				}
			}
		}

		if ($cat_id == 2) {
		  //   echo "5 prem";

			$ip = $db1->sql("SELECT `id`, `category`, `sub_cat`, `pro_type`, `client_name`, `client_whatsapp`, `client_mobile`, `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`, `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`, `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`, `user_upload_by`, `paid`, `date`, `edit_date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `edit_id`, `del`, `is_d`, `act`, `dtime`, `state`, `job_role`, `job_experience`, `job_salary`, `key_skils`, `place`, `offering_value`, `email`, `website`, `price`, `describtion`, `propriter_name`, `mail_id`, `pincode`, (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL limit 1) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL limit 1) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null    $search   order by id desc limit 50")->many();
			foreach ($ip as &$val) {
			    
				$sk['price_in_number'] =  $val['price_in_alphabet'];
				$sk['email'] = $val['email'];
				$sk['product_title'] =  $val['vehicle_name'];
				$sk['area'] =  $val['area'];
				$sk['pro_type'] =  $val['pro_type'];
				$sk['city'] =  $val['city'];
				$sk['id'] =  $val['id'];
				$sk['client_mobile'] =  $val['contact_number'];
				$sk['img1'] =  $val['img1'];
				// $sk['pro_size']=$val['product_size'];
				// $sk['size_type']=$val['size_type'];
				$sk['pro_code'] = $val['product_code'];
				// $sk['pro_code']=$val['product_code'];
				$skk[] = $sk;
			}
		}

		if ($cat_id == 3) {
			//  print_r($_POST);
// echo "6 prem";
			$ip = $db1->sql("SELECT `id`, `category`, `sub_cat`, `pro_type`, `client_name`, `client_whatsapp`, `client_mobile`, `client_address`, `listing_for`, `product_title`,`qulification` ,`product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`, `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`, `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`, `user_upload_by`, `paid`, `date`, `edit_date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `edit_id`, `del`, `is_d`, `act`, `dtime`, `state`, `job_role`, `job_experience`, `job_salary`, `key_skils`, `place`, `offering_value`, `email`, `website`, `price`, `describtion`, `propriter_name`, `mail_id`, `pincode`, (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL limit 1) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL limit 1) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null    $search   order by id desc")->many();
			foreach ($ip as &$val) {
				//   =$val['job_role'];
				// $rolename = $db->sql("SELECT name FROM sm_main_form_11 WHERE value=" . $val["job_role"] . " and list_id=217 ")->one();
$head_job=$db1->sql("select ans as job from add_property_1 where del is null and mid=".$val['id']." and ques='Job_Role'")->one();
				$sk['price_in_number'] = "Salary From:".$val['price_in_number'];
				$sk['email'] = $val['email'];
				$sk['product_title'] = "Role:". $head_job['job'];
				$sk['area'] = "Qualification:".$val['qulification'];
				$sk['pro_type'] =  $val['pro_type'];
				$sk['city'] =  "Location:".$val['city'];
				$sk['id'] =  $val['id'];
				$sk['client_mobile'] =  $val['contact_no'];
				$sk['img1'] =  $val['img1'];
				$sk['pro_size'] ="Company Name:". $val['company_name'];
				// $sk['size_type']=$val['size_type'];
				$sk['pro_code'] = $val['product_code'];
				// $sk['pro_code']=$val['product_code'];
				$skk[] = $sk;
			}
		}
		if ($cat_id == 4) {
			//  print_r($_POST);
// 			echo "7 prem";

			$ip = $db1->sql("SELECT `id`, `category`, `sub_cat`, `pro_type`, `client_name`, `client_whatsapp`, `client_mobile`, `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`, `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`, `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`, `user_upload_by`, `paid`, `date`, `edit_date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `edit_id`, `del`, `is_d`, `act`, `dtime`, `state`, `job_role`, `job_experience`, `job_salary`, `key_skils`, `place`, `offering_value`, `email`, `website`, `price`, `describtion`, `propriter_name`, `mail_id`, `pincode`, (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL limit 1) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL limit 1) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null    $search   order by id desc")->many();
			foreach ($ip as &$val) {
				//   =$val['job_role'];
				// $rolename=$db->sql("SELECT name FROM sm_main_form_11 WHERE value=" . $val["job_role"] . " and list_id=217 ")->one();           
                    //  $head_job=$db1->sql("select ans as job from add_property_1 where del is null and mid=".$val['id']." and ques='Job_Role'")->one();
				$sk['price_in_number'] = "Client Name:".$val['propriter_name'] ;
				// $sk['email']=$val['email'];
				$sk['product_title'] = $val['business_name'] ;
				$sk['area'] = "Area:". $val['area'];
				$sk['pro_type'] =  $val['pro_type'];
				$sk['city'] = "City:". $val['city'];
				$sk['id'] =  $val['id'];
				$sk['client_mobile'] =  $val['contact_number'];
				$sk['img1'] =  $val['img1'];
				$sk['pro_size'] = "Description:".$val['description'];
				// $sk['size_type']=$val['size_type'];
				$sk['pro_code'] = $val['product_code'];
				// $sk['pro_code']=$val['product_code'];
				$skk[] = $sk;
			}
		}

		if ($cat_id == 5) {
			//  print_r($_POST);
// 	echo "8 prem";
			$ip = $db1->sql("SELECT `id`, `category`, `sub_cat`, `pro_type`, `client_name`, `client_whatsapp`, `client_mobile`, `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`, `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`, `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`, `user_upload_by`, `paid`, `date`, `edit_date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `edit_id`, `del`, `is_d`, `act`, `dtime`, `state`, `job_role`, `job_experience`, `job_salary`, `key_skils`, `place`, `offering_value`, `email`, `website`, `price`, `describtion`, `propriter_name`, `mail_id`, `pincode`, (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1 ) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL limit 1) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL limit 1) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null    $search   order by id desc")->many();
			foreach ($ip as &$val) {
				//   =$val['job_role'];
				// $rolename=$db->sql("SELECT name FROM sm_main_form_11 WHERE value=" . $val["job_role"] . " and list_id=217 ")->one();           

				$sk['price_in_number'] =  $val['company_name'] . "in" . $val['city'];
				$sk['listing_for'] = $val['business_proof'];
				$sk['product_title'] =  $val['address'];
				$sk['area'] =  $val['area'];
				$sk['pro_type'] =  $val['pro_type'];
				$sk['city'] =  $val['city'];
				$sk['id'] =  $val['id'];
				$sk['client_mobile'] =  $val['contact_number'];
				$sk['img1'] =  $val['img1'];
				$sk['pro_size'] = $val['payment_mode'];
				// $sk['size_type']=$val['size_type'];
				$sk['pro_code'] = $val['product_code'];
				// $sk['pro_code']=$val['product_code'];
				$skk[] = $sk;
			}
		}
		if ($cat_id == 7) {
			//  print_r($_POST);
// 	echo "9 prem";
			$ip = $db1->sql("SELECT `id`, `category`, `sub_cat`, `pro_type`, `client_name`, `client_whatsapp`, `client_mobile`, `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`, `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`, `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`, `user_upload_by`, `paid`, `date`, `edit_date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `edit_id`, `del`, `is_d`, `act`, `dtime`, `state`, `job_role`, `job_experience`, `job_salary`, `key_skils`, `place`, `offering_value`, `email`, `website`, `price`, `describtion`, `propriter_name`, `mail_id`, `pincode`, (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1 ) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL limit 1) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL limit 1) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null    $search   order by id desc")->many();
			foreach ($ip as &$val) {
				//   =$val['job_role'];
				$pro_for = $db->sql("SELECT name FROM sm_main_form_11 WHERE value=" . $val["mobile_brand"] . " and list_id=224 and del IS NULL")->one();

				$sk['price_in_number'] =  $pro_for['name'];
				$sk['listing_for'] = $val['seller_name'];
				$sk['product_title'] =  $val['description'];
				$sk['area'] =  $val['area'];
				$sk['pro_type'] =  $val['pro_type'];
				$sk['city'] =  $val['city'];
				$sk['id'] =  $val['id'];
				$sk['client_mobile'] =  $val['mobile_number'];
				$sk['img1'] =  $val['img1'];
				$sk['pro_size'] = $val['description'];
				// $sk['size_type']=$val['size_type'];
				$sk['pro_code'] = $val['product_code'];
				// $sk['pro_code']=$val['product_code'];
				$skk[] = $sk;
			}
		}
		
		

		echo json_encode($skk);
	}



	if ($sub_type == 7) {
	}
	
		if ($sub_type == 8) {
		  //  print_r($_POST);
	$resultz = $db1->sql("select id from add_property where del is null and product_code=$pro_code1")->one();
	$pro_id=$resultz['id'];
		// print_r($_POST);
	$result = $db1->sql("SELECT *,
                            (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            FROM add_property as a WHERE pro_view=1 and del is null and id='$pro_id' $search   order by id desc   ")->one();
                            
                            
                            
                            
                            // 	echo	$result = $db1->sql("SELECT `id`, `aid`, `uid`, `bid`, `cid`, `sub_cat`, `client_name`, `client_whatsapp`, `client_mobile`, 
                            // `client_address`, `listing_for`, `product_title`, `product_code`, `size_type`, `product_size`, `price_in_number`, `price_in_alphabet`, `address`, `post_id`, `postal_code`, `area`, 
                            // `city`, `type_of_customer`, `latitude`, `logitute`, `description`, `bhk_values`, `business_name`, `business_proof`, `product_name`, `offer`, `company_address`, `email_id`, `contact_no`,
                            // `name`, `contact_number`, `business_timing`, `years_been_in_the_field`, `offered_service`, `vechicle_type`, `company_name`, `officering_value`, `interest_range`, `payment_mode`,
                            // `investment_types`, `customer_name`, `vehicle_name`, `offering_loans`, `seller_name`, `mobile_brand`, `used_years`, `mobile_number`, `computer_brand`, `home_appliance_types`, `user_approved_by`,
                            // `user_upload_by`, `paid`, `date`, `date_listing`, `expired_date`, `update_date`, `lt`, `ln`, `type`, `pro_view`, `del`, `is_d`, `act`, `dtime`,
                            // (SELECT img_1 FROM sm_main_form_1009 WHERE pro_id=a.id and del IS NULL limit 1) as img1, 
                            // (SELECT category FROM sm_main_form_1000 WHERE id=a.category and del IS NULL) as category ,
                            // (SELECT pro_type FROM sm_main_form_1002 WHERE id=a.pro_type and del IS NULL) as pro_type 
                            // FROM add_property as a WHERE pro_view=1 and del is null and id='$pro_id' $search   order by id desc   ")->sql();
                            
                            
                            
                            
                            
		$img = $db1->sql("SELECT img_1  FROM sm_main_form_1009 WHERE pro_id='$pro_id' and del IS NULL and img_1 is not null ")->many();
	
		

		$datacount = $db1->sql("select * from sm_main_form_1022 where del is null and pro_id='$pro_id' and customerid=$uid")->many();
		$datacount = count($datacount);

		if ($datacount == 0) {
			$result['like'] = 0;
		} else {
			$result['like'] = 1;
		}

		$qa = $db1->sql("SELECT ans,ques,ques_id FROM add_property_1 WHERE mid=$pro_id and del IS NULL and ans IS NOT NULL")->many();
		foreach ($qa as $ans) {
			$qaw = $db1->sql("SELECT que_name FROM sm_main_form_1003 WHERE id='" . $ans['ques_id'] . "' and del IS NULL")->one();

			$qas['question'] = $qaw['que_name'];
			$qas['answer'] = $ans['ans'];
			$qans[] = $qas;
		}
		$result['qa'] = $qans;
		$result['pro_pic'] = $img;
		$result['view_count'] = $viewcount['count'];
		
		
		
		
		
		echo json_encode($result);
		
		
		$pkk=$db1->sql("select * from add_property where id=$pro_id and del is null")->one();
		
		  $view=$db1->sql("select count(id) as ccount from sm_main_form_1025 where pro_id=$pro_id and user_id=$uid")->one();
    // print_r($view);
// echo $view['ccount']."prem";
    if($view['ccount']==0){
     $us_detail=$db->sql("select* from sm_main_form_20 where id=$uid")->one();
 
 if ($pkk['category'] == 1) {
		$name = $pkk['client_name'];
		$phone = $pkk['client_whatsapp'];
	} 
	elseif ($pkk['category'] == 2) {

		$name = $pkk['customer_name'];
		$phone = $pkk['contact_number'];
	}
	elseif ($pkk['category'] == 3) {

		$name = $pkk['name'];
		$phone = $pkk['contact_no'];
	}
	elseif ($pkk['category'] == 4) {

		$name = $pkk['name'];
		$phone = $pkk['contact_number'];
	}
	elseif ($pkk['category'] == 5) {

		$name = $pkk['company_name'];
		$phone = $pkk['contact_number'];
	}
	elseif ($pkk['category'] == 7) {

		$name = $pkk['seller_name'];
		$phone = $pkk['mobile_number'];
	} 
	else {
		$uid55 = $pkk['uid'];
		$sel1 = $db->sql("select * from sm_main_form_20 where id=$uid55")->one();
		$name = $sel1['f_name'];
		$phone = $sel1['mobile'];
	}
 
 
  $sk=array('cid'=>$cid,'pro_id'=>$pro_id,'pro_code'=>$pkk['product_code'],'user_id'=>$uid,'user_name'=>$us_detail['f_name'],'mobile'=>$us_detail['mobile'], 'pro_user'=>$pkk['uid'],'pro_mobile'=>$phone);
  	$wsms_sav = $db1->from('sm_main_form_1025')->insert($sk)->execute();
  	
  	
  	$name1=$us_detail['f_name'];
  	$phone1=$us_detail['mobile'];
  	$code=$pkk['product_code'];
  		$sms = "அன்புள்ள வாடிக்கையாளர்,

உங்கள் லிஸ்டிங்-யை ஒருவர் பார்த்துள்ளார். அவர்களின் பெயர் $name1, மற்றும் அவர்களின் மொபைல் எண் $phone1, TrueBroker  வாடிக்கையாளர் இந்தப் பட்டியலைப் பார்வையிட்டார்: https://truebroker.in/listing_detail?id=$code. நீங்கள் TrueBroker இணையதளத்தையும் இங்கே அணுகலாம்: https://truebroker.in மற்றும அப்ளிகேஷனுக்கு  : http://surl.li/ljovf";
	$wsms = array('cid' => $cid, 'mobile' => $phone, 'message' => $sms);
	$wsms_sav = $db->from('send_wsms')->insert($wsms)->execute();

    }

	}
	
	
	if($sub_type==9){
	   // ini_set("display_errors",1);
	   //$result = $db->sql("select value, name from sm_main_form_11  WHERE list_id = '240'")->many(); 
  $result = $db1->sql("SELECT DISTINCT(listing_for)as lis,category  FROM `add_property` where category=$category and  listing_for is not null and listing_for !=0")->many(); 
	   foreach($result as &$res){
	       
	      $sel1=$db->sql("select value, name from sm_main_form_11  WHERE list_id = '193' and value='".$res['lis']."'")->one(); 
	       $res['category']=$sel1['name'];
	   }
	   echo json_encode($result);
	}
	
	
	if($sub_type==10){
	    $date=date("Y-m-d");
	    if($pro_id!="" && $uid!=""){
	    $db1->sql("INSERT INTO `sm_main_form_1017`( `cid`, `date`, `pro_id`, `user_id`, `ip_add`) VALUES ('$cid','$date','$pro_id','$uid','$ip_add')")->execute();
	     $response['error']=false;
	        $response['error_msg']="inserted successfully";
	    }else{
	        $response['error']=true;
	        $response['error_msg']="pro_id and user_id is missing";
	    }
	    echo json_encode($response);
	}
	
	
	
}



?>
