<?php 
ini_set("display_errors",-1);
$cid=$_GET['cid'];


require_once('../index.php');
require_once(BASEPATH.'config/autoloader.php');
require_once(BASEPATH.'config/sysconfig.php');
$db = new Dbclass();
$db1 = new Dbclass($cid);


$data=$_GET;
//print_r($_POST);
$cdate=date('Y-m-d');

// $pdata=json_encode($_GET);

//save query --receipt

    
    /* request save*/ 
    
    $url="receipt_api.php";
     $r_t=$data['request'];
       date_default_timezone_set('Asia/Kolkata');
    $new=fopen("log_sms.txt",'a');
    $CURRENTDATE=date("Y-m-d H:i:s"); 
    $write= "[" . $CURRENTDATE  ." - " . $data['cid'] ." - " . $data['type']." - " . $r_t."-".$url.".$pdata."  ;
    
   
    
    
    fwrite($new,$write);
    fwrite($new,"\r\n");
    fclose($new);
    
    /* 'ef'=>1
     is mobile save  entry different */
      
    
  
// 
           
             $user =new USER();
     
             
                      
    //                  if ($cid=='45281857' ) {
                            
    //                         $grpdata=$db1->sql("select * from sm_main_form_1417 where del is null and name='".$data['led_id']."' and id='".$data['chit_id']."' ")->one();
                             
    //                          $gs=$grpdata['gname']."/".$grpdata['ch_value'];
    //   $message="We have received your payment of ".$data['amount']." towards SJVCPL Chits Group $gs, Ticket #".$grpdata['t_no'].". Thank you.";
	   //// $message="Dear ".$data['name'].", ReciptNo: ".$lastid.", Amount: ".$data['amount'].",Balance: ".$data['balance'].", Thank you for Payment at Thank you SriJothivinayaga chits Contact: 9566616720. From CHITSOFT";
	    
	   // $phone=$data["mobile"];
	   //// $template_id="22";
	   //$template_id="54";
    //     $user->sendsms_api($phone,$message,$cid,$template_id);

	   //// return true;
    //     }        
    $cid=='64389719';
        if ($cid=='64389719' || $cid=='21472147') {
                            
                        $sdata=$db1->sql("select * from sm_main_form_1417 where del is null and  id='".$data['acno']."' ")->one();
     
	    $message="Dear ".$sdata['sub_name'].", ReciptNo: ".$data['rno'].", Amount: ".$data['amount'].",Balance: , Thank you for Payment at Thank you MANICHANDER CHITS INDIA (P) LIMITED Contact: 9791515266. From CHITSOFT";
	    
	    $phone=$sdata["mobile"];
	    $template_id="22";
	    $message;
	 
       $user->sendsms_api($phone,$message,$cid,$template_id);

	   // return true;
        }
        
  
                




?>